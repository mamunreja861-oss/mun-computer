/**
 * server/permissions.ts - 3-Level Role & Individual Permission Control Engine
 * MUN COMPUTER BUSINESS MANAGER ("One Business, Three Levels of Control")
 */

export const PERMISSION_ACTIONS = [
  'view',
  'add',
  'edit',
  'delete',
  'approve',
  'export',
  'print'
] as const;

export type PermissionAction = (typeof PERMISSION_ACTIONS)[number];

export type MenuPermissionSet = Record<PermissionAction, boolean>;

export interface MenuDefinition {
  id: string;
  label: string;
  group: string;
  description: string;
}

export interface ExtraPermissionControls {
  cashOperationLimit: number; // 0 = Unlimited
  customerAccessScope: 'ALL' | 'ASSIGNED';
  customerAccessLimit: number; // 0 = Unlimited
  canApproveTransactions: boolean;
  canViewAllAttendancePhotos: boolean;
  canManageBackupSettings: boolean;
  canManageUserPermissions: boolean;
  accountActive: boolean;
}

export interface EffectivePermissions {
  role: string;
  isSuperAdmin: boolean;
  menus: Record<string, MenuPermissionSet>;
  extra: ExtraPermissionControls;
}

export const MENU_DEFINITIONS: MenuDefinition[] = [
  // CORE
  { id: 'dashboard', label: 'Dashboard', group: 'CORE', description: 'KPI cards and business summary' },
  { id: 'universal-search', label: 'Universal Search', group: 'CORE', description: 'Cross-module global search' },

  // SERVICES & DIRECTORY
  { id: 'customers', label: 'Customer Directory', group: 'SERVICES & DIRECTORY', description: 'Customer profiles, visits & search' },
  { id: 'applications', label: 'Applications & Timeline', group: 'SERVICES & DIRECTORY', description: 'Service application tracking & status' },
  { id: 'services', label: 'Services & Tracking', group: 'SERVICES & DIRECTORY', description: 'Service bookings, receipts & catalog' },
  { id: 'rate-chart', label: 'Service Rate Chart', group: 'SERVICES & DIRECTORY', description: 'Official rates & A4 printable chart' },
  { id: 'whatsapp-connect', label: 'WhatsApp Customer Connect', group: 'SERVICES & DIRECTORY', description: 'Manual pre-filled +91 WhatsApp dispatch' },
  { id: 'inventory', label: 'Hardware & Stock', group: 'SERVICES & DIRECTORY', description: 'Stock levels and hardware items' },
  { id: 'followups', label: 'Smart Follow-ups', group: 'SERVICES & DIRECTORY', description: 'Customer callbacks & due reminders' },

  // OPERATIONS
  { id: 'counter-daybook', label: 'Counter Day Book', group: 'OPERATIONS', description: 'Daily cash book & counter ledger' },
  { id: 'daily-opening-cash', label: 'Daily Opening Cash', group: 'OPERATIONS', description: 'Morning opening float & balance carry-forward' },
  { id: 'daily-closing-cash', label: 'Daily Closing Cash', group: 'OPERATIONS', description: 'Evening physical cash count & lock' },
  { id: 'staff-attendance', label: 'Staff Attendance', group: 'OPERATIONS', description: 'Attendance register & status' },
  { id: 'time-register', label: 'Time Management Register', group: 'OPERATIONS', description: 'In/Out times, late & overtime tracking' },
  { id: 'gps-attendance', label: 'GPS Location Attendance', group: 'OPERATIONS', description: 'GPS coordinates + selfie punch' },
  { id: 'staff-location-map', label: 'Staff Photo & Location Mapping', group: 'OPERATIONS', description: 'GPS pins & Google Maps check' },
  { id: 'attendance-photo-gallery', label: 'Attendance Photo Gallery', group: 'OPERATIONS', description: 'Morning In & Evening Out photo verification, download, print & Admin delete' },
  { id: 'attendance-reports', label: 'Attendance Reports', group: 'OPERATIONS', description: 'Monthly attendance & punctuality reports' },
  { id: 'cash-reports', label: 'Cash Reports', group: 'OPERATIONS', description: 'Date-range cash flow reports' },
  { id: 'govt-annapurna', label: 'Annapurna Yojana System', group: 'OPERATIONS', description: 'Annapurna Yojana applications, claims, grievances & follow-ups' },

  // FINANCE
  { id: 'payments', label: 'Payments & Ledger', group: 'FINANCE', description: 'Customer payments and pending dues' },
  { id: 'invoices', label: 'Billing & Invoices', group: 'FINANCE', description: 'Official bills and printable invoices' },
  { id: 'expenses', label: 'Expense Management', group: 'FINANCE', description: 'Expense entries & approval requests' },
  { id: 'income', label: 'Income & Profit', group: 'FINANCE', description: 'Revenue, margin & profit analytics' },

  // ENTERPRISE & GROWTH
  { id: 'business', label: 'Business Profile', group: 'ENTERPRISE', description: 'Shop profile & corporate identity' },
  { id: 'targets', label: 'Business Targets', group: 'GROWTH', description: 'Monthly goals & progress' },
  { id: 'projects', label: 'New Business Projects', group: 'GROWTH', description: 'Expansion projects & initiatives' },
  { id: 'investments', label: 'Capital & Investments', group: 'GROWTH', description: 'Capital & asset ledger' },
  { id: 'marketing', label: 'Marketing & Campaigns', group: 'GROWTH', description: 'Customer campaigns' },
  { id: 'competitors', label: 'Competitor Analysis', group: 'GROWTH', description: 'Market benchmarking' },

  // TEAM
  { id: 'tasks', label: 'Staff & Tasks', group: 'TEAM', description: 'Staff assignments and task board' },
  { id: 'chat', label: 'Team Chat', group: 'TEAM', description: 'Internal counter team messaging' },
  { id: 'documents', label: 'Document Vault', group: 'TEAM', description: 'Protected document uploads & downloads' },

  // SYSTEM
  { id: 'user-approvals', label: 'User Approvals & Permissions', group: 'SYSTEM', description: 'Role management, approvals & individual user permissions' },
  { id: 'locations-master', label: 'Locations & Domkal Wards', group: 'SYSTEM', description: 'Murshidabad village & PIN directory' },
  { id: 'reports', label: 'Reports & Analytics', group: 'SYSTEM', description: 'Business performance analytics' },
  { id: 'admin-settings', label: 'Dynamic Admin Control Settings', group: 'SYSTEM', description: 'Manage all dropdowns, services, statuses, 90-day schedules, portals & defaults (Admin-Only)' },
  { id: 'settings', label: 'Settings, Security & Backups', group: 'SYSTEM', description: 'System settings, audit logs, delete history & backups' }
];

function makeSet(overrides: Partial<MenuPermissionSet> = {}): MenuPermissionSet {
  return {
    view: false,
    add: false,
    edit: false,
    delete: false,
    approve: false,
    export: false,
    print: false,
    ...overrides
  };
}

function allTrueSet(): MenuPermissionSet {
  return {
    view: true,
    add: true,
    edit: true,
    delete: true,
    approve: true,
    export: true,
    print: true
  };
}

export function getDefaultRolePermissions(roleInput?: string): EffectivePermissions {
  const role = String(roleInput || 'STAFF').trim().toUpperCase();
  const menus: Record<string, MenuPermissionSet> = {};

  if (role === 'ADMIN') {
    for (const def of MENU_DEFINITIONS) {
      menus[def.id] = allTrueSet();
    }
    return {
      role: 'ADMIN',
      isSuperAdmin: false,
      menus,
      extra: {
        cashOperationLimit: 0,
        customerAccessScope: 'ALL',
        customerAccessLimit: 0,
        canApproveTransactions: true,
        canViewAllAttendancePhotos: true,
        canManageBackupSettings: true,
        canManageUserPermissions: true,
        accountActive: true
      }
    };
  }

  if (role === 'MANAGER') {
    for (const def of MENU_DEFINITIONS) {
      menus[def.id] = makeSet();
    }
    const managerBusinessFull = [
      'dashboard',
      'universal-search',
      'customers',
      'applications',
      'services',
      'rate-chart',
      'whatsapp-connect',
      'inventory',
      'followups',
      'counter-daybook',
      'daily-opening-cash',
      'daily-closing-cash',
      'staff-attendance',
      'time-register',
      'gps-attendance',
      'staff-location-map',
      'attendance-reports',
      'cash-reports',
      'govt-annapurna',
      'payments',
      'invoices',
      'targets',
      'tasks',
      'chat',
      'documents',
      'locations-master',
      'reports'
    ];
    for (const id of managerBusinessFull) {
      menus[id] = makeSet({
        view: true,
        add: true,
        edit: true,
        delete: false,
        approve: true,
        export: true,
        print: true
      });
    }
    // Manager expense: can enter & request approval, Admin approves by default
    menus['expenses'] = makeSet({
      view: true,
      add: true,
      edit: true,
      delete: false,
      approve: false,
      export: true,
      print: true
    });
    menus['income'] = makeSet({
      view: true,
      add: false,
      edit: false,
      delete: false,
      approve: false,
      export: true,
      print: true
    });
    // Attendance Photo Gallery: Manager sees own by default; Admin permission enables verifying all staff photos; NEVER delete
    menus['attendance-photo-gallery'] = makeSet({
      view: true,
      add: false,
      edit: false,
      delete: false,
      approve: false,
      export: true,
      print: true
    });
    menus['projects'] = makeSet({ view: true, add: true, edit: true, print: true });
    // Strict restriction: Manager CANNOT change User Permissions, Business Settings, or Backup without Admin permission
    menus['user-approvals'] = makeSet();
    menus['admin-settings'] = makeSet();
    menus['settings'] = makeSet();
    menus['business'] = makeSet();
    menus['investments'] = makeSet();
    menus['marketing'] = makeSet();
    menus['competitors'] = makeSet();

    return {
      role: 'MANAGER',
      isSuperAdmin: false,
      menus,
      extra: {
        cashOperationLimit: 50000,
        customerAccessScope: 'ALL',
        customerAccessLimit: 0,
        canApproveTransactions: true,
        canViewAllAttendancePhotos: false,
        canManageBackupSettings: false,
        canManageUserPermissions: false,
        accountActive: true
      }
    };
  }

  // STAFF / MAKER / CHECKER default work-access template
  for (const def of MENU_DEFINITIONS) {
    menus[def.id] = makeSet();
  }

  menus['dashboard'] = makeSet({ view: true });
  menus['universal-search'] = makeSet({ view: true });
  menus['customers'] = makeSet({ view: true, add: true, edit: true, print: true });
  menus['applications'] = makeSet({ view: true, add: true, edit: true, print: true });
  menus['services'] = makeSet({ view: true, add: true, edit: false, print: true });
  // Service Rate Chart is STRICTLY View Only for Staff by default
  menus['rate-chart'] = makeSet({ view: true, print: true });
  menus['whatsapp-connect'] = makeSet({ view: true, add: true });
  menus['invoices'] = makeSet({ view: true, add: true, print: true });
  // Expense Request only
  menus['expenses'] = makeSet({ view: true, add: true });
  // Own Attendance, GPS Check-in/Check-out, Own Photo, Own Time Register, Own Attendance Report
  menus['staff-attendance'] = makeSet({ view: true, add: true });
  menus['time-register'] = makeSet({ view: true, add: true });
  menus['gps-attendance'] = makeSet({ view: true, add: true });
  menus['staff-location-map'] = makeSet({ view: true });
  menus['attendance-photo-gallery'] = makeSet({ view: true, print: true });
  menus['attendance-reports'] = makeSet({ view: true, print: true });
  menus['govt-annapurna'] = makeSet({ view: true, add: true, edit: true, print: true });
  // Assigned Tasks, Team Chat, Assigned Documents
  menus['tasks'] = makeSet({ view: true, edit: true });
  menus['chat'] = makeSet({ view: true, add: true, edit: true, delete: true });
  menus['documents'] = makeSet({ view: true, add: true, print: true });

  // Legacy MAKER / CHECKER slight compatibility while staying restricted from admin/photos/financial abuse
  if (role === 'CHECKER') {
    menus['reports'] = makeSet({ view: true, print: true });
  }

  return {
    role: role || 'STAFF',
    isSuperAdmin: false,
    menus,
    extra: {
      cashOperationLimit: 5000,
      customerAccessScope: 'ASSIGNED',
      customerAccessLimit: 250,
      canApproveTransactions: false,
      canViewAllAttendancePhotos: false,
      canManageBackupSettings: false,
      canManageUserPermissions: false,
      accountActive: true
    }
  };
}

export function resolveEffectivePermissions(user: {
  uid?: string;
  role?: string;
  isSuperAdmin?: boolean;
  status?: string;
  permissionOverrides?: Record<string, Partial<MenuPermissionSet>>;
  extraPermissions?: Partial<ExtraPermissionControls>;
} | null | undefined): EffectivePermissions {
  if (!user) {
    const empty = getDefaultRolePermissions('STAFF');
    for (const key of Object.keys(empty.menus)) {
      empty.menus[key] = makeSet();
    }
    empty.extra.accountActive = false;
    return empty;
  }

  const isRootSuper = Boolean(user.isSuperAdmin || user.uid === 'MUNCOMPUTER-2019');
  const role = String(user.role || 'STAFF').trim().toUpperCase();
  const base = getDefaultRolePermissions(isRootSuper ? 'ADMIN' : role);
  base.isSuperAdmin = isRootSuper;

  if (isRootSuper) {
    return base;
  }

  // Merge per-menu overrides
  const overrides = user.permissionOverrides || {};
  for (const def of MENU_DEFINITIONS) {
    const ov = overrides[def.id];
    if (ov && typeof ov === 'object') {
      const target = base.menus[def.id];
      for (const act of PERMISSION_ACTIONS) {
        if (typeof ov[act] === 'boolean') {
          target[act] = ov[act] as boolean;
        }
      }
    }
  }

  // Merge extra controls
  const extOv = user.extraPermissions || {};
  if (typeof extOv.cashOperationLimit === 'number' && Number.isFinite(extOv.cashOperationLimit)) {
    base.extra.cashOperationLimit = Math.max(0, extOv.cashOperationLimit);
  }
  if (extOv.customerAccessScope === 'ALL' || extOv.customerAccessScope === 'ASSIGNED') {
    base.extra.customerAccessScope = extOv.customerAccessScope;
  }
  if (typeof extOv.customerAccessLimit === 'number' && Number.isFinite(extOv.customerAccessLimit)) {
    base.extra.customerAccessLimit = Math.max(0, extOv.customerAccessLimit);
  }
  if (typeof extOv.canApproveTransactions === 'boolean') {
    base.extra.canApproveTransactions = extOv.canApproveTransactions;
  }
  if (typeof extOv.canViewAllAttendancePhotos === 'boolean') {
    base.extra.canViewAllAttendancePhotos = extOv.canViewAllAttendancePhotos;
  }
  if (typeof extOv.canManageBackupSettings === 'boolean') {
    base.extra.canManageBackupSettings = extOv.canManageBackupSettings;
  }
  if (typeof extOv.canManageUserPermissions === 'boolean') {
    base.extra.canManageUserPermissions = extOv.canManageUserPermissions;
  }

  base.extra.accountActive = user.status === 'ACTIVE';

  // Hard security invariants from Master Spec:
  // 1. Attendance Photo Delete & Dynamic Admin Settings are strictly Administrator-only
  if (role !== 'ADMIN') {
    base.menus['attendance-photo-gallery'].delete = false;
    base.menus['admin-settings'] = makeSet();
    // 2. Staff CANNOT view other staff's Attendance Photos or GPS History
    if (role !== 'MANAGER') {
      base.extra.canViewAllAttendancePhotos = false;
    }
  }

  return base;
}

export function hasMenuPermission(
  user: any,
  menuId: string,
  action: PermissionAction = 'view'
): boolean {
  const eff = resolveEffectivePermissions(user);
  if (eff.isSuperAdmin) return true;
  if (!eff.extra.accountActive) return false;
  const set = eff.menus[menuId];
  if (!set) return false;
  return Boolean(set[action]);
}
