import crypto from 'crypto';
import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'url';
import { locationService } from './server/locationService.js';
import { murshidabadMaster } from './server/murshidabadMaster.js';
import {
  centralDb,
  SUPER_ADMIN_UID,
  DEFAULT_ADMIN_PASSWORD,
  AppRole,
  AccountStatus,
  ApprovalStatus,
  validateVerhoeffAadhaar,
  encryptSensitive,
  decryptSensitive,
  hashSensitive,
  maskAadhaar,
  maskPhone,
  issueSessionToken,
  verifySessionToken,
  generateCaptchaChallenge,
  verifyCaptchaChallenge,
  issueForgotStepToken,
  verifyForgotStepToken,
  getKolkataDateParts,
  getRoleCode,
  getIdFormatPreview,
  generateSecureTempPassword,
  validatePasswordStrength
} from './server/centralDb.js';
import {
  MENU_DEFINITIONS,
  PERMISSION_ACTIONS,
  PermissionAction,
  getDefaultRolePermissions,
  resolveEffectivePermissions,
  hasMenuPermission
} from './server/permissions.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === 'production';

// 10mb JSON limit for up to 5MB base64 Document Vault uploads
app.use(express.json({ limit: '10mb' }));

const DATA_DIR = path.resolve(process.cwd(), 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const SMS_CONFIG_FILE = path.join(DATA_DIR, 'sms-config.json');
const UPI_SETTINGS_FILE = path.join(DATA_DIR, 'upi-settings.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// ---------------------------------------------------------------------------
// IN-MEMORY OTP & RATE LIMITER
// ---------------------------------------------------------------------------
interface OtpRecord {
  phone: string;
  otpHash: string;
  expiresAt: number;
  lastSentAt: number;
  type: 'REGISTRATION' | 'FORGOT_PASSWORD';
  uid?: string;
  verified?: boolean;
}

const activeOtps = new Map<string, OtpRecord>();
const rateLimiter = new Map<string, { attempts: number; resetAt: number }>();

function checkRateLimit(key: string, maxAttempts = 10, windowMs = 15 * 60 * 1000): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const record = rateLimiter.get(key);
  if (!record || now > record.resetAt) {
    rateLimiter.set(key, { attempts: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: maxAttempts - 1 };
  }
  if (record.attempts >= maxAttempts) {
    return { allowed: false, remaining: 0 };
  }
  record.attempts += 1;
  return { allowed: true, remaining: maxAttempts - record.attempts };
}

export interface UserRecord {
  requestId: string;
  uid: string;
  name: string;
  fatherName?: string;
  motherName?: string;
  dob?: string;
  role: AppRole;
  isSuperAdmin?: boolean;
  designation: string;
  phone: string;
  phoneMasked?: string;
  aadhaarMasked?: string;
  aadhaarEncrypted?: string;
  aadhaarHash?: string;
  email: string;
  district?: string;
  areaType?: 'RURAL' | 'URBAN';
  blockOrMunicipality?: string;
  gpOrWard?: string;
  villageOrWard?: string;
  postOffice?: string;
  policeStation?: string;
  pinCode?: string;
  address?: string;
  profilePhotoDocId?: string;
  supportingDocId?: string;
  registrationDate?: string;
  passwordHash: string;
  mustChangePassword: boolean;
  sessionVersion?: number;
  failedLoginAttempts?: number;
  failedResetAttempts?: number;
  lockedUntil?: string | null;
  loginCount?: number;
  lastLoginPanel?: string;
  passwordChangeCount?: number;
  dailyPasswordChangeDate?: string;
  dailyPasswordChangeCount?: number;
  passwordHistory?: Array<{ changedAt: string; method: string }>;
  status: AccountStatus;
  approvalStatus: ApprovalStatus;
  verificationStatus: string;
  createdAt: string;
  updatedAt?: string;
  lastLoginAt?: string;
  passwordChangedAt?: string;
  approvedByUid?: string;
  approvedAt?: string;
  decisionNotes?: string;
  approvalHistory?: Array<{
    timestamp: string;
    action: string;
    actorUid: string;
    notes?: string;
  }>;
  permissionOverrides?: Record<string, any>;
  extraPermissions?: Record<string, any>;
}

function sanitizeUserForResponse(user: UserRecord, includeAdminFields = true) {
  const { passwordHash, aadhaarHash, aadhaarEncrypted, ...rest } = user;
  const effectivePermissions = resolveEffectivePermissions(user);
  const masked = {
    requestId: rest.requestId,
    uid: rest.uid,
    name: rest.name,
    role: rest.role,
    isSuperAdmin: Boolean(rest.isSuperAdmin || rest.uid === SUPER_ADMIN_UID),
    designation: rest.designation,
    phoneMasked: user.phoneMasked || maskPhone(user.phone),
    aadhaarMasked: user.aadhaarMasked || (user.aadhaarHash ? 'XXXX-XXXX-XXXX' : 'Not Provided'),
    status: rest.status,
    approvalStatus: rest.approvalStatus,
    verificationStatus: rest.verificationStatus,
    mustChangePassword: Boolean(rest.mustChangePassword),
    dailyPasswordChangesUsed:
      rest.dailyPasswordChangeDate === getKolkataDateParts().isoDate ? Number(rest.dailyPasswordChangeCount || 0) : 0,
    dailyPasswordChangesRemaining: Math.max(
      0,
      5 - (rest.dailyPasswordChangeDate === getKolkataDateParts().isoDate ? Number(rest.dailyPasswordChangeCount || 0) : 0)
    ),
    dailyPasswordChangeLimit: 5,
    registrationDate: rest.registrationDate || (rest.createdAt ? rest.createdAt.split('T')[0] : ''),
    createdAt: rest.createdAt,
    updatedAt: rest.updatedAt,
    lastLoginAt: rest.lastLoginAt,
    lastLoginPanel: rest.lastLoginPanel,
    approvedByUid: rest.approvedByUid,
    approvedAt: rest.approvedAt,
    decisionNotes: rest.decisionNotes,
    permissionOverrides: rest.permissionOverrides || {},
    extraPermissions: rest.extraPermissions || {},
    effectivePermissions
  };

  if (!includeAdminFields) {
    return masked;
  }

  return {
    ...masked,
    fatherName: rest.fatherName || '',
    motherName: rest.motherName || '',
    dob: rest.dob || '',
    email: rest.email || '',
    district: rest.district || '',
    areaType: rest.areaType || 'RURAL',
    blockOrMunicipality: rest.blockOrMunicipality || '',
    gpOrWard: rest.gpOrWard || '',
    villageOrWard: rest.villageOrWard || '',
    postOffice: rest.postOffice || '',
    policeStation: rest.policeStation || '',
    pinCode: rest.pinCode || '',
    address: rest.address || '',
    profilePhotoDocId: rest.profilePhotoDocId || '',
    supportingDocId: rest.supportingDocId || '',
    passwordChangedAt: rest.passwordChangedAt || '',
    passwordChangeCount: rest.passwordChangeCount || 0,
    passwordHistory: rest.passwordHistory || [],
    failedLoginAttempts: rest.failedLoginAttempts || 0,
    lockedUntil: rest.lockedUntil || null,
    loginCount: rest.loginCount || 0,
    approvalHistory: rest.approvalHistory || []
  };
}

function loadUsers(): UserRecord[] {
  if (!fs.existsSync(USERS_FILE)) return initializeUsers();
  try {
    return JSON.parse(fs.readFileSync(USERS_FILE, 'utf-8'));
  } catch {
    return initializeUsers();
  }
}

function saveUsers(users: UserRecord[]): void {
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
}

function initializeUsers(): UserRecord[] {
  if (fs.existsSync(USERS_FILE)) {
    try {
      const data = JSON.parse(fs.readFileSync(USERS_FILE, 'utf-8'));
      if (Array.isArray(data) && data.length > 0) {
        let changed = false;
        const normalized = data.map((u: any, idx: number) => {
          const isLegacyRoot = u.uid === 'MUNCM-2026';
          const isSuper = u.uid === SUPER_ADMIN_UID || isLegacyRoot || u.isSuperAdmin === true;
          if (isLegacyRoot) {
            u.uid = SUPER_ADMIN_UID;
            changed = true;
          }
          if (isSuper && !u.isSuperAdmin) {
            u.isSuperAdmin = true;
            u.approvalStatus = 'APPROVED';
            u.verificationStatus = 'VERIFIED';
            u.requestId = u.requestId || 'REQ-2026-000';
            changed = true;
          }
          if (!u.requestId) {
            u.requestId = `REQ-2026-${String(idx).padStart(3, '0')}`;
            changed = true;
          }
          if (!u.approvalStatus) {
            u.approvalStatus = u.status === 'ACTIVE' ? 'APPROVED' : u.status === 'REJECTED' ? 'REJECTED' : 'PENDING_APPROVAL';
            changed = true;
          }
          if (!u.verificationStatus) {
            u.verificationStatus = 'VERIFIED';
            changed = true;
          }
          return u as UserRecord;
        });
        if (changed) saveUsers(normalized);
        return normalized;
      }
    } catch (err) {
      console.error('Error loading users.json, re-initializing:', err);
    }
  }

  const initialAdmin: UserRecord = {
    requestId: 'REQ-2026-000',
    uid: SUPER_ADMIN_UID,
    name: 'Mamun Reja (Administration)',
    role: 'ADMIN',
    isSuperAdmin: true,
    designation: 'Proprietor & Chief Administrator',
    phone: '8101352105',
    phoneMasked: maskPhone('8101352105'),
    aadhaarMasked: 'XXXX-XXXX-0001',
    email: 'muncomputer2019@gmail.com',
    district: 'Murshidabad',
    areaType: 'URBAN',
    blockOrMunicipality: 'Domkal Municipality',
    gpOrWard: 'WARD 16',
    villageOrWard: 'Mamudpur (Ward 16)',
    postOffice: 'Juginda',
    pinCode: '742406',
    address: 'MUN COMPUTER, Mamudpur, Juginda, Domkal, Murshidabad - 742406',
    registrationDate: getKolkataDateParts().isoDate,
    passwordHash: bcrypt.hashSync(DEFAULT_ADMIN_PASSWORD, 10),
    mustChangePassword: false,
    dailyPasswordChangeDate: '',
    dailyPasswordChangeCount: 0,
    sessionVersion: 1,
    status: 'ACTIVE',
    approvalStatus: 'APPROVED',
    verificationStatus: 'VERIFIED',
    approvedByUid: 'SYSTEM_BOOTSTRAP',
    approvedAt: new Date().toISOString(),
    createdAt: new Date().toISOString()
  };

  const users = [initialAdmin];
  saveUsers(users);
  centralDb.logAudit('SYSTEM_INIT', `Initial Administration account provisioned: ${SUPER_ADMIN_UID}`, 'SYSTEM');
  return users;
}

// ---------------------------------------------------------------------------
// ACTOR VERIFICATION (Session Token OR Verified Active UID Header)
// ---------------------------------------------------------------------------
function resolveActor(req: Request, requireSignedToken = false): { ok: boolean; actor?: UserRecord; error?: string; code?: number } {
  const queryToken = typeof req.query?.token === 'string' ? req.query.token.trim() : '';
  const token = String(req.headers['x-session-token'] || queryToken || '').trim();
  const headerUid = String(req.headers['x-actor-uid'] || req.body?.actorUid || '').trim().toUpperCase();

  if (requireSignedToken && !token) {
    return { ok: false, code: 401, error: 'Authentication session token required. Please sign in again.' };
  }

  let targetUid = headerUid;
  let tokenSv: number | undefined;
  if (token) {
    const verified = verifySessionToken(token);
    if (!verified) {
      return { ok: false, code: 401, error: 'Session expired or invalid. Please sign in again.' };
    }
    targetUid = verified.uid.toUpperCase();
    tokenSv = verified.sv;
  }

  if (!targetUid) {
    return { ok: false, code: 401, error: 'Authentication required: Actor UID missing.' };
  }

  const users = loadUsers();
  const actor = users.find(u => u.uid && u.uid.toUpperCase() === targetUid);
  if (!actor) {
    return { ok: false, code: 401, error: 'Invalid actor account.' };
  }
  if (actor.status !== 'ACTIVE' || actor.approvalStatus !== 'APPROVED') {
    return { ok: false, code: 403, error: 'Actor account is not active or approved.' };
  }
  if (token && tokenSv !== undefined && tokenSv !== (actor.sessionVersion || 1)) {
    return { ok: false, code: 401, error: 'Session invalidated due to password change or administrative action. Please sign in again.' };
  }
  if (actor.lockedUntil && Date.parse(actor.lockedUntil) > Date.now()) {
    return { ok: false, code: 429, error: 'Account is temporarily locked due to suspicious attempts.' };
  }
  return { ok: true, actor };
}

function verifySuperAdminActor(req: Request): { ok: boolean; actor?: UserRecord; error?: string; code?: number } {
  const resolved = resolveActor(req, true);
  if (!resolved.ok || !resolved.actor) return resolved;
  const actor = resolved.actor;
  if (actor.uid !== SUPER_ADMIN_UID && actor.isSuperAdmin !== true) {
    return {
      ok: false,
      code: 403,
      error: `ACCESS DENIED: Only Administration (${SUPER_ADMIN_UID}) can perform this protected operation. Role '${actor.role}' is restricted.`
    };
  }
  return { ok: true, actor };
}

function verifyAdminActor(req: Request): { ok: boolean; actor?: UserRecord; error?: string; code?: number } {
  const resolved = resolveActor(req);
  if (!resolved.ok || !resolved.actor) return resolved;
  const actor = resolved.actor;
  if (actor.role !== 'ADMIN' && actor.uid !== SUPER_ADMIN_UID && !actor.isSuperAdmin) {
    return { ok: false, code: 403, error: `ACCESS DENIED: Administration role required.` };
  }
  return { ok: true, actor };
}

function verifyManagerOrAdminActor(req: Request): { ok: boolean; actor?: UserRecord; error?: string; code?: number } {
  const resolved = resolveActor(req);
  if (!resolved.ok || !resolved.actor) return resolved;
  const actor = resolved.actor;
  if (!['ADMIN', 'MANAGER'].includes(actor.role) && actor.uid !== SUPER_ADMIN_UID && !actor.isSuperAdmin) {
    return { ok: false, code: 403, error: `ACCESS DENIED: Manager or Administration role required.` };
  }
  return { ok: true, actor };
}

function verifyMenuPermission(
  req: Request,
  menuId: string,
  action: PermissionAction = 'view'
): { ok: boolean; actor?: UserRecord; error?: string; code?: number } {
  const resolved = resolveActor(req);
  if (!resolved.ok || !resolved.actor) return resolved;
  const actor = resolved.actor;
  if (!hasMenuPermission(actor, menuId, action)) {
    centralDb.logAudit(
      'PERMISSION_DENIED',
      `Blocked ${actor.uid} (${actor.role}) from '${menuId}.${action}' on ${req.method} ${req.path}`,
      actor.uid,
      { menuId, action, path: req.path }
    );
    return {
      ok: false,
      code: 403,
      error: `ACCESS DENIED: Your account lacks '${action}' permission for '${menuId}'.`
    };
  }
  return { ok: true, actor };
}

// ---------------------------------------------------------------------------
// SMS GATEWAY CONFIGURATION
// ---------------------------------------------------------------------------
interface SmsConfig {
  provider: 'fast2sms' | 'twilio' | 'msg91' | 'generic';
  apiKey?: string;
  senderId?: string;
  apiUrl?: string;
  accountSid?: string;
  authToken?: string;
  fromPhone?: string;
  enabled: boolean;
}

function loadSmsConfig(): SmsConfig {
  if (fs.existsSync(SMS_CONFIG_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(SMS_CONFIG_FILE, 'utf-8'));
    } catch {
      // fallback
    }
  }
  return {
    provider: 'fast2sms',
    apiKey: process.env.FAST2SMS_API_KEY || process.env.SMS_API_KEY || '',
    senderId: 'MUNCMP',
    enabled: !!(process.env.FAST2SMS_API_KEY || process.env.SMS_API_KEY || process.env.TWILIO_ACCOUNT_SID)
  };
}

function saveSmsConfig(config: SmsConfig): void {
  fs.writeFileSync(SMS_CONFIG_FILE, JSON.stringify(config, null, 2), 'utf-8');
}

interface UpiPaymentSettings {
  upiId: string;
  upiDisplayName: string;
  paymentInstructions: string;
  qrImageDataUrl: string;
  qrImageMime: string;
  qrFileName: string;
  updatedAt: string;
  updatedByUid: string;
  updatedByName: string;
}

function loadUpiSettings(): UpiPaymentSettings {
  if (fs.existsSync(UPI_SETTINGS_FILE)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(UPI_SETTINGS_FILE, 'utf-8'));
      return {
        upiId: String(parsed?.upiId || ''),
        upiDisplayName: String(parsed?.upiDisplayName || ''),
        paymentInstructions: String(parsed?.paymentInstructions || ''),
        qrImageDataUrl: String(parsed?.qrImageDataUrl || ''),
        qrImageMime: String(parsed?.qrImageMime || ''),
        qrFileName: String(parsed?.qrFileName || ''),
        updatedAt: String(parsed?.updatedAt || ''),
        updatedByUid: String(parsed?.updatedByUid || ''),
        updatedByName: String(parsed?.updatedByName || '')
      };
    } catch {
      // fallback
    }
  }
  return {
    upiId: '',
    upiDisplayName: '',
    paymentInstructions: '',
    qrImageDataUrl: '',
    qrImageMime: '',
    qrFileName: '',
    updatedAt: '',
    updatedByUid: '',
    updatedByName: ''
  };
}

function saveUpiSettings(settings: UpiPaymentSettings): void {
  fs.writeFileSync(UPI_SETTINGS_FILE, JSON.stringify(settings, null, 2), 'utf-8');
}

function isSmsGatewayConfigured(): boolean {
  const config = loadSmsConfig();
  return !!(
    (config.provider === 'fast2sms' && config.apiKey) ||
    (config.provider === 'twilio' && config.accountSid && config.authToken && config.fromPhone) ||
    (config.provider === 'msg91' && config.apiKey) ||
    (config.provider === 'generic' && config.apiUrl && config.apiKey)
  );
}

async function dispatchSms(phone: string, message: string, otp: string): Promise<{ success: boolean; message: string; provider?: string }> {
  const config = loadSmsConfig();
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const target10 = cleanPhone.length > 10 ? cleanPhone.slice(-10) : cleanPhone;

  if (target10.length !== 10) {
    return { success: false, message: 'Invalid 10-digit mobile number for SMS dispatch.' };
  }

  if (config.provider === 'fast2sms' && config.apiKey) {
    try {
      const response = await fetch('https://www.fast2sms.com/dev/bulkV2', {
        method: 'POST',
        headers: { authorization: config.apiKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({ route: 'otp', variables_values: otp, numbers: target10 })
      });
      const data = await response.json();
      if (data && (data.return === true || data.status_code === 200)) {
        return { success: true, message: `OTP delivered via Fast2SMS to +91 XXXXXX${target10.slice(-4)}`, provider: 'Fast2SMS' };
      }
      return { success: false, message: `Fast2SMS Gateway Error: ${data.message || JSON.stringify(data)}` };
    } catch (err: any) {
      return { success: false, message: `Fast2SMS Gateway Network Failure: ${err.message}` };
    }
  }

  if (config.provider === 'twilio' && config.accountSid && config.authToken && config.fromPhone) {
    try {
      const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${config.accountSid}/Messages.json`;
      const authHeader = 'Basic ' + Buffer.from(`${config.accountSid}:${config.authToken}`).toString('base64');
      const bodyParams = new URLSearchParams({ To: `+91${target10}`, From: config.fromPhone, Body: message });
      const response = await fetch(twilioUrl, {
        method: 'POST',
        headers: { Authorization: authHeader, 'Content-Type': 'application/x-www-form-urlencoded' },
        body: bodyParams.toString()
      });
      const data = await response.json();
      if (response.ok && data.sid) {
        return { success: true, message: `OTP delivered via Twilio SMS to +91 XXXXXX${target10.slice(-4)}`, provider: 'Twilio' };
      }
      return { success: false, message: `Twilio SMS Gateway Error: ${data.message || JSON.stringify(data)}` };
    } catch (err: any) {
      return { success: false, message: `Twilio SMS Gateway Network Failure: ${err.message}` };
    }
  }

  if (config.provider === 'msg91' && config.apiKey) {
    try {
      const response = await fetch(
        `https://control.msg91.com/api/v5/otp?template_id=${config.senderId || 'default'}&mobile=91${target10}&authkey=${config.apiKey}&otp=${otp}`,
        { method: 'POST', headers: { 'Content-Type': 'application/json' } }
      );
      const data = await response.json();
      if (data && data.type === 'success') {
        return { success: true, message: `OTP delivered via MSG91 to +91 XXXXXX${target10.slice(-4)}`, provider: 'MSG91' };
      }
      return { success: false, message: `MSG91 Gateway Error: ${data.message || JSON.stringify(data)}` };
    } catch (err: any) {
      return { success: false, message: `MSG91 Gateway Network Failure: ${err.message}` };
    }
  }

  if (config.provider === 'generic' && config.apiUrl && config.apiKey) {
    try {
      const response = await fetch(config.apiUrl, {
        method: 'POST',
        headers: { Authorization: `Bearer ${config.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: `91${target10}`, otp, message })
      });
      const data = await response.json();
      if (response.ok) {
        return { success: true, message: `OTP dispatched via Custom SMS Gateway to +91 XXXXXX${target10.slice(-4)}`, provider: 'Custom Webhook' };
      }
      return { success: false, message: `Custom SMS Gateway Error: ${JSON.stringify(data)}` };
    } catch (err: any) {
      return { success: false, message: `Custom SMS Gateway Error: ${err.message}` };
    }
  }

  return {
    success: false,
    message: 'Live SMS Gateway is not yet configured with an active provider (Fast2SMS / Twilio / MSG91).'
  };
}

// ---------------------------------------------------------------------------
// CORE HEALTH & COUNTERS API
// ---------------------------------------------------------------------------
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    app: 'MUN COMPUTER — CENTRAL AUTHORITY (MUNCOMPUTER-2019)',
    smsConfigured: isSmsGatewayConfigured(),
    year: new Date().getFullYear(),
    counters: centralDb.getCurrentCounters(),
    time: new Date().toISOString()
  });
});

app.get('/api/counters', (req, res) => {
  res.json({ success: true, counters: centralDb.getCurrentCounters(), year: new Date().getFullYear() });
});

// ---------------------------------------------------------------------------
// 3-PANEL AUTHENTICATION, REGISTRATION, VERHOEFF AADHAAR & 6-STEP NO-OTP FORGOT PASSWORD
// ---------------------------------------------------------------------------
app.get('/api/auth/id-preview', (req, res) => {
  const role = String(req.query.role || 'STAFF').toUpperCase();
  const preview = getIdFormatPreview(role);
  res.json({ success: true, ...preview });
});

app.get('/api/auth/captcha', (req, res) => {
  const { svg, captchaToken } = generateCaptchaChallenge();
  res.json({ success: true, svg, captchaToken });
});

app.get('/api/auth/session', (req, res) => {
  const resolved = resolveActor(req, true);
  if (!resolved.ok || !resolved.actor) {
    return res.status(resolved.code || 401).json({ success: false, message: resolved.error || 'Session invalid.' });
  }
  res.json({ success: true, user: sanitizeUserForResponse(resolved.actor, true) });
});

app.post('/api/auth/login', (req, res) => {
  const { uid, password, panelRole, captchaToken, captchaInput } = req.body || {};

  if (!uid || !password) {
    return res.status(400).json({ success: false, message: 'Please provide both User ID and Password.' });
  }

  const ipRate = checkRateLimit(`login_ip_${req.ip}`, 30, 15 * 60 * 1000);
  if (!ipRate.allowed) {
    return res.status(429).json({
      success: false,
      message: 'Too many login requests from this device. Please wait 15 minutes.'
    });
  }

  if (!captchaToken || !captchaInput) {
    return res.status(400).json({ success: false, message: 'CAPTCHA verification is required.' });
  }

  if (!verifyCaptchaChallenge(String(captchaToken), String(captchaInput))) {
    return res.status(400).json({
      success: false,
      captchaError: true,
      message: 'Incorrect or expired CAPTCHA code. Please refresh and try again.'
    });
  }

  const cleanUid = String(uid).trim().toUpperCase();
  const users = loadUsers();
  const user = users.find(
    u => (u.uid && u.uid.toUpperCase() === cleanUid) || (u.requestId && u.requestId.toUpperCase() === cleanUid)
  );

  if (!user) {
    centralDb.logAudit('AUTH_LOGIN_FAILED', `Failed login attempt for unknown UID: ${cleanUid} via ${panelRole || 'CENTRAL'} panel.`, cleanUid, {
      panel: panelRole || 'CENTRAL',
      ip: req.ip
    });
    return res.status(401).json({
      success: false,
      message: 'Invalid User ID or Password. Only Administration-approved permanent UIDs can sign in.'
    });
  }

  if (user.lockedUntil && Date.parse(user.lockedUntil) > Date.now()) {
    const minsLeft = Math.max(1, Math.ceil((Date.parse(user.lockedUntil) - Date.now()) / 60000));
    centralDb.logAudit('AUTH_LOGIN_LOCKED', `Blocked login attempt on locked account ${user.uid || user.requestId}.`, user.uid || user.requestId);
    return res.status(429).json({
      success: false,
      lockedUntil: user.lockedUntil,
      message: `Account temporarily locked due to multiple failed login attempts. Try again in ${minsLeft} minute(s) or contact Administration.`
    });
  }

  if (user.status === 'PENDING_APPROVAL' || user.approvalStatus === 'PENDING_APPROVAL' || !user.uid) {
    return res.status(403).json({
      success: false,
      message: `Registration (${user.requestId}) is PENDING ADMINISTRATION APPROVAL. No login access or permanent UID before approval.`
    });
  }

  if (user.status === 'REJECTED' || user.approvalStatus === 'REJECTED') {
    return res.status(403).json({
      success: false,
      message: `This registration was REJECTED by Administration${user.decisionNotes ? `: ${user.decisionNotes}` : '.'}`
    });
  }

  if (user.status === 'CORRECTION_REQUIRED' || user.approvalStatus === 'CORRECTION_REQUIRED') {
    return res.status(403).json({
      success: false,
      message: `Account requires correction before approval: ${user.decisionNotes || 'Contact Administration.'}`
    });
  }

  if (user.status === 'SUSPENDED') {
    return res.status(403).json({
      success: false,
      message: 'This account has been SUSPENDED by Administration. Login is disabled.'
    });
  }

  if (user.approvalStatus !== 'APPROVED' && user.uid !== SUPER_ADMIN_UID) {
    return res.status(403).json({ success: false, message: 'Account lacks Administration approval.' });
  }

  // Enforce strict 3-panel boundary (ADMINISTRATION / MANAGER / STAFF)
  if (panelRole) {
    const panel = String(panelRole).toUpperCase();
    const displayRole = user.role === 'ADMIN' ? 'ADMINISTRATION' : user.role;
    if ((panel === 'ADMIN' || panel === 'ADMINISTRATION') && user.role !== 'ADMIN' && !user.isSuperAdmin) {
      return res.status(403).json({
        success: false,
        message: `Access Denied for ADMINISTRATION: Account ${user.uid} holds role '${displayRole}'. Use ${user.role === 'MANAGER' ? 'MANAGER LOGIN' : 'STAFF LOGIN'}.`
      });
    }
    if (panel === 'MANAGER' && user.role !== 'MANAGER' && user.role !== 'ADMIN' && !user.isSuperAdmin) {
      return res.status(403).json({
        success: false,
        message: `Access Denied for MANAGER LOGIN: Account ${user.uid} holds role '${displayRole}'. Use STAFF LOGIN.`
      });
    }
    if (panel === 'STAFF' && !['STAFF', 'MAKER', 'CHECKER'].includes(user.role)) {
      return res.status(403).json({
        success: false,
        message: `Access Denied for STAFF LOGIN: Account ${user.uid} holds role '${displayRole}'. Use ${user.role === 'ADMIN' ? 'ADMINISTRATION' : 'MANAGER LOGIN'}.`
      });
    }
  }

  const isMatch = bcrypt.compareSync(String(password).trim(), user.passwordHash);
  if (!isMatch) {
    const nextFails = (user.failedLoginAttempts || 0) + 1;
    user.failedLoginAttempts = nextFails;
    if (nextFails >= 5) {
      user.lockedUntil = new Date(Date.now() + 15 * 60 * 1000).toISOString();
      user.failedLoginAttempts = 0;
      saveUsers(users);
      centralDb.logAudit('ACCOUNT_LOCKED', `Account ${user.uid} temporarily locked for 15 minutes after 5 failed password attempts.`, user.uid, {
        panel: panelRole || 'CENTRAL',
        ip: req.ip
      });
      return res.status(429).json({
        success: false,
        lockedUntil: user.lockedUntil,
        message: 'Account temporarily locked for 15 minutes after 5 failed login attempts.'
      });
    }
    saveUsers(users);
    centralDb.logAudit('AUTH_LOGIN_FAILED', `Invalid password attempt (${nextFails}/5) for ${user.uid} via ${panelRole || 'CENTRAL'} panel.`, user.uid, {
      panel: panelRole || 'CENTRAL'
    });
    return res.status(401).json({
      success: false,
      remainingAttempts: 5 - nextFails,
      message: `Invalid password for User ID ${user.uid}. ${5 - nextFails} attempt(s) remaining before temporary lockout.`
    });
  }

  user.failedLoginAttempts = 0;
  user.lockedUntil = null;
  user.lastLoginAt = new Date().toISOString();
  user.lastLoginPanel = String(panelRole || 'CENTRAL').toUpperCase();
  user.loginCount = (user.loginCount || 0) + 1;
  user.sessionVersion = user.sessionVersion || 1;
  saveUsers(users);

  centralDb.logAudit('AUTH_LOGIN', `User ${user.name} (${user.uid} - ${user.role}) signed in via ${user.lastLoginPanel} panel.`, user.uid, {
    panel: user.lastLoginPanel,
    role: user.role,
    userName: user.name
  });

  const sessionToken = issueSessionToken({
    uid: user.uid,
    role: user.role,
    isSuperAdmin: user.uid === SUPER_ADMIN_UID || user.isSuperAdmin,
    sessionVersion: user.sessionVersion
  });

  res.json({
    success: true,
    message: user.mustChangePassword
      ? 'Login successful. Temporary password detected — password change required.'
      : `Welcome back, ${user.name}!`,
    user: sanitizeUserForResponse(user, true),
    sessionToken,
    mustChangePassword: user.mustChangePassword
  });
});

app.post('/api/auth/change-password', (req, res) => {
  const { uid, currentPassword, newPassword, confirmPassword } = req.body || {};

  if (!uid || !currentPassword || !newPassword) {
    return res.status(400).json({ success: false, message: 'All password fields are required.' });
  }
  if (newPassword !== confirmPassword) {
    return res.status(400).json({ success: false, message: 'New password and confirmation do not match.' });
  }

  const users = loadUsers();
  const cleanUid = String(uid).trim().toUpperCase();
  const user = users.find(u => u.uid && u.uid.toUpperCase() === cleanUid);

  if (!user) return res.status(404).json({ success: false, message: 'User account not found.' });
  if (user.status !== 'ACTIVE' || user.approvalStatus !== 'APPROVED') {
    return res.status(403).json({ success: false, message: 'Only Administration approved active accounts can update passwords.' });
  }

  const MAX_DAILY_PASSWORD_CHANGES = 5;
  const todayIst = getKolkataDateParts().isoDate;
  const usedToday = user.dailyPasswordChangeDate === todayIst ? Number(user.dailyPasswordChangeCount || 0) : 0;
  if (usedToday >= MAX_DAILY_PASSWORD_CHANGES) {
    return res.status(429).json({
      success: false,
      dailyLimit: MAX_DAILY_PASSWORD_CHANGES,
      dailyChangesUsed: usedToday,
      remainingChangesToday: 0,
      message: `Daily password change limit reached (${MAX_DAILY_PASSWORD_CHANGES}/${MAX_DAILY_PASSWORD_CHANGES} changes used today). Please try again tomorrow.`
    });
  }

  const strength = validatePasswordStrength(String(newPassword), {
    uid: user.uid,
    name: user.name,
    phone: user.phone,
    dob: user.dob
  });
  if (!strength.valid) {
    return res.status(400).json({ success: false, message: strength.reason });
  }

  const isCurrentValid = bcrypt.compareSync(String(currentPassword).trim(), user.passwordHash);
  if (!isCurrentValid) {
    return res.status(401).json({ success: false, message: 'Current password verification failed.' });
  }
  if (bcrypt.compareSync(String(newPassword), user.passwordHash)) {
    return res.status(400).json({ success: false, message: 'New password must be different from your current password.' });
  }

  const now = new Date().toISOString();
  const nextDailyCount = usedToday + 1;
  user.passwordHash = bcrypt.hashSync(String(newPassword), 10);
  user.mustChangePassword = false;
  user.passwordChangedAt = now;
  user.passwordChangeCount = (user.passwordChangeCount || 0) + 1;
  user.dailyPasswordChangeDate = todayIst;
  user.dailyPasswordChangeCount = nextDailyCount;
  user.passwordHistory = Array.isArray(user.passwordHistory) ? user.passwordHistory : [];
  user.passwordHistory.unshift({ changedAt: now, method: 'USER_PASSWORD_CHANGE' });
  if (user.passwordHistory.length > 20) user.passwordHistory.length = 20;
  user.sessionVersion = (user.sessionVersion || 1) + 1;
  saveUsers(users);

  centralDb.logAudit(
    'PASSWORD_CHANGE',
    `User ${user.name} (${user.uid}) updated password securely (${nextDailyCount}/${MAX_DAILY_PASSWORD_CHANGES} daily changes used).`,
    user.uid
  );

  const sessionToken = issueSessionToken({
    uid: user.uid,
    role: user.role,
    isSuperAdmin: user.uid === SUPER_ADMIN_UID || user.isSuperAdmin,
    sessionVersion: user.sessionVersion
  });

  const remainingToday = Math.max(0, MAX_DAILY_PASSWORD_CHANGES - nextDailyCount);
  res.json({
    success: true,
    message: `Password updated successfully! (${remainingToday} of ${MAX_DAILY_PASSWORD_CHANGES} daily changes remaining today.)`,
    user: sanitizeUserForResponse(user, true),
    sessionToken,
    dailyLimit: MAX_DAILY_PASSWORD_CHANGES,
    dailyChangesUsed: nextDailyCount,
    remainingChangesToday: remainingToday
  });
});

// ---------------------------------------------------------------------------
// SEPARATE 6-STEP FORGOT PASSWORD API (STRICTLY NO OTP — LOCAL IDENTITY MATCH)
// Step 1: User ID + CAPTCHA verification
// Step 2: Registered Mobile Number + 12-Digit Aadhaar identity match
// Step 3: Strong Password Reset + Session Invalidation + Audit Log
// ---------------------------------------------------------------------------
app.post('/api/auth/forgot/verify-step1', (req, res) => {
  const { uid, captchaToken, captchaInput } = req.body || {};
  const cleanUid = String(uid || '').trim().toUpperCase();

  const rl = checkRateLimit(`forgot_step1_${req.ip}_${cleanUid || 'ANON'}`, 10, 15 * 60 * 1000);
  if (!rl.allowed) {
    return res.status(429).json({
      success: false,
      message: 'Too many password recovery attempts. Please wait 15 minutes before trying again.'
    });
  }

  if (!cleanUid) {
    return res.status(400).json({ success: false, message: 'Step 1: Please enter your permanent User ID.' });
  }
  if (!captchaToken || !captchaInput || !verifyCaptchaChallenge(String(captchaToken), String(captchaInput))) {
    return res.status(400).json({
      success: false,
      captchaError: true,
      message: 'Step 2: Incorrect or expired CAPTCHA code. Please refresh and enter again.'
    });
  }

  const users = loadUsers();
  const user = users.find(u => u.uid && u.uid.toUpperCase() === cleanUid);
  if (!user || user.status !== 'ACTIVE' || user.approvalStatus !== 'APPROVED') {
    centralDb.logAudit('FORGOT_STEP1_FAILED', `Password recovery lookup rejected for User ID: ${cleanUid}.`, cleanUid || 'ANON');
    return res.status(404).json({
      success: false,
      message: 'No active approved account found for this User ID.'
    });
  }

  if (user.lockedUntil && Date.parse(user.lockedUntil) > Date.now()) {
    const minsLeft = Math.max(1, Math.ceil((Date.parse(user.lockedUntil) - Date.now()) / 60000));
    return res.status(429).json({
      success: false,
      lockedUntil: user.lockedUntil,
      message: `Account is temporarily locked for ${minsLeft} more minute(s) due to excess failed attempts.`
    });
  }

  const stepToken = issueForgotStepToken(user.uid, 'STEP1');
  res.json({
    success: true,
    stepToken,
    uid: user.uid,
    message: 'User ID and CAPTCHA verified. Enter your registered Mobile Number and 12-digit Aadhaar Number for identity verification.'
  });
});

app.post('/api/auth/forgot/verify-identity', (req, res) => {
  const { stepToken, phone, aadhaarNumber } = req.body || {};
  const step = verifyForgotStepToken(String(stepToken || ''), 'STEP1');
  if (!step) {
    return res.status(403).json({
      success: false,
      message: 'Recovery session expired or invalid. Please restart from Step 1 (User ID & CAPTCHA).'
    });
  }

  const users = loadUsers();
  const user = users.find(u => u.uid && u.uid.toUpperCase() === step.uid.toUpperCase());
  if (!user || user.status !== 'ACTIVE' || user.approvalStatus !== 'APPROVED') {
    return res.status(403).json({ success: false, message: 'Account is not active or approved.' });
  }

  if (user.lockedUntil && Date.parse(user.lockedUntil) > Date.now()) {
    const minsLeft = Math.max(1, Math.ceil((Date.parse(user.lockedUntil) - Date.now()) / 60000));
    return res.status(429).json({
      success: false,
      lockedUntil: user.lockedUntil,
      message: `Account locked due to too many failed verification attempts. Try again in ${minsLeft} minute(s).`
    });
  }

  const rl = checkRateLimit(`forgot_identity_${user.uid}_${req.ip}`, 8, 15 * 60 * 1000);
  if (!rl.allowed) {
    return res.status(429).json({
      success: false,
      message: 'Too many identity verification attempts. Please wait 15 minutes.'
    });
  }

  const inputPhone10 = String(phone || '').replace(/[^0-9]/g, '').slice(-10);
  const inputAadhaar12 = String(aadhaarNumber || '').replace(/[^0-9]/g, '');

  if (inputPhone10.length !== 10) {
    return res.status(400).json({ success: false, message: 'Enter a valid 10-digit registered Mobile Number.' });
  }
  if (inputAadhaar12.length !== 12) {
    return res.status(400).json({ success: false, message: 'Enter a valid 12-digit registered Aadhaar Number.' });
  }

  if (!user.aadhaarHash && !user.aadhaarEncrypted) {
    return res.status(400).json({
      success: false,
      message: 'Encrypted Aadhaar identity record is not on file for this legacy bootstrap account. Contact Administration.'
    });
  }

  const userPhone10 = String(user.phone || '').replace(/[^0-9]/g, '').slice(-10);
  const phoneMatched = userPhone10.length === 10 && inputPhone10 === userPhone10;

  let aadhaarMatched = false;
  if (user.aadhaarHash) {
    const inputHash = hashSensitive(inputAadhaar12);
    const aBuf = Buffer.from(inputHash);
    const bBuf = Buffer.from(user.aadhaarHash);
    aadhaarMatched = aBuf.length === bBuf.length && crypto.timingSafeEqual(aBuf, bBuf);
  }
  if (!aadhaarMatched && user.aadhaarEncrypted) {
    const decrypted = decryptSensitive(user.aadhaarEncrypted);
    if (decrypted && decrypted === inputAadhaar12) {
      aadhaarMatched = true;
    }
  }

  if (!phoneMatched || !aadhaarMatched) {
    const nextFails = (user.failedResetAttempts || 0) + 1;
    user.failedResetAttempts = nextFails;
    if (nextFails >= 5) {
      user.lockedUntil = new Date(Date.now() + 15 * 60 * 1000).toISOString();
      user.failedResetAttempts = 0;
      saveUsers(users);
      centralDb.logAudit('FORGOT_PASSWORD_LOCKOUT', `Account ${user.uid} locked for 15 minutes after 5 failed identity-match reset attempts.`, user.uid);
      return res.status(429).json({
        success: false,
        lockedUntil: user.lockedUntil,
        message: 'Account temporarily locked for 15 minutes after 5 failed Mobile/Aadhaar verification attempts.'
      });
    }
    saveUsers(users);
    centralDb.logAudit('PASSWORD_RESET_IDENTITY_FAILED', `Identity-match verification failed (${nextFails}/5) for ${user.uid}.`, user.uid);
    return res.status(403).json({
      success: false,
      remainingAttempts: 5 - nextFails,
      message: `Identity mismatch: Registered Mobile Number and Aadhaar Number do not match our records. ${5 - nextFails} attempt(s) remaining.`
    });
  }

  user.failedResetAttempts = 0;
  saveUsers(users);
  centralDb.logAudit('PASSWORD_RESET_IDENTITY_VERIFIED', `Local identity match succeeded for ${user.uid} (UID + CAPTCHA + Mobile + Aadhaar).`, user.uid);

  const resetToken = issueForgotStepToken(user.uid, 'IDENTITY_VERIFIED');
  res.json({
    success: true,
    resetToken,
    uid: user.uid,
    message: 'All 4 identity checks matched. You may now set your new password.'
  });
});

app.post('/api/auth/forgot/reset-password', (req, res) => {
  const { resetToken, newPassword, confirmPassword } = req.body || {};
  const verified = verifyForgotStepToken(String(resetToken || ''), 'IDENTITY_VERIFIED');
  if (!verified) {
    return res.status(403).json({
      success: false,
      message: 'Verification required: All 4 checks (User ID, CAPTCHA, Mobile Number, Aadhaar Number) must match before resetting password.'
    });
  }

  if (!newPassword || !confirmPassword) {
    return res.status(400).json({ success: false, message: 'New Password and Confirm New Password are required.' });
  }
  if (newPassword !== confirmPassword) {
    return res.status(400).json({ success: false, message: 'New Password and Confirm New Password do not match.' });
  }

  const users = loadUsers();
  const user = users.find(u => u.uid && u.uid.toUpperCase() === verified.uid.toUpperCase());
  if (!user || user.status !== 'ACTIVE' || user.approvalStatus !== 'APPROVED') {
    return res.status(403).json({ success: false, message: 'Account is not active or approved.' });
  }

  const strength = validatePasswordStrength(String(newPassword), {
    uid: user.uid,
    name: user.name,
    phone: user.phone,
    dob: user.dob
  });
  if (!strength.valid) {
    return res.status(400).json({ success: false, message: strength.reason });
  }

  if (bcrypt.compareSync(String(newPassword), user.passwordHash)) {
    return res.status(400).json({ success: false, message: 'New password cannot be the same as your previous password.' });
  }

  const now = new Date().toISOString();
  user.passwordHash = bcrypt.hashSync(String(newPassword), 10);
  user.mustChangePassword = false;
  user.passwordChangedAt = now;
  user.passwordChangeCount = (user.passwordChangeCount || 0) + 1;
  user.passwordHistory = Array.isArray(user.passwordHistory) ? user.passwordHistory : [];
  user.passwordHistory.unshift({ changedAt: now, method: 'IDENTITY_MATCH_RESET' });
  if (user.passwordHistory.length > 20) user.passwordHistory.length = 20;
  // Invalidate ALL active existing sessions for this user immediately
  user.sessionVersion = (user.sessionVersion || 1) + 1;
  saveUsers(users);

  centralDb.logAudit('PASSWORD_RESET', `Password reset completed via verified identity match for ${user.name} (${user.uid}). Active sessions invalidated.`, user.uid);

  res.json({
    success: true,
    uid: user.uid,
    title: 'PASSWORD RESET SUCCESSFUL!',
    message: 'Your password has been changed successfully. Please log in with your new password.'
  });
});

// Registration endpoints
function handleUserRegistration(req: Request, res: Response) {
  const {
    fullName,
    name,
    fatherName,
    motherName,
    dob,
    role,
    requestedRole,
    phone,
    aadhaarNumber,
    aadhaar,
    designation,
    email,
    district,
    areaType,
    blockOrMunicipality,
    gpOrWard,
    villageOrWard,
    villageOrLocality,
    postOffice,
    policeStation,
    pinCode,
    address,
    profilePhoto,
    supportingDocument
  } = req.body || {};

  const applicantName = String(fullName || name || '').trim();
  const cleanFather = String(fatherName || '').trim();
  const cleanMother = String(motherName || '').trim();
  const cleanDob = String(dob || '').trim();
  const cleanEmail = String(email || '').trim();
  const phone10 = String(phone || '').replace(/[^0-9]/g, '').slice(-10);
  const rawAadhaar = String(aadhaarNumber || aadhaar || '').replace(/[^0-9]/g, '');

  const rawRole = String(requestedRole || role || 'STAFF').trim().toUpperCase();
  const allowedRoles: AppRole[] = ['ADMIN', 'MANAGER', 'MAKER', 'CHECKER', 'STAFF'];
  const normalizedRole: AppRole = allowedRoles.includes(rawRole as AppRole) ? (rawRole as AppRole) : 'STAFF';

  if (!applicantName || phone10.length !== 10) {
    return res.status(400).json({ success: false, message: 'Full Name and valid 10-digit Mobile Number are required.' });
  }

  if (!cleanFather || !cleanMother || !cleanDob) {
    return res.status(400).json({
      success: false,
      message: "Father's Name, Mother's Name, and Date of Birth are mandatory for registration."
    });
  }

  if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
    return res.status(400).json({ success: false, message: 'Valid Email Address is required.' });
  }

  const aadhaarCheck = validateVerhoeffAadhaar(rawAadhaar);
  if (!aadhaarCheck.valid) {
    return res.status(400).json({
      success: false,
      message: aadhaarCheck.reason || 'Valid 12-digit Aadhaar Number (Verhoeff verified) is mandatory.'
    });
  }

  const cleanPin = String(pinCode || '').replace(/[^0-9]/g, '').slice(0, 6);
  if (!district || !blockOrMunicipality || cleanPin.length !== 6) {
    return res.status(400).json({
      success: false,
      message: 'District, Block / Municipality, and 6-digit PIN Code are required.'
    });
  }

  const users = loadUsers();
  const aadhaarDigest = hashSensitive(aadhaarCheck.clean);
  const duplicate = users.find(u => {
    if (u.status === 'REJECTED') return false;
    const samePhone = String(u.phone || '').replace(/[^0-9]/g, '').slice(-10) === phone10;
    const sameAadhaar = u.aadhaarHash && u.aadhaarHash === aadhaarDigest;
    return samePhone || sameAadhaar;
  });

  if (duplicate) {
    return res.status(409).json({
      success: false,
      message: 'Duplicate account prevented: An application or active account already exists with this Mobile Number or Aadhaar Number.'
    });
  }

  const requestId = centralDb.generateNextId('REQ');
  const ist = getKolkataDateParts();
  const nowIso = new Date().toISOString();

  let profilePhotoDocId = '';
  if (profilePhoto && profilePhoto.base64Data && profilePhoto.mimeType) {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(profilePhoto.mimeType)) {
      return res.status(400).json({ success: false, message: 'Profile photo must be JPG, PNG, or WEBP.' });
    }
    const savedPhoto = centralDb.saveUploadedDocument({
      title: `Profile Photo — ${applicantName}`,
      category: 'USER_PROFILE_PHOTO',
      userId: requestId,
      fileName: String(profilePhoto.fileName || `${requestId}_photo.jpg`),
      mimeType: String(profilePhoto.mimeType),
      base64Data: String(profilePhoto.base64Data),
      actorUid: requestId
    });
    if (!savedPhoto.success) {
      return res.status(400).json({ success: false, message: savedPhoto.message });
    }
    profilePhotoDocId = savedPhoto.document?.id || '';
  }

  let supportingDocId = '';
  if (supportingDocument && supportingDocument.base64Data && supportingDocument.mimeType) {
    const savedDoc = centralDb.saveUploadedDocument({
      title: `KYC Document — ${applicantName}`,
      category: 'USER_KYC_DOCUMENT',
      userId: requestId,
      fileName: String(supportingDocument.fileName || `${requestId}_kyc.pdf`),
      mimeType: String(supportingDocument.mimeType),
      base64Data: String(supportingDocument.base64Data),
      actorUid: requestId
    });
    if (!savedDoc.success) {
      return res.status(400).json({ success: false, message: savedDoc.message });
    }
    supportingDocId = savedDoc.document?.id || '';
  }

  const newUserRequest: UserRecord = {
    requestId,
    uid: '', // Assigned atomically ONLY after Super Admin approval
    name: applicantName,
    fatherName: cleanFather,
    motherName: cleanMother,
    dob: cleanDob,
    role: normalizedRole,
    isSuperAdmin: false,
    designation: String(designation || normalizedRole).trim(),
    phone: phone10,
    phoneMasked: maskPhone(phone10),
    aadhaarMasked: maskAadhaar(aadhaarCheck.clean),
    aadhaarEncrypted: encryptSensitive(aadhaarCheck.clean),
    aadhaarHash: aadhaarDigest,
    email: cleanEmail,
    district: String(district).trim(),
    areaType: areaType === 'URBAN' ? 'URBAN' : 'RURAL',
    blockOrMunicipality: String(blockOrMunicipality).trim(),
    gpOrWard: String(gpOrWard || '').trim(),
    villageOrWard: String(villageOrLocality || villageOrWard || gpOrWard || '').trim(),
    postOffice: String(postOffice || '').trim(),
    policeStation: String(policeStation || '').trim(),
    pinCode: cleanPin,
    address: String(address || '').trim(),
    profilePhotoDocId: profilePhotoDocId || undefined,
    supportingDocId: supportingDocId || undefined,
    registrationDate: ist.isoDate,
    passwordHash: bcrypt.hashSync(crypto.randomBytes(24).toString('hex'), 8),
    mustChangePassword: true,
    sessionVersion: 1,
    status: 'PENDING_APPROVAL',
    approvalStatus: 'PENDING_APPROVAL',
    verificationStatus: 'AADHAAR_VERHOEFF_VERIFIED',
    createdAt: nowIso,
    approvalHistory: [
      {
        timestamp: nowIso,
        action: 'REGISTRATION_SUBMITTED',
        actorUid: requestId,
        notes: `Submitted for ${normalizedRole} role (Asia/Kolkata ${ist.isoDate}).`
      }
    ]
  };

  users.push(newUserRequest);
  saveUsers(users);

  centralDb.logAudit(
    'USER_REGISTRATION_SUBMITTED',
    `New ${normalizedRole} registration submitted: ${applicantName} (Request ID: ${requestId}, Masked Aadhaar: ${newUserRequest.aadhaarMasked}). Status: PENDING SUPER ADMIN APPROVAL.`,
    requestId,
    { requestId, decision: 'PENDING_APPROVAL', requestedRole: normalizedRole }
  );

  res.json({
    success: true,
    message: `Registration submitted under Request ID ${requestId}. Status is PENDING SUPER ADMIN APPROVAL.`,
    requestId,
    requestedRole: normalizedRole,
    idFormatPreview: getIdFormatPreview(normalizedRole).formatPreview,
    verificationStatus: newUserRequest.verificationStatus,
    approvalStatus: 'PENDING_APPROVAL',
    requiresApproval: true,
    user: sanitizeUserForResponse(newUserRequest, true)
  });
}

app.post('/api/auth/register', handleUserRegistration);
app.post('/api/auth/register-staff', handleUserRegistration);

// ---------------------------------------------------------------------------
// USER MANAGEMENT & SUPER ADMIN APPROVAL PANEL
// ---------------------------------------------------------------------------
function computeUserStats(users: UserRecord[]) {
  return {
    totalUsers: users.length,
    activeUsers: users.filter(u => u.status === 'ACTIVE').length,
    pendingRegistrations: users.filter(u => u.status === 'PENDING_APPROVAL' || u.status === 'CORRECTION_REQUIRED').length,
    approvedUsers: users.filter(u => u.approvalStatus === 'APPROVED').length,
    rejectedRegistrations: users.filter(u => u.status === 'REJECTED').length,
    suspendedUsers: users.filter(u => u.status === 'SUSPENDED').length,
    adminCount: users.filter(u => u.role === 'ADMIN' && u.status !== 'REJECTED').length,
    managerCount: users.filter(u => u.role === 'MANAGER' && u.status !== 'REJECTED').length,
    staffCount: users.filter(u => ['STAFF', 'MAKER', 'CHECKER'].includes(u.role) && u.status !== 'REJECTED').length
  };
}

app.get('/api/users', (req, res) => {
  const users = loadUsers();
  const resolved = resolveActor(req);
  const isPrivileged = Boolean(resolved.ok && resolved.actor && (resolved.actor.role === 'ADMIN' || resolved.actor.isSuperAdmin));

  const q = String(req.query.q || '').trim().toLowerCase();
  let filtered = users;
  if (q) {
    filtered = users.filter(u =>
      [u.uid, u.requestId, u.name, u.role, u.status, u.phoneMasked, u.district, u.blockOrMunicipality]
        .some(v => String(v || '').toLowerCase().includes(q))
    );
  }

  const recentLogins = centralDb
    .loadAuditLogs()
    .filter(l => ['AUTH_LOGIN', 'AUTH_LOGIN_FAILED', 'ACCOUNT_LOCKED', 'PASSWORD_RESET', 'PASSWORD_CHANGE'].includes(l.action))
    .slice(0, 25);

  res.json({
    success: true,
    users: filtered.map(u => sanitizeUserForResponse(u, isPrivileged)),
    stats: computeUserStats(users),
    recentLogins
  });
});

app.get('/api/users/dashboard-stats', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) {
    return res.status(auth.code || 403).json({ success: false, message: auth.error });
  }
  const users = loadUsers();
  const recentLogins = centralDb
    .loadAuditLogs()
    .filter(l => ['AUTH_LOGIN', 'AUTH_LOGIN_FAILED', 'ACCOUNT_LOCKED', 'PASSWORD_RESET', 'PASSWORD_CHANGE'].includes(l.action))
    .slice(0, 25);
  res.json({
    success: true,
    stats: computeUserStats(users),
    recentLogins,
    idPreviews: {
      ADMIN: getIdFormatPreview('ADMIN'),
      MANAGER: getIdFormatPreview('MANAGER'),
      STAFF: getIdFormatPreview('STAFF')
    }
  });
});

app.post('/api/users/create', (req, res) => {
  const actorRes = verifyAdminActor(req);
  if (!actorRes.ok || !actorRes.actor) {
    return res.status(actorRes.code || 403).json({ success: false, message: actorRes.error || 'Admin authentication required.' });
  }
  const actorUid = actorRes.actor.uid;

  const {
    name,
    fatherName,
    motherName,
    dob,
    role,
    designation,
    phone,
    aadhaarNumber,
    aadhaar,
    email,
    district,
    areaType,
    blockOrMunicipality,
    gpOrWard,
    villageOrWard,
    villageOrLocality,
    postOffice,
    policeStation,
    pinCode,
    address
  } = req.body || {};

  if (!name || !role) return res.status(400).json({ success: false, message: 'Applicant Name and Requested Role are required.' });

  const allowedRoles: AppRole[] = ['ADMIN', 'MANAGER', 'MAKER', 'CHECKER', 'STAFF'];
  const rawRole = String(role).trim().toUpperCase();
  const targetRole: AppRole = allowedRoles.includes(rawRole as AppRole) ? (rawRole as AppRole) : 'STAFF';

  const phone10 = phone ? String(phone).replace(/[^0-9]/g, '').slice(-10) : '';
  if (phone10.length !== 10) {
    return res.status(400).json({ success: false, message: 'Valid 10-digit Mobile Number is required.' });
  }

  const cleanAadhaar = String(aadhaarNumber || aadhaar || '').replace(/[^0-9]/g, '');
  const aadhaarCheck = validateVerhoeffAadhaar(cleanAadhaar);
  if (!aadhaarCheck.valid) {
    return res.status(400).json({ success: false, message: aadhaarCheck.reason || 'Valid 12-digit Verhoeff-verified Aadhaar is required.' });
  }

  const users = loadUsers();
  const aadhaarHash = hashSensitive(aadhaarCheck.clean);
  const duplicate = users.find(u => {
    if (u.status === 'REJECTED') return false;
    const samePhone = String(u.phone || '').replace(/[^0-9]/g, '').slice(-10) === phone10;
    const sameAadhaar = u.aadhaarHash && u.aadhaarHash === aadhaarHash;
    return samePhone || sameAadhaar;
  });
  if (duplicate) {
    return res.status(409).json({ success: false, message: 'Duplicate account prevented: Mobile or Aadhaar already registered.' });
  }

  const requestId = centralDb.generateNextId('REQ');
  const ist = getKolkataDateParts();
  const nowIso = new Date().toISOString();

  const newUser: UserRecord = {
    requestId,
    uid: '',
    name: String(name).trim(),
    fatherName: String(fatherName || '').trim(),
    motherName: String(motherName || '').trim(),
    dob: String(dob || '').trim(),
    role: targetRole,
    isSuperAdmin: false,
    designation: String(designation || targetRole).trim(),
    phone: phone10,
    phoneMasked: maskPhone(phone10),
    aadhaarMasked: maskAadhaar(aadhaarCheck.clean),
    aadhaarEncrypted: encryptSensitive(aadhaarCheck.clean),
    aadhaarHash,
    email: email ? String(email).trim() : '',
    district: district ? String(district).trim() : 'Murshidabad',
    areaType: areaType === 'URBAN' ? 'URBAN' : 'RURAL',
    blockOrMunicipality: blockOrMunicipality ? String(blockOrMunicipality).trim() : '',
    gpOrWard: gpOrWard ? String(gpOrWard).trim() : '',
    villageOrWard: String(villageOrLocality || villageOrWard || '').trim(),
    postOffice: String(postOffice || '').trim(),
    policeStation: String(policeStation || '').trim(),
    pinCode: pinCode ? String(pinCode).replace(/[^0-9]/g, '').slice(0, 6) : '',
    address: address ? String(address).trim() : '',
    registrationDate: ist.isoDate,
    passwordHash: bcrypt.hashSync(crypto.randomBytes(24).toString('hex'), 8),
    mustChangePassword: true,
    sessionVersion: 1,
    status: 'PENDING_APPROVAL',
    approvalStatus: 'PENDING_APPROVAL',
    verificationStatus: 'AADHAAR_VERHOEFF_VERIFIED',
    createdAt: nowIso,
    approvalHistory: [
      {
        timestamp: nowIso,
        action: 'REQUEST_CREATED',
        actorUid,
        notes: `Submitted by ${actorUid} for ${targetRole} (${ist.isoDate})`
      }
    ]
  };

  users.push(newUser);
  saveUsers(users);

  centralDb.logAudit('USER_REQUEST_CREATED', `Account request ${requestId} (${targetRole}) created by ${actorUid}`, actorUid, { requestId });
  res.json({
    success: true,
    message: `Account request ${requestId} submitted to Administration Approval Panel.`,
    idFormatPreview: getIdFormatPreview(targetRole).formatPreview,
    user: sanitizeUserForResponse(newUser, true)
  });
});

app.post('/api/users/approve', (req, res) => {
  const auth = verifySuperAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });

  const { requestId, uid, notes } = req.body || {};
  const lookup = String(requestId || uid || '').trim().toUpperCase();
  if (!lookup) return res.status(400).json({ success: false, message: 'Request ID or User ID is required.' });

  const users = loadUsers();
  const user = users.find(u => (u.requestId && u.requestId.toUpperCase() === lookup) || (u.uid && u.uid.toUpperCase() === lookup));
  if (!user) return res.status(404).json({ success: false, message: 'Applicant record not found.' });
  if (user.status === 'REJECTED') return res.status(400).json({ success: false, message: 'Rejected requests cannot be activated directly.' });

  if (user.approvalStatus === 'APPROVED' && user.status === 'ACTIVE' && user.uid) {
    return res.status(409).json({
      success: false,
      uid: user.uid,
      message: `Account is already approved with permanent User ID ${user.uid}. Permanent UIDs cannot be regenerated.`
    });
  }

  // Strictly issue permanent UID atomically ONLY once upon Administration approval
  if (!user.uid) {
    const existingUids = new Set(users.map(u => String(u.uid || '').trim().toUpperCase()).filter(Boolean));
    user.uid = centralDb.generatePermanentUid(user.role, existingUids);
  }

  const tempPassword = generateSecureTempPassword(12);
  const now = new Date().toISOString();

  user.status = 'ACTIVE';
  user.approvalStatus = 'APPROVED';
  user.verificationStatus = 'SUPER_ADMIN_VERIFIED';
  user.approvedByUid = auth.actor.uid;
  user.approvedAt = now;
  user.updatedAt = now;
  user.decisionNotes = notes ? String(notes).trim() : 'Approved by Administration';
  user.mustChangePassword = true;
  user.passwordHash = bcrypt.hashSync(tempPassword, 10);
  user.sessionVersion = (user.sessionVersion || 1) + 1;
  user.failedLoginAttempts = 0;
  user.lockedUntil = null;
  user.approvalHistory = Array.isArray(user.approvalHistory) ? user.approvalHistory : [];
  user.approvalHistory.unshift({
    timestamp: now,
    action: 'APPROVED',
    actorUid: auth.actor.uid,
    notes: `Permanent UID ${user.uid} generated. ${user.decisionNotes}`
  });

  saveUsers(users);
  centralDb.logAudit(
    'USER_APPROVED',
    `Administration (${auth.actor.uid}) APPROVED ${user.role} (${user.requestId}) -> Assigned Permanent UID: ${user.uid}.`,
    auth.actor.uid,
    { requestId: user.requestId, targetUid: user.uid, decision: 'APPROVED', approvingAdminUid: auth.actor.uid }
  );

  // Return one-time temporaryPassword strictly in this single approval response; never stored in plaintext
  res.json({
    success: true,
    message: `Account APPROVED! Permanent UID: ${user.uid}`,
    uid: user.uid,
    temporaryPassword: tempPassword,
    user: sanitizeUserForResponse(user, true)
  });
});

app.post('/api/users/reject', (req, res) => {
  const auth = verifySuperAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });

  const { requestId, uid, reason } = req.body || {};
  const lookup = String(requestId || uid || '').trim().toUpperCase();
  if (!lookup) return res.status(400).json({ success: false, message: 'Request ID is required.' });

  const cleanReason = String(reason || '').trim();
  if (!cleanReason) {
    return res.status(400).json({ success: false, message: 'Rejection reason is required for audit history.' });
  }

  const users = loadUsers();
  const user = users.find(u => (u.requestId && u.requestId.toUpperCase() === lookup) || (u.uid && u.uid.toUpperCase() === lookup));
  if (!user) return res.status(404).json({ success: false, message: 'Applicant record not found.' });
  if (user.uid === SUPER_ADMIN_UID || user.isSuperAdmin) return res.status(403).json({ success: false, message: 'Cannot reject root Administration account.' });

  const now = new Date().toISOString();
  user.status = 'REJECTED';
  user.approvalStatus = 'REJECTED';
  user.approvedByUid = auth.actor.uid;
  user.approvedAt = now;
  user.updatedAt = now;
  user.decisionNotes = cleanReason;
  user.sessionVersion = (user.sessionVersion || 1) + 1;
  user.approvalHistory = Array.isArray(user.approvalHistory) ? user.approvalHistory : [];
  user.approvalHistory.unshift({
    timestamp: now,
    action: 'REJECTED',
    actorUid: auth.actor.uid,
    notes: cleanReason
  });
  saveUsers(users);

  centralDb.logAudit('USER_REJECTED', `Administration (${auth.actor.uid}) REJECTED ${user.requestId} (${user.name}). Reason: ${cleanReason}`, auth.actor.uid);
  res.json({ success: true, message: `Registration ${user.requestId} rejected.`, user: sanitizeUserForResponse(user, true) });
});

app.post('/api/users/request-correction', (req, res) => {
  const auth = verifySuperAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });

  const { requestId, uid, notes } = req.body || {};
  const lookup = String(requestId || uid || '').trim().toUpperCase();
  if (!lookup) return res.status(400).json({ success: false, message: 'Request ID is required.' });

  const users = loadUsers();
  const user = users.find(u => (u.requestId && u.requestId.toUpperCase() === lookup) || (u.uid && u.uid.toUpperCase() === lookup));
  if (!user) return res.status(404).json({ success: false, message: 'Applicant record not found.' });
  if (user.uid === SUPER_ADMIN_UID || user.isSuperAdmin) return res.status(403).json({ success: false, message: 'Cannot modify root Administration account.' });

  const now = new Date().toISOString();
  const cleanNotes = notes ? String(notes).trim() : 'Document/Aadhaar correction requested by Administration.';
  user.status = 'CORRECTION_REQUIRED';
  user.approvalStatus = 'CORRECTION_REQUIRED';
  user.approvedByUid = auth.actor.uid;
  user.approvedAt = now;
  user.updatedAt = now;
  user.decisionNotes = cleanNotes;
  user.approvalHistory = Array.isArray(user.approvalHistory) ? user.approvalHistory : [];
  user.approvalHistory.unshift({
    timestamp: now,
    action: 'CORRECTION_REQUIRED',
    actorUid: auth.actor.uid,
    notes: cleanNotes
  });
  saveUsers(users);

  centralDb.logAudit('USER_CORRECTION_REQUESTED', `Administration (${auth.actor.uid}) requested correction for ${user.requestId}.`, auth.actor.uid);
  res.json({ success: true, message: `Correction requested for ${user.requestId}.`, user: sanitizeUserForResponse(user, true) });
});

app.post('/api/users/edit', (req, res) => {
  const auth = verifySuperAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });

  const {
    requestId,
    uid,
    name,
    fatherName,
    motherName,
    dob,
    phone,
    email,
    designation,
    role,
    district,
    areaType,
    blockOrMunicipality,
    gpOrWard,
    villageOrWard,
    postOffice,
    policeStation,
    pinCode,
    address
  } = req.body || {};

  const lookup = String(uid || requestId || '').trim().toUpperCase();
  if (!lookup) return res.status(400).json({ success: false, message: 'Target User ID or Request ID is required.' });

  const users = loadUsers();
  const user = users.find(u => (u.uid && u.uid.toUpperCase() === lookup) || (u.requestId && u.requestId.toUpperCase() === lookup));
  if (!user) return res.status(404).json({ success: false, message: 'User account not found.' });

  // NEVER alter an already-issued permanent UID
  if (name !== undefined && String(name).trim()) user.name = String(name).trim();
  if (fatherName !== undefined) user.fatherName = String(fatherName).trim();
  if (motherName !== undefined) user.motherName = String(motherName).trim();
  if (dob !== undefined) user.dob = String(dob).trim();
  if (designation !== undefined && String(designation).trim()) user.designation = String(designation).trim();
  if (email !== undefined) user.email = String(email).trim();
  if (district !== undefined) user.district = String(district).trim();
  if (areaType !== undefined) user.areaType = areaType === 'URBAN' ? 'URBAN' : 'RURAL';
  if (blockOrMunicipality !== undefined) user.blockOrMunicipality = String(blockOrMunicipality).trim();
  if (gpOrWard !== undefined) user.gpOrWard = String(gpOrWard).trim();
  if (villageOrWard !== undefined) user.villageOrWard = String(villageOrWard).trim();
  if (postOffice !== undefined) user.postOffice = String(postOffice).trim();
  if (policeStation !== undefined) user.policeStation = String(policeStation).trim();
  if (pinCode !== undefined) user.pinCode = String(pinCode).replace(/[^0-9]/g, '').slice(0, 6);
  if (address !== undefined) user.address = String(address).trim();

  if (phone !== undefined && String(phone).trim()) {
    const cleanPhone = String(phone).replace(/[^0-9]/g, '').slice(-10);
    if (cleanPhone.length !== 10) return res.status(400).json({ success: false, message: 'Mobile Number must be 10 digits.' });
    user.phone = cleanPhone;
    user.phoneMasked = maskPhone(cleanPhone);
  }

  if (role !== undefined && user.uid !== SUPER_ADMIN_UID && !user.isSuperAdmin) {
    const allowedRoles: AppRole[] = ['ADMIN', 'MANAGER', 'MAKER', 'CHECKER', 'STAFF'];
    const nextRole = String(role).trim().toUpperCase() as AppRole;
    if (allowedRoles.includes(nextRole)) {
      user.role = nextRole;
    }
  }

  const now = new Date().toISOString();
  user.updatedAt = now;
  user.approvalHistory = Array.isArray(user.approvalHistory) ? user.approvalHistory : [];
  user.approvalHistory.unshift({
    timestamp: now,
    action: 'PROFILE_EDITED',
    actorUid: auth.actor.uid,
    notes: `Profile updated by Administration (${auth.actor.uid}); permanent UID unchanged.`
  });
  saveUsers(users);

  centralDb.logAudit('USER_UPDATED', `Administration (${auth.actor.uid}) updated user profile for ${user.uid || user.requestId} (${user.name}).`, auth.actor.uid);
  res.json({
    success: true,
    message: `User profile updated for ${user.uid || user.requestId}.`,
    user: sanitizeUserForResponse(user, true)
  });
});

app.post('/api/users/toggle-status', (req, res) => {
  const auth = verifySuperAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });

  const { requestId, uid } = req.body || {};
  const lookup = String(requestId || uid || '').trim().toUpperCase();
  if (!lookup) return res.status(400).json({ success: false, message: 'User ID or Request ID required.' });
  if (lookup === SUPER_ADMIN_UID) return res.status(403).json({ success: false, message: 'Cannot suspend root Administration account.' });

  const users = loadUsers();
  const user = users.find(u => (u.uid && u.uid.toUpperCase() === lookup) || (u.requestId && u.requestId.toUpperCase() === lookup));
  if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
  if (user.isSuperAdmin || user.uid === SUPER_ADMIN_UID) return res.status(403).json({ success: false, message: 'Cannot suspend root Administration account.' });
  if (user.approvalStatus !== 'APPROVED' || !user.uid) return res.status(403).json({ success: false, message: 'Approve account first.' });

  const now = new Date().toISOString();
  user.status = user.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE';
  user.approvedByUid = auth.actor.uid;
  user.updatedAt = now;
  user.sessionVersion = (user.sessionVersion || 1) + 1;
  if (user.status === 'ACTIVE') {
    user.failedLoginAttempts = 0;
    user.failedResetAttempts = 0;
    user.lockedUntil = null;
  }
  user.approvalHistory = Array.isArray(user.approvalHistory) ? user.approvalHistory : [];
  user.approvalHistory.unshift({
    timestamp: now,
    action: user.status === 'ACTIVE' ? 'REACTIVATED' : 'SUSPENDED',
    actorUid: auth.actor.uid,
    notes: `Account marked ${user.status}`
  });
  saveUsers(users);

  centralDb.logAudit('USER_STATUS_CHANGE', `Administration (${auth.actor.uid}) toggled ${user.uid} -> ${user.status}`, auth.actor.uid);
  res.json({ success: true, message: `Account status updated to ${user.status}`, status: user.status });
});

app.post('/api/users/reset-password', (req, res) => {
  const auth = verifySuperAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });

  const { uid } = req.body || {};
  if (!uid) return res.status(400).json({ success: false, message: 'User ID is required.' });

  const users = loadUsers();
  const user = users.find(u => u.uid && u.uid.toUpperCase() === String(uid).trim().toUpperCase());
  if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

  const tempPassword = generateSecureTempPassword(12);
  const now = new Date().toISOString();
  user.passwordHash = bcrypt.hashSync(tempPassword, 10);
  user.mustChangePassword = true;
  user.passwordChangedAt = now;
  user.passwordChangeCount = (user.passwordChangeCount || 0) + 1;
  user.passwordHistory = Array.isArray(user.passwordHistory) ? user.passwordHistory : [];
  user.passwordHistory.unshift({ changedAt: now, method: `ADMIN_TEMP_RESET (${auth.actor.uid})` });
  user.sessionVersion = (user.sessionVersion || 1) + 1;
  user.failedLoginAttempts = 0;
  user.lockedUntil = null;
  saveUsers(users);

  centralDb.logAudit('ADMIN_PASSWORD_RESET', `Administration (${auth.actor.uid}) issued a new temporary password for ${user.uid}. Active sessions invalidated.`, auth.actor.uid);
  res.json({
    success: true,
    uid: user.uid,
    temporaryPassword: tempPassword,
    message: `Temporary password generated for ${user.uid}.`
  });
});

app.post('/api/users/recovery-code', (req, res) => {
  const auth = verifySuperAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });

  const cleanUid = String(req.body?.uid || '').trim().toUpperCase();
  if (!cleanUid) return res.status(400).json({ success: false, message: 'User ID is required.' });

  const users = loadUsers();
  const user = users.find(u => u.uid && u.uid.toUpperCase() === cleanUid);
  if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

  const result = centralDb.createRecoveryCode(user.uid, auth.actor.uid);
  res.json({
    success: true,
    uid: user.uid,
    code: result.code,
    expiresAt: result.expiresAt,
    message: `One-time recovery code issued for ${user.uid}.`
  });
});

app.post('/api/users/permissions', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const actorEff = resolveEffectivePermissions(auth.actor);
  const canManagePerms =
    auth.actor.uid === SUPER_ADMIN_UID ||
    auth.actor.isSuperAdmin === true ||
    auth.actor.role === 'ADMIN' ||
    actorEff.extra.canManageUserPermissions === true;

  if (!canManagePerms) {
    return res.status(403).json({
      success: false,
      message: 'ACCESS DENIED: Only Administrator can modify User Role & Individual Permissions.'
    });
  }

  const { uid, requestId, permissionOverrides, extraPermissions, resetToDefaults } = req.body || {};
  const lookup = String(uid || requestId || '').trim().toUpperCase();
  if (!lookup) return res.status(400).json({ success: false, message: 'Target User ID is required.' });
  if (lookup === SUPER_ADMIN_UID) {
    return res.status(403).json({ success: false, message: 'Root Administrator permissions cannot be restricted.' });
  }

  const users = loadUsers();
  const target = users.find(u => (u.uid && u.uid.toUpperCase() === lookup) || (u.requestId && u.requestId.toUpperCase() === lookup));
  if (!target) return res.status(404).json({ success: false, message: 'User account not found.' });
  if (target.isSuperAdmin || target.uid === SUPER_ADMIN_UID) {
    return res.status(403).json({ success: false, message: 'Root Administrator permissions cannot be modified.' });
  }

  const now = new Date().toISOString();
  if (resetToDefaults) {
    target.permissionOverrides = {};
    target.extraPermissions = {};
  } else {
    if (permissionOverrides && typeof permissionOverrides === 'object') {
      const cleanedMenus: Record<string, Record<string, boolean>> = {};
      for (const def of MENU_DEFINITIONS) {
        const m = permissionOverrides[def.id];
        if (m && typeof m === 'object') {
          cleanedMenus[def.id] = {};
          for (const act of PERMISSION_ACTIONS) {
            if (typeof m[act] === 'boolean') {
              cleanedMenus[def.id][act] = m[act];
            }
          }
        }
      }
      target.permissionOverrides = cleanedMenus;
    }
    if (extraPermissions && typeof extraPermissions === 'object') {
      const ext: Record<string, any> = {};
      if (extraPermissions.cashOperationLimit !== undefined) {
        ext.cashOperationLimit = Math.max(0, Number(extraPermissions.cashOperationLimit) || 0);
      }
      if (extraPermissions.customerAccessScope === 'ALL' || extraPermissions.customerAccessScope === 'ASSIGNED') {
        ext.customerAccessScope = extraPermissions.customerAccessScope;
      }
      if (extraPermissions.customerAccessLimit !== undefined) {
        ext.customerAccessLimit = Math.max(0, Number(extraPermissions.customerAccessLimit) || 0);
      }
      if (typeof extraPermissions.canApproveTransactions === 'boolean') {
        ext.canApproveTransactions = extraPermissions.canApproveTransactions;
      }
      if (typeof extraPermissions.canViewAllAttendancePhotos === 'boolean') {
        ext.canViewAllAttendancePhotos = target.role === 'ADMIN' || target.role === 'MANAGER'
          ? extraPermissions.canViewAllAttendancePhotos
          : false;
      }
      if (typeof extraPermissions.canManageBackupSettings === 'boolean') {
        ext.canManageBackupSettings = extraPermissions.canManageBackupSettings;
      }
      if (typeof extraPermissions.canManageUserPermissions === 'boolean') {
        ext.canManageUserPermissions = target.role === 'ADMIN' || target.role === 'MANAGER'
          ? extraPermissions.canManageUserPermissions
          : false;
      }
      target.extraPermissions = ext;
    }
  }

  target.updatedAt = now;
  target.approvalHistory = Array.isArray(target.approvalHistory) ? target.approvalHistory : [];
  target.approvalHistory.unshift({
    timestamp: now,
    action: resetToDefaults ? 'PERMISSIONS_RESET' : 'PERMISSIONS_UPDATED',
    actorUid: auth.actor.uid,
    notes: resetToDefaults
      ? `Permissions reset to ${target.role} role defaults by ${auth.actor.uid}`
      : `Individual menu & control permissions updated by ${auth.actor.uid}`
  });
  saveUsers(users);

  centralDb.logAudit(
    'USER_PERMISSIONS_UPDATED',
    `Administrator (${auth.actor.uid}) updated individual permissions for ${target.name} (${target.uid || target.requestId})`,
    auth.actor.uid,
    { targetUid: target.uid || target.requestId, resetToDefaults: Boolean(resetToDefaults) }
  );

  res.json({
    success: true,
    message: `Permissions updated for ${target.name} (${target.uid || target.requestId}).`,
    user: sanitizeUserForResponse(target, true)
  });
});

app.post('/api/users/delete', (req, res) => {
  const auth = verifySuperAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });

  const { uid, requestId, reason } = req.body || {};
  const lookup = String(uid || requestId || '').trim().toUpperCase();
  const cleanReason = String(reason || '').trim();
  if (!lookup) return res.status(400).json({ success: false, message: 'User ID or Request ID is required.' });
  if (cleanReason.length < 3) {
    return res.status(400).json({ success: false, message: 'Delete Reason (minimum 3 characters) is required.' });
  }
  if (lookup === SUPER_ADMIN_UID) {
    return res.status(403).json({ success: false, message: 'Cannot delete root Administration account.' });
  }

  const users = loadUsers();
  const idx = users.findIndex(u => (u.uid && u.uid.toUpperCase() === lookup) || (u.requestId && u.requestId.toUpperCase() === lookup));
  if (idx === -1) return res.status(404).json({ success: false, message: 'User account not found.' });
  const target = users[idx];
  if (target.isSuperAdmin || target.uid === SUPER_ADMIN_UID) {
    return res.status(403).json({ success: false, message: 'Cannot delete root Administration account.' });
  }

  users.splice(idx, 1);
  saveUsers(users);
  centralDb.recordDeleteHistory({
    targetType: 'USER_ACCOUNT',
    targetId: target.uid || target.requestId,
    targetSummary: `${target.name} (${target.role}) · Phone ${target.phoneMasked || maskPhone(target.phone)}`,
    reason: cleanReason,
    deletedByUid: auth.actor.uid,
    deletedByName: auth.actor.name
  });

  res.json({ success: true, message: `User ${target.name} (${target.uid || target.requestId}) deleted and logged.` });
});

app.get('/api/permissions/schema', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  res.json({
    success: true,
    menus: MENU_DEFINITIONS,
    actions: PERMISSION_ACTIONS,
    roleDefaults: {
      ADMIN: getDefaultRolePermissions('ADMIN'),
      MANAGER: getDefaultRolePermissions('MANAGER'),
      STAFF: getDefaultRolePermissions('STAFF')
    },
    currentEffective: resolveEffectivePermissions(auth.actor)
  });
});

app.post('/api/permissions/verify', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const menuId = String(req.body?.menuId || '');
  const action = (String(req.body?.action || 'view') as PermissionAction);
  const amount = req.body?.amount !== undefined ? Number(req.body.amount) : undefined;
  const eff = resolveEffectivePermissions(auth.actor);

  const allowed = menuId ? hasMenuPermission(auth.actor, menuId, action) : true;
  if (!allowed) {
    return res.status(403).json({
      success: false,
      allowed: false,
      message: `Permission denied: '${menuId}.${action}' is disabled for ${auth.actor.name} (${auth.actor.uid}).`
    });
  }
  if (amount !== undefined && eff.extra.cashOperationLimit > 0 && amount > eff.extra.cashOperationLimit) {
    return res.status(403).json({
      success: false,
      allowed: false,
      limitExceeded: true,
      limit: eff.extra.cashOperationLimit,
      message: `Cash Operation Limit Exceeded: Your limit is ₹${eff.extra.cashOperationLimit}. Contact Administrator for approval.`
    });
  }
  res.json({ success: true, allowed: true, effectivePermissions: eff });
});

// ---------------------------------------------------------------------------
// SERVICE CATALOG MANAGEMENT API (ADD, EDIT, SOFT DELETE, RESTORE, TOGGLE)
// ---------------------------------------------------------------------------
app.get('/api/services', (req, res) => {
  const includeDeleted = req.query.includeDeleted === 'true';
  const activeOnly = req.query.activeOnly === 'true';
  const category = req.query.category ? String(req.query.category) : undefined;
  const q = req.query.q ? String(req.query.q) : undefined;
  const services = centralDb.listServices({ includeDeleted, activeOnly, category, q });
  res.json({ success: true, services, total: services.length });
});

app.post('/api/services', (req, res) => {
  const auth = verifyMenuPermission(req, 'rate-chart', 'add');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = centralDb.upsertService(req.body || {}, auth.actor.uid);
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

app.put('/api/services/:id', (req, res) => {
  const auth = verifyMenuPermission(req, 'rate-chart', 'edit');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = centralDb.upsertService({ ...(req.body || {}), id: String(req.params.id) }, auth.actor.uid);
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

app.delete('/api/services/:id', (req, res) => {
  const auth = verifyMenuPermission(req, 'rate-chart', 'delete');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = centralDb.softDeleteService(String(req.params.id), auth.actor.uid);
  if (!result.success) return res.status(404).json(result);
  res.json(result);
});

app.post('/api/services/:id/restore', (req, res) => {
  const auth = verifyMenuPermission(req, 'rate-chart', 'edit');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = centralDb.restoreService(String(req.params.id), auth.actor.uid);
  if (!result.success) return res.status(404).json(result);
  res.json(result);
});

app.post('/api/services/:id/toggle', (req, res) => {
  const auth = verifyMenuPermission(req, 'rate-chart', 'edit');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = centralDb.toggleServiceActive(String(req.params.id), auth.actor.uid);
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

app.delete('/api/services/:id/permanent', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = centralDb.permanentDeleteService(String(req.params.id), auth.actor.uid);
  if (!result.success) return res.status(404).json(result);
  res.json(result);
});

// ---------------------------------------------------------------------------
// INVENTORY PRODUCT CATEGORIES API (GAS DEFAULTS + CUSTOM ADD / DELETE)
// ---------------------------------------------------------------------------
app.get('/api/inventory/categories', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(401).json({ success: false, message: auth.error });
  const categories = centralDb.getInventoryCategories();
  res.json({ success: true, categories });
});

app.post('/api/inventory/categories', (req, res) => {
  const auth = verifyMenuPermission(req, 'inventory', 'add');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const name = String(req.body?.name || '');
  const id = req.body?.id ? String(req.body.id) : undefined;
  const result = centralDb.addInventoryCategory(name, auth.actor.uid, id);
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

app.delete('/api/inventory/categories/:id', (req, res) => {
  const auth = verifyMenuPermission(req, 'inventory', 'delete');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = centralDb.deleteInventoryCategory(String(req.params.id), auth.actor.uid);
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

app.post('/api/inventory/categories/restore-defaults', (req, res) => {
  const auth = verifyMenuPermission(req, 'inventory', 'add');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = centralDb.restoreDefaultGasCategories(auth.actor.uid);
  res.json(result);
});

app.post('/api/inventory/categories/sync', (req, res) => {
  const auth = verifyMenuPermission(req, 'inventory', 'add');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const categories = Array.isArray(req.body?.categories) ? req.body.categories : [];
  const result = centralDb.syncInventoryCategories(categories, auth.actor.uid);
  res.json(result);
});

// ---------------------------------------------------------------------------
// TEAM COUNTER CHAT API (LIST, SEND, EDIT, DELETE)
// ---------------------------------------------------------------------------
app.get('/api/chats', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(401).json({ success: false, message: auth.error });
  const channel = req.query.channel ? String(req.query.channel) : 'all';
  const chats = centralDb.listChats(channel);
  res.json({ success: true, chats, total: chats.length });
});

app.post('/api/chats', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(401).json({ success: false, message: auth.error });
  const result = centralDb.createChatMessage(req.body || {}, auth.actor);
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

app.put('/api/chats/:id', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(401).json({ success: false, message: auth.error });
  const messageText = String(req.body?.message || '');
  const result = centralDb.editChatMessage(String(req.params.id), messageText, auth.actor);
  if (!result.success) return res.status(result.message.includes('only edit') ? 403 : 400).json(result);
  res.json(result);
});

app.delete('/api/chats/:id', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(401).json({ success: false, message: auth.error });
  const result = centralDb.deleteChatMessage(String(req.params.id), auth.actor);
  if (!result.success) return res.status(result.message.includes('only delete') ? 403 : 404).json(result);
  res.json(result);
});

// ---------------------------------------------------------------------------
// CUSTOMER MASTER, AUTO-FETCH & ADMIN DUPLICATE MERGE
// ---------------------------------------------------------------------------
app.get('/api/customers', (req, res) => {
  const q = String(req.query.q || '');
  const customers = centralDb.listCustomers(q);
  res.json({ success: true, customers, total: customers.length });
});

app.get('/api/customers/autofetch', (req, res) => {
  const lookup = String(req.query.q || req.query.uid || '');
  if (!lookup) return res.status(400).json({ success: false, message: 'Provide UID, Customer ID, or Mobile.' });
  const match = centralDb.getCustomerAutoFetch(lookup);
  if (!match) return res.status(404).json({ success: false, message: 'Customer not found.' });
  res.json({ success: true, ...match });
});

app.post('/api/customers', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(401).json({ success: false, message: auth.error });
  const result = centralDb.upsertCustomer(req.body || {}, auth.actor.uid);
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

app.post('/api/customers/merge', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const { sourceId, targetId } = req.body;
  const result = centralDb.mergeCustomers(String(sourceId || ''), String(targetId || ''), auth.actor.uid);
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

app.delete('/api/customers/:id', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = centralDb.deleteCustomer(String(req.params.id), auth.actor.uid);
  if (!result.success) return res.status(404).json(result);
  res.json(result);
});

// ---------------------------------------------------------------------------
// APPLICATION WORKFLOW & TIMELINE
// ---------------------------------------------------------------------------
app.get('/api/applications', (req, res) => {
  const apps = centralDb.listApplications({
    status: req.query.status ? String(req.query.status) : undefined,
    staffUid: req.query.staffUid ? String(req.query.staffUid) : undefined,
    customerId: req.query.customerId ? String(req.query.customerId) : undefined,
    q: req.query.q ? String(req.query.q) : undefined
  });
  res.json({ success: true, applications: apps, total: apps.length });
});

app.post('/api/applications', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(401).json({ success: false, message: auth.error });
  const result = centralDb.createApplication(req.body || {}, auth.actor.uid);
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

app.patch('/api/applications/:id', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(401).json({ success: false, message: auth.error });
  const result = centralDb.updateApplication(String(req.params.id), req.body || {}, auth.actor.uid);
  if (!result.success) return res.status(404).json(result);
  res.json(result);
});

// ---------------------------------------------------------------------------
// PROTECTED DOCUMENT VAULT
// ---------------------------------------------------------------------------
app.get('/api/documents', (req, res) => {
  res.json({ success: true, documents: centralDb.listDocuments() });
});

app.post('/api/documents/upload', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(401).json({ success: false, message: auth.error });
  const result = centralDb.saveUploadedDocument({ ...(req.body || {}), actorUid: auth.actor.uid });
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

app.get('/api/documents/:id/download', (req, res) => {
  const doc = centralDb.getDocumentById(String(req.params.id));
  if (!doc) return res.status(404).json({ success: false, message: 'Document not found.' });
  const filePath = centralDb.getDocumentFilePath(doc);
  if (!fs.existsSync(filePath)) return res.status(404).json({ success: false, message: 'Stored file missing on disk.' });
  res.setHeader('Content-Type', doc.mimeType);
  res.setHeader('Content-Disposition', `inline; filename="${doc.fileName}"`);
  res.sendFile(filePath);
});

app.delete('/api/documents/:id', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = centralDb.deleteDocument(String(req.params.id), auth.actor.uid);
  if (!result.success) return res.status(404).json(result);
  res.json(result);
});

// ---------------------------------------------------------------------------
// UNIVERSAL SERVER-SIDE SEARCH & PAGINATION
// ---------------------------------------------------------------------------
app.get('/api/search', (req, res) => {
  const result = centralDb.universalSearch({
    q: req.query.q ? String(req.query.q) : '',
    type: req.query.type ? String(req.query.type) : 'all',
    district: req.query.district ? String(req.query.district) : undefined,
    blockOrMunicipality: req.query.blockOrMunicipality ? String(req.query.blockOrMunicipality) : undefined,
    status: req.query.status ? String(req.query.status) : undefined,
    dateFrom: req.query.dateFrom ? String(req.query.dateFrom) : undefined,
    dateTo: req.query.dateTo ? String(req.query.dateTo) : undefined,
    sort: (req.query.sort as any) || 'relevance',
    page: Number(req.query.page || 1),
    limit: Number(req.query.limit || 20),
    actorRole: req.headers['x-actor-role'] ? String(req.headers['x-actor-role']) : 'STAFF'
  });
  res.json({ success: true, ...result });
});

// ---------------------------------------------------------------------------
// MANDATORY ATTENDANCE PHOTO GALLERY, GPS MONITORING & TIME REGISTER APIs
// ---------------------------------------------------------------------------
function canViewAllStaffPhotos(actor: UserRecord): boolean {
  if (actor.uid === SUPER_ADMIN_UID || actor.isSuperAdmin || actor.role === 'ADMIN') return true;
  if (actor.role === 'MANAGER') {
    const eff = resolveEffectivePermissions(actor);
    return Boolean(eff.extra.canViewAllAttendancePhotos);
  }
  return false; // Staff NEVER sees another staff member's attendance photos or GPS history
}

app.get('/api/attendance/records', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const actor = auth.actor;
  const isStaffScoped = actor.role !== 'ADMIN' && !actor.isSuperAdmin && actor.role !== 'MANAGER';
  const requestedStaff = req.query.staffId ? String(req.query.staffId) : undefined;
  const eff = resolveEffectivePermissions(actor);
  const canViewAll = actor.role === 'ADMIN' || actor.isSuperAdmin || (actor.role === 'MANAGER' && eff.menus['staff-attendance']?.view);

  const records = centralDb.listAttendanceRecords({
    date: req.query.date ? String(req.query.date) : undefined,
    month: req.query.month ? String(req.query.month) : undefined,
    staffId: canViewAll && !isStaffScoped ? requestedStaff : actor.uid
  });
  res.json({ success: true, records, total: records.length, scopedToSelf: !canViewAll || isStaffScoped });
});

app.post('/api/attendance/records', (req, res) => {
  const auth = verifyMenuPermission(req, 'staff-attendance', 'add');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const actor = auth.actor;
  const body = req.body || {};
  const targetStaffId = String(body.staffId || actor.uid).trim().toUpperCase();
  const isAdminOrMgr = actor.role === 'ADMIN' || actor.isSuperAdmin || actor.role === 'MANAGER';
  if (!isAdminOrMgr && targetStaffId !== actor.uid.toUpperCase()) {
    return res.status(403).json({ success: false, message: 'Staff can only record their own attendance.' });
  }
  const saved = centralDb.upsertAttendanceRecord({ ...body, staffId: targetStaffId }, actor.uid);
  res.json({ success: true, record: saved });
});

app.get('/api/attendance/photos', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const actor = auth.actor;
  const allowAll = canViewAllStaffPhotos(actor);

  const requestedStaffId = req.query.staffId ? String(req.query.staffId) : 'all';
  const effectiveStaffFilter = allowAll ? requestedStaffId : actor.uid;

  const photos = centralDb.listAttendancePhotos({
    date: req.query.date ? String(req.query.date) : undefined,
    fromDate: req.query.fromDate ? String(req.query.fromDate) : undefined,
    toDate: req.query.toDate ? String(req.query.toDate) : undefined,
    staffId: effectiveStaffFilter,
    eventType: req.query.eventType ? String(req.query.eventType) : 'ALL',
    q: req.query.q ? String(req.query.q) : undefined
  });

  res.json({
    success: true,
    photos,
    total: photos.length,
    canViewAllStaffPhotos: allowAll,
    canDeletePhotos: actor.role === 'ADMIN' || actor.isSuperAdmin || actor.uid === SUPER_ADMIN_UID
  });
});

app.get('/api/attendance/photos/:id/image', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const actor = auth.actor;
  const record = centralDb.getAttendancePhotoById(String(req.params.id));
  if (!record) return res.status(404).json({ success: false, message: 'Attendance photo not found.' });

  const allowAll = canViewAllStaffPhotos(actor);
  if (!allowAll && record.staffId.toUpperCase() !== actor.uid.toUpperCase()) {
    centralDb.logAudit(
      'UNAUTHORIZED_PHOTO_ACCESS',
      `Blocked ${actor.uid} (${actor.role}) from viewing Attendance Photo ${record.id} belonging to ${record.staffId}`,
      actor.uid
    );
    return res.status(403).json({
      success: false,
      message: 'ACCESS DENIED: You are only authorized to view your own attendance photos.'
    });
  }

  const filePath = centralDb.getAttendancePhotoFilePath(record);
  if (!fs.existsSync(filePath)) return res.status(404).json({ success: false, message: 'Stored photo file missing.' });

  const isDownload = req.query.download === '1' || req.query.download === 'true';
  const safeName = `MUN_Attendance_${record.staffId}_${record.date}_${record.eventType}_${record.id}.jpg`;
  res.setHeader('Content-Type', record.mimeType || 'image/jpeg');
  res.setHeader('Content-Disposition', `${isDownload ? 'attachment' : 'inline'}; filename="${safeName}"`);
  res.sendFile(filePath);
});

app.post('/api/attendance/photos', (req, res) => {
  const auth = verifyMenuPermission(req, 'gps-attendance', 'add');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const actor = auth.actor;
  const body = req.body || {};

  const isAdminOrMgr = actor.role === 'ADMIN' || actor.isSuperAdmin || actor.role === 'MANAGER';
  const targetStaffId = isAdminOrMgr && body.staffId ? String(body.staffId).trim().toUpperCase() : actor.uid;
  const users = loadUsers();
  const targetUser = users.find(u => u.uid && u.uid.toUpperCase() === targetStaffId);

  const result = centralDb.saveAttendancePhoto({
    staffId: targetStaffId,
    staffName: targetUser?.name || body.staffName || actor.name,
    staffRole: targetUser?.designation || targetUser?.role || actor.role,
    eventType: body.eventType === 'OUT' ? 'OUT' : 'IN',
    date: body.date,
    time24: body.time24,
    time12: body.time12,
    istTimestamp: body.istTimestamp,
    latitude: Number(body.latitude),
    longitude: Number(body.longitude),
    accuracy: Number(body.accuracy || 0),
    photoDataUrl: String(body.photoDataUrl || ''),
    captureMethod: String(body.captureMethod || ''),
    gpsVerifiedLive: body.gpsVerifiedLive === true,
    gpsMatchDistanceMeters: Number(body.gpsMatchDistanceMeters || 0),
    photoCapturedAt: body.photoCapturedAt ? String(body.photoCapturedAt) : undefined,
    gpsCapturedAt: body.gpsCapturedAt ? String(body.gpsCapturedAt) : undefined,
    consentAccepted: Boolean(body.consentAccepted),
    notes: body.notes,
    actorUid: actor.uid
  });

  if (!result.success || !result.photo) return res.status(400).json(result);

  // Sync Attendance Record cleanly on server
  const p = result.photo;
  const existing = centralDb.listAttendanceRecords({ date: p.date, staffId: p.staffId })[0];
  centralDb.upsertAttendanceRecord(
    {
      date: p.date,
      staffId: p.staffId,
      staffName: p.staffName,
      role: p.staffRole,
      status: existing?.status && existing.status !== 'Absent' && existing.status !== 'Leave' ? existing.status : 'Present',
      inTime24: p.eventType === 'IN' ? p.time24 : (existing?.inTime24 || p.time24),
      outTime24: p.eventType === 'OUT' ? p.time24 : (existing?.outTime24 || ''),
      clockIn: p.eventType === 'IN' ? p.time12 : (existing?.clockIn || p.time12),
      clockOut: p.eventType === 'OUT' ? p.time12 : (existing?.clockOut || '-'),
      inGpsLat: p.eventType === 'IN' ? p.latitude : existing?.inGpsLat,
      inGpsLng: p.eventType === 'IN' ? p.longitude : existing?.inGpsLng,
      outGpsLat: p.eventType === 'OUT' ? p.latitude : existing?.outGpsLat,
      outGpsLng: p.eventType === 'OUT' ? p.longitude : existing?.outGpsLng,
      inPhotoId: p.eventType === 'IN' ? p.id : existing?.inPhotoId,
      outPhotoId: p.eventType === 'OUT' ? p.id : existing?.outPhotoId,
      notes: p.notes || existing?.notes || `GPS ${p.eventType} Verified`
    },
    actor.uid
  );

  res.json(result);
});

app.post('/api/attendance/photos/:id/verify', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  if (!canViewAllStaffPhotos(auth.actor)) {
    return res.status(403).json({
      success: false,
      message: 'ACCESS DENIED: Only Administrator or permitted Manager can verify Staff Attendance Photos.'
    });
  }
  const statusRaw = String(req.body?.verifiedStatus || 'VERIFIED').toUpperCase();
  const verifiedStatus: 'VERIFIED' | 'FLAGGED' | 'PENDING' =
    statusRaw === 'FLAGGED' ? 'FLAGGED' : statusRaw === 'PENDING' ? 'PENDING' : 'VERIFIED';
  const result = centralDb.verifyAttendancePhoto(String(req.params.id), auth.actor.uid, verifiedStatus, req.body?.notes);
  if (!result.success) return res.status(404).json(result);
  res.json(result);
});

app.delete('/api/attendance/photos/:id', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) {
    return res.status(auth.code || 403).json({
      success: false,
      message: 'ACCESS DENIED: Only Administrator has permission to delete Attendance Photos.'
    });
  }
  const reason = String(req.body?.reason || req.query?.reason || '').trim();
  const result = centralDb.deleteAttendancePhoto(String(req.params.id), auth.actor.uid, auth.actor.name, reason);
  if (!result.success) return res.status(result.message.includes('Reason') ? 400 : 404).json(result);
  res.json(result);
});

// ---------------------------------------------------------------------------
// COUNTER DAY BOOK SERVER LEDGER (CASH LIMIT + ACTOR AUDIT + DELETE REASON)
// ---------------------------------------------------------------------------
app.get('/api/daybook', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const allowed =
    hasMenuPermission(auth.actor, 'counter-daybook', 'view') ||
    hasMenuPermission(auth.actor, 'daily-opening-cash', 'view') ||
    hasMenuPermission(auth.actor, 'daily-closing-cash', 'view') ||
    hasMenuPermission(auth.actor, 'cash-reports', 'view');
  if (!allowed) {
    return res.status(403).json({ success: false, message: 'ACCESS DENIED: Counter Day Book & Cash Records are restricted.' });
  }
  const filters = {
    date: req.query.date ? String(req.query.date) : undefined,
    fromDate: req.query.fromDate ? String(req.query.fromDate) : undefined,
    toDate: req.query.toDate ? String(req.query.toDate) : undefined
  };
  res.json({
    success: true,
    txns: centralDb.listCounterCashTxns(filters),
    snapshots: centralDb.listCounterDaybookSnapshots(filters)
  });
});

app.post('/api/daybook/txn', (req, res) => {
  const auth = verifyMenuPermission(req, 'counter-daybook', 'add');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const amount = Math.max(0, Number(req.body?.amount) || 0);
  if (amount <= 0) return res.status(400).json({ success: false, message: 'Valid cash amount (> ₹0) is required.' });
  const eff = resolveEffectivePermissions(auth.actor);
  if (eff.extra.cashOperationLimit > 0 && amount > eff.extra.cashOperationLimit) {
    return res.status(403).json({
      success: false,
      limitExceeded: true,
      message: `Cash Operation Limit Exceeded: Your single-entry limit is ₹${eff.extra.cashOperationLimit}. Contact Administrator.`
    });
  }
  const txn = centralDb.addCounterCashTxn(req.body || {}, { uid: auth.actor.uid, name: auth.actor.name });
  res.json({ success: true, txn });
});

app.delete('/api/daybook/txn/:id', (req, res) => {
  const auth = verifyMenuPermission(req, 'counter-daybook', 'delete');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const reason = String(req.body?.reason || req.query?.reason || '').trim();
  const result = centralDb.deleteCounterCashTxn(String(req.params.id), auth.actor.uid, auth.actor.name, reason);
  if (!result.success) return res.status(result.message.includes('Reason') ? 400 : 404).json(result);
  res.json(result);
});

app.post('/api/daybook/snapshot', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const isClosing = Boolean(req.body?.closingSaved);
  const menu = isClosing ? 'daily-closing-cash' : 'daily-opening-cash';
  if (!hasMenuPermission(auth.actor, menu, 'add') && !hasMenuPermission(auth.actor, 'counter-daybook', 'add')) {
    return res.status(403).json({ success: false, message: `ACCESS DENIED: No permission for ${menu}.` });
  }
  const snapshot = centralDb.saveCounterDaybookSnapshot(req.body || {}, { uid: auth.actor.uid, name: auth.actor.name });
  res.json({ success: true, snapshot });
});

// ---------------------------------------------------------------------------
// 90-DAY FOLLOW-UP & CASE MANAGEMENT SERVER LEDGER
// ---------------------------------------------------------------------------
app.get('/api/followup-cases', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  if (!hasMenuPermission(auth.actor, 'followups', 'view') && !hasMenuPermission(auth.actor, 'customers', 'view')) {
    return res.status(403).json({ success: false, message: 'ACCESS DENIED: Follow-up case access is restricted.' });
  }
  res.json({ success: true, cases: centralDb.listFollowupCases() });
});

app.post('/api/followup-cases', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  if (!hasMenuPermission(auth.actor, 'followups', 'add') && !hasMenuPermission(auth.actor, 'customers', 'add')) {
    return res.status(403).json({ success: false, message: 'ACCESS DENIED: Follow-up case creation is restricted.' });
  }
  const caseRecord = centralDb.upsertFollowupCase(req.body || {}, auth.actor.uid);
  res.json({ success: true, caseRecord });
});

app.post('/api/followup-cases/:id/timeline', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  if (!hasMenuPermission(auth.actor, 'followups', 'edit') && !hasMenuPermission(auth.actor, 'followups', 'add')) {
    return res.status(403).json({ success: false, message: 'ACCESS DENIED: Adding follow-up entries is restricted.' });
  }
  const result = centralDb.appendFollowupCaseTimeline(String(req.params.id), req.body || {}, auth.actor.uid);
  if (!result.success) return res.status(404).json(result);
  res.json(result);
});

app.delete('/api/followup-cases/:id', (req, res) => {
  const auth = verifyMenuPermission(req, 'followups', 'delete');
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = centralDb.deleteFollowupCase(String(req.params.id), auth.actor.uid);
  res.json(result);
});

// ---------------------------------------------------------------------------
// BACKUP EXPORT / AUTO-SNAPSHOT / RESTORE, DELETE HISTORY & AUDIT LOGS
// ---------------------------------------------------------------------------
function hasBackupOrSettingsPermission(actor: UserRecord): boolean {
  if (actor.uid === SUPER_ADMIN_UID || actor.isSuperAdmin || actor.role === 'ADMIN') return true;
  const eff = resolveEffectivePermissions(actor);
  return Boolean(eff.extra.canManageBackupSettings || eff.menus['settings']?.view);
}

app.get('/api/backup/export', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  if (!hasBackupOrSettingsPermission(auth.actor)) {
    return res.status(403).json({
      success: false,
      message: 'ACCESS DENIED: Administrator permission is required to export or change Backups/Settings.'
    });
  }
  res.json({ success: true, snapshot: centralDb.exportFullBackup(auth.actor.uid) });
});

app.get('/api/backup/snapshots', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  if (!hasBackupOrSettingsPermission(auth.actor)) {
    return res.status(403).json({ success: false, message: 'ACCESS DENIED: Administrator permission required for Backup Snapshots.' });
  }
  res.json({ success: true, snapshots: centralDb.listBackupSnapshots() });
});

app.post('/api/backup/auto-snapshot', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  if (!hasBackupOrSettingsPermission(auth.actor)) {
    return res.status(403).json({ success: false, message: 'ACCESS DENIED: Administrator permission required to run Backups.' });
  }
  const meta = centralDb.createAutoBackupSnapshot(auth.actor.uid, 'MANUAL');
  res.json({ success: true, snapshot: meta, message: `Backup snapshot ${meta.id} saved securely.` });
});

app.get('/api/backup/snapshots/:id/download', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  if (!hasBackupOrSettingsPermission(auth.actor)) {
    return res.status(403).json({ success: false, message: 'ACCESS DENIED.' });
  }
  const filePath = centralDb.getBackupSnapshotFilePath(String(req.params.id));
  if (!filePath) return res.status(404).json({ success: false, message: 'Snapshot not found.' });
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', `attachment; filename="${path.basename(filePath)}"`);
  res.sendFile(filePath);
});

app.post('/api/backup/restore', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const eff = resolveEffectivePermissions(auth.actor);
  if (auth.actor.uid !== SUPER_ADMIN_UID && !auth.actor.isSuperAdmin && auth.actor.role !== 'ADMIN' && !eff.extra.canManageBackupSettings) {
    return res.status(403).json({
      success: false,
      message: 'ACCESS DENIED: Only Administrator (or explicitly permitted Manager) can restore backups.'
    });
  }
  const result = centralDb.restoreBackup(req.body, auth.actor.uid);
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

app.post('/api/admin/clear-operational-data', (req, res) => {
  const auth = verifySuperAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = centralDb.clearOperationalData(auth.actor.uid);
  res.json(result);
});

app.get('/api/security/delete-history', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const isAdminOrMgr = auth.actor.role === 'ADMIN' || auth.actor.isSuperAdmin || hasBackupOrSettingsPermission(auth.actor);
  if (!isAdminOrMgr) {
    return res.status(403).json({ success: false, message: 'ACCESS DENIED: Security Delete History is restricted to Administration.' });
  }
  const targetType = req.query.targetType ? String(req.query.targetType) : 'ALL';
  const records = centralDb.listDeleteHistory(targetType);
  res.json({ success: true, records, total: records.length });
});

app.post('/api/security/delete-history', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const { targetType, targetId, targetSummary, reason, metadata } = req.body || {};
  const cleanReason = String(reason || '').trim();
  if (cleanReason.length < 3) {
    return res.status(400).json({ success: false, message: 'Delete Reason (minimum 3 characters) is required.' });
  }
  const rec = centralDb.recordDeleteHistory({
    targetType: targetType || 'OTHER',
    targetId: String(targetId || 'UNKNOWN'),
    targetSummary: String(targetSummary || 'Record Deleted'),
    reason: cleanReason,
    deletedByUid: auth.actor.uid,
    deletedByName: auth.actor.name,
    metadata
  });
  res.json({ success: true, record: rec });
});

app.get('/api/audit-logs', (req, res) => {
  res.json({ success: true, logs: centralDb.loadAuditLogs() });
});

// SMS Gateway Settings
app.get('/api/sms/config', (req, res) => {
  const config = loadSmsConfig();
  res.json({
    success: true,
    config: {
      provider: config.provider,
      apiKey: config.apiKey ? '••••••••' + config.apiKey.slice(-4) : '',
      senderId: config.senderId,
      apiUrl: config.apiUrl,
      fromPhone: config.fromPhone,
      enabled: config.enabled,
      isConfigured: isSmsGatewayConfigured()
    }
  });
});

app.post('/api/sms/config', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const { provider, apiKey, senderId, apiUrl, accountSid, authToken, fromPhone, enabled } = req.body;
  const existing = loadSmsConfig();
  const updated: SmsConfig = {
    provider: provider || existing.provider || 'fast2sms',
    apiKey: apiKey && !apiKey.includes('••••') ? apiKey : existing.apiKey,
    senderId: senderId !== undefined ? senderId : existing.senderId,
    apiUrl: apiUrl !== undefined ? apiUrl : existing.apiUrl,
    accountSid: accountSid && !accountSid.includes('••••') ? accountSid : existing.accountSid,
    authToken: authToken && !authToken.includes('••••') ? authToken : existing.authToken,
    fromPhone: fromPhone !== undefined ? fromPhone : existing.fromPhone,
    enabled: enabled !== undefined ? enabled : true
  };
  saveSmsConfig(updated);
  centralDb.logAudit('SMS_CONFIG_UPDATE', `SMS Gateway updated for provider: ${updated.provider}`, auth.actor.uid);
  res.json({ success: true, message: 'SMS Gateway configuration updated successfully.' });
});

app.post('/api/sms/test', async (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const targetPhone = req.body?.phone || '8101352105';
  const testOtp = String(Math.floor(100000 + Math.random() * 900000));
  const result = await dispatchSms(targetPhone, `MUN COMPUTER SMS Gateway Test: Your code is ${testOtp}.`, testOtp);
  if (result.success) return res.json({ success: true, message: result.message });
  return res.status(502).json({ success: false, message: result.message });
});

// ---------------------------------------------------------------------------
// ADMIN-CONTROLLED CUSTOM UPI QR CODE & PAYMENT SETTINGS
// ---------------------------------------------------------------------------
app.get('/api/settings/upi', (req, res) => {
  const auth = resolveActor(req, true);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const settings = loadUpiSettings();
  res.json({ success: true, settings });
});

app.post('/api/settings/upi', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });

  const body = req.body || {};
  const existing = loadUpiSettings();
  const upiId = body.upiId !== undefined ? String(body.upiId).trim() : existing.upiId;
  const upiDisplayName = body.upiDisplayName !== undefined ? String(body.upiDisplayName).trim() : existing.upiDisplayName;
  const paymentInstructions = body.paymentInstructions !== undefined ? String(body.paymentInstructions).trim() : existing.paymentInstructions;
  const clearQr = body.clearQr === true;

  let qrImageDataUrl = existing.qrImageDataUrl;
  let qrImageMime = existing.qrImageMime;
  let qrFileName = existing.qrFileName;

  if (clearQr) {
    qrImageDataUrl = '';
    qrImageMime = '';
    qrFileName = '';
  } else if (typeof body.qrImageDataUrl === 'string' && body.qrImageDataUrl.length > 0) {
    const match = body.qrImageDataUrl.match(/^data:(image\/(?:png|jpeg|jpg|webp));base64,([A-Za-z0-9+/=]+)$/i);
    if (!match) {
      return res.status(400).json({
        success: false,
        message: 'Invalid QR image format. Only JPG, JPEG, PNG, and WebP images are supported.'
      });
    }
    const approxBytes = Math.ceil((match[2].length * 3) / 4);
    if (approxBytes > 4 * 1024 * 1024) {
      return res.status(400).json({
        success: false,
        message: 'QR image file exceeds 4 MB limit.'
      });
    }
    qrImageMime = match[1].toLowerCase() === 'image/jpg' ? 'image/jpeg' : match[1].toLowerCase();
    qrImageDataUrl = body.qrImageDataUrl;
    qrFileName = String(body.qrFileName || 'upi-qr-code').trim().slice(0, 140);
  }

  const updated: UpiPaymentSettings = {
    upiId,
    upiDisplayName,
    paymentInstructions,
    qrImageDataUrl,
    qrImageMime,
    qrFileName,
    updatedAt: new Date().toISOString(),
    updatedByUid: auth.actor.uid,
    updatedByName: auth.actor.name
  };

  saveUpiSettings(updated);
  centralDb.logAudit(
    'UPI_SETTINGS_UPDATE',
    `Admin ${auth.actor.name} updated UPI Payment Settings (UPI ID: ${upiId || 'Not Set'}, QR: ${qrImageDataUrl ? 'Uploaded' : 'Cleared/Empty'})`,
    auth.actor.uid
  );
  res.json({ success: true, settings: updated, message: 'UPI Payment Settings saved successfully.' });
});

app.delete('/api/settings/upi/qr', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const existing = loadUpiSettings();
  const updated: UpiPaymentSettings = {
    ...existing,
    qrImageDataUrl: '',
    qrImageMime: '',
    qrFileName: '',
    updatedAt: new Date().toISOString(),
    updatedByUid: auth.actor.uid,
    updatedByName: auth.actor.name
  };
  saveUpiSettings(updated);
  centralDb.logAudit('UPI_QR_REMOVED', `Admin ${auth.actor.name} removed uploaded UPI QR Code image.`, auth.actor.uid);
  res.json({ success: true, settings: updated, message: 'UPI QR Code removed.' });
});

// ---------------------------------------------------------------------------
// ALL-INDIA LOCATION + MURSHIDABAD MASTER & DOMKAL MUNICIPALITY 21-WARD APIs
// ---------------------------------------------------------------------------
app.get('/api/locations/states', (req, res) => {
  const states = locationService.getStates();
  res.json({ success: true, states, count: states.length });
});

app.get('/api/locations/districts', (req, res) => {
  const state = String(req.query.state || '');
  if (!state) return res.json({ success: true, districts: [], count: 0 });
  const districts = locationService.getDistricts(state);
  res.json({ success: true, state, districts, count: districts.length });
});

app.get('/api/locations/villages', async (req, res) => {
  const state = String(req.query.state || '');
  const district = String(req.query.district || '');
  const q = String(req.query.q || '');
  if (!district) return res.json({ success: true, villages: [], entries: [] });
  const result = await locationService.getVillages(state, district, q);
  res.json({ success: true, ...result });
});

app.get('/api/locations/post-offices', (req, res) => {
  const result = locationService.getPostOffices(
    String(req.query.state || ''),
    String(req.query.district || ''),
    String(req.query.village || '')
  );
  res.json({ success: true, ...result });
});

app.get('/api/locations/police-stations', (req, res) => {
  const result = locationService.getPoliceStations(
    String(req.query.state || ''),
    String(req.query.district || ''),
    String(req.query.village || ''),
    String(req.query.postOffice || '')
  );
  res.json({ success: true, ...result });
});

app.get('/api/locations/pincodes', (req, res) => {
  const result = locationService.getPincodes(
    String(req.query.state || ''),
    String(req.query.district || ''),
    String(req.query.village || ''),
    String(req.query.postOffice || ''),
    String(req.query.policeStation || '')
  );
  res.json({ success: true, ...result });
});

app.get('/api/locations/pincode/:pin', async (req, res) => {
  const result = await locationService.lookupByPincode(String(req.params.pin || ''));
  res.json({ success: true, ...result });
});

app.post('/api/locations/custom', (req, res) => {
  const result = locationService.addCustomLocation(req.body || {});
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

// Murshidabad Master & Domkal Municipality (LGD 273007) Routes
app.get('/api/locations/murshidabad/overview', (req, res) => {
  res.json({ success: true, ...murshidabadMaster.getOverview() });
});

app.get('/api/locations/murshidabad/hierarchy', (req, res) => {
  const data = murshidabadMaster.getHierarchy({
    areaType: req.query.areaType === 'URBAN' ? 'URBAN' : 'RURAL',
    subdivision: req.query.subdivision ? String(req.query.subdivision) : undefined,
    block: req.query.block ? String(req.query.block) : undefined,
    gp: req.query.gp ? String(req.query.gp) : undefined,
    municipality: req.query.municipality
      ? String(req.query.municipality)
      : (req.query.municipalityLgd ? String(req.query.municipalityLgd) : 'Domkal Municipality'),
    ward: req.query.wardCode
      ? String(req.query.wardCode)
      : (req.query.ward ? String(req.query.ward) : undefined),
    mouza: req.query.mouza ? String(req.query.mouza) : undefined
  });
  res.json({ success: true, ...data });
});

app.get('/api/locations/domkal-wards', (req, res) => {
  const wardCode = req.query.wardCode ? String(req.query.wardCode) : undefined;
  const hierarchy = murshidabadMaster.getHierarchy({
    areaType: 'URBAN',
    municipality: 'Domkal Municipality',
    ward: wardCode
  });
  const wards = murshidabadMaster.getDomkalWardsFull(wardCode);
  res.json({
    success: true,
    wards,
    mouzas: hierarchy.mouzas,
    localities: hierarchy.localities,
    pollingStations: hierarchy.pollingStations
  });
});

app.get('/api/locations/search', (req, res) => {
  const q = String(req.query.q || '');
  const results = murshidabadMaster.searchLocations(q);
  res.json({ success: true, total: results.length, results });
});

app.post('/api/locations/import/preview', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const rows = Array.isArray(req.body?.rows) ? req.body.rows : [];
  const preview = murshidabadMaster.previewImportRows(rows);
  res.json({ success: true, preview });
});

app.post('/api/locations/import/commit', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const batch = murshidabadMaster.commitImportBatch({
    fileName: String(req.body?.fileName || 'manual-import.csv'),
    sourceName: String(req.body?.sourceName || 'Admin Import'),
    sourceUrlOrDocument: String(req.body?.sourceUrlOrDocument || 'Official Upload'),
    sourceDate: String(req.body?.sourceDate || new Date().toISOString().split('T')[0]),
    importedBy: auth.actor.uid,
    rows: Array.isArray(req.body?.rows) ? req.body.rows : []
  });
  centralDb.logAudit('LOCATION_IMPORT_COMMITTED', `Location batch ${batch.importId} staged (${batch.totalRows} rows) by ${auth.actor.uid}`, auth.actor.uid);
  res.json({ success: true, batch });
});

app.get('/api/locations/import/batches', (req, res) => {
  res.json({ success: true, batches: murshidabadMaster.getImportBatches() });
});

app.post('/api/locations/verify', (req, res) => {
  const auth = verifySuperAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const { targetType, targetId, localityId, action, decision, correctedEnglishName, pinCode, mouzaName, postOffice } = req.body || {};
  const resolvedId = String(targetId || localityId || '');
  const resolvedType: 'LOCALITY' | 'RURAL_VILLAGE' | 'IMPORT_BATCH' =
    targetType === 'IMPORT_BATCH' || targetType === 'RURAL_VILLAGE' ? targetType : 'LOCALITY';
  const rawDecision = String(decision || action || 'APPROVE').toUpperCase();
  const resolvedDecision: 'APPROVE' | 'REJECT' | 'EDIT' =
    rawDecision === 'REJECT' ? 'REJECT' : (rawDecision === 'EDIT' ? 'EDIT' : 'APPROVE');
  const result = murshidabadMaster.verifyLocalityOrImport({
    targetType: resolvedType,
    targetId: resolvedId,
    decision: resolvedDecision,
    correctedEnglishName,
    pinCode,
    mouzaName,
    postOffice,
    actorUid: auth.actor.uid
  });
  if (!result.success) return res.status(404).json(result);
  centralDb.logAudit('LOCATION_VERIFICATION', `${resolvedDecision} ${resolvedType} ${resolvedId} by ${auth.actor.uid}`, auth.actor.uid);
  res.json({ ...result, message: `Location record ${resolvedId} ${resolvedDecision.toLowerCase()}d.` });
});

app.post('/api/locations/polling-station', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const station = murshidabadMaster.addPollingStation({
    wardCode: String(req.body?.wardCode || 'WARD 01'),
    psNumber: String(req.body?.psNumber || ''),
    psName: String(req.body?.psName || ''),
    buildingOrLocality: String(req.body?.buildingOrLocality || ''),
    sourceName: String(req.body?.sourceName || 'CP_01.pdf (Verified Upload)'),
    sourceDate: String(req.body?.sourceDate || new Date().toISOString().split('T')[0]),
    actorUid: auth.actor.uid
  });
  centralDb.logAudit('POLLING_STATION_ADDED', `Added Polling Station ${station.psNumber} (${station.wardCode}) by ${auth.actor.uid}`, auth.actor.uid);
  res.json({ success: true, station });
});

// Unified Murshidabad Village & Municipality Locality CRUD, Auto-Verify Add & Export
app.get('/api/locations/villages/master', (req, res) => {
  const entries = murshidabadMaster.listAllEntries({
    areaType: req.query.areaType ? String(req.query.areaType) : 'ALL',
    blockOrMunicipality: req.query.blockOrMunicipality ? String(req.query.blockOrMunicipality) : '',
    gpOrWard: req.query.gpOrWard ? String(req.query.gpOrWard) : '',
    pinCode: req.query.pinCode ? String(req.query.pinCode) : '',
    q: req.query.q ? String(req.query.q) : '',
    verificationStatus: req.query.verificationStatus ? String(req.query.verificationStatus) : 'ALL'
  });
  res.json({ success: true, total: entries.length, entries });
});

app.post('/api/locations/villages', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.addVillageOrLocality(req.body || {}, auth.actor.uid);
  if (!result.success) return res.status(result.duplicate ? 409 : 400).json(result);
  centralDb.logAudit('LOCATION_ADDED', result.message, auth.actor.uid);
  res.json(result);
});

app.post('/api/locations/villages/auto-add', async (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(401).json({ success: false, message: auth.error });
  const body = req.body || {};
  const cleanPin = String(body.pinCode || '').replace(/[^0-9]/g, '').slice(0, 6);
  if (cleanPin.length !== 6) {
    return res.status(400).json({ success: false, message: 'Valid 6-digit Indian PIN Code is required for verification.' });
  }
  const lookup = await locationService.lookupByPincode(cleanPin);
  const result = murshidabadMaster.verifyAndAutoAddMissingVillage(
    {
      areaType: body.areaType === 'URBAN' ? 'URBAN' : 'RURAL',
      blockOrMunicipality: String(body.blockOrMunicipality || 'Domkal'),
      gpOrWard: body.gpOrWard ? String(body.gpOrWard) : undefined,
      name: String(body.name || ''),
      pinCode: cleanPin,
      postOffice: body.postOffice ? String(body.postOffice) : undefined,
      policeStation: body.policeStation ? String(body.policeStation) : undefined
    },
    { found: lookup.found, records: lookup.entries },
    auth.actor.uid
  );
  if (!result.success) return res.status(result.duplicate ? 409 : 400).json(result);
  centralDb.logAudit('LOCATION_AUTO_VERIFIED', result.message, auth.actor.uid);
  res.json(result);
});

app.put('/api/locations/villages/:id', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.editVillageOrLocality(String(req.params.id), req.body || {}, auth.actor.uid);
  if (!result.success) return res.status(result.duplicate ? 409 : 404).json(result);
  centralDb.logAudit('LOCATION_UPDATED', result.message, auth.actor.uid);
  res.json(result);
});

app.delete('/api/locations/villages/:id', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.deleteVillageOrLocality(String(req.params.id));
  if (!result.success) return res.status(404).json(result);
  centralDb.logAudit('LOCATION_DELETED', result.message, auth.actor.uid);
  res.json(result);
});

app.get('/api/locations/villages/export', (req, res) => {
  const rows = murshidabadMaster.getExportRows({
    areaType: req.query.areaType ? String(req.query.areaType) : 'ALL',
    blockOrMunicipality: req.query.blockOrMunicipality ? String(req.query.blockOrMunicipality) : '',
    gpOrWard: req.query.gpOrWard ? String(req.query.gpOrWard) : '',
    pinCode: req.query.pinCode ? String(req.query.pinCode) : '',
    q: req.query.q ? String(req.query.q) : '',
    verificationStatus: req.query.verificationStatus ? String(req.query.verificationStatus) : 'ALL'
  });

  if (String(req.query.format || '').toLowerCase() === 'csv') {
    const headers = ['areaType', 'district', 'subdivisionOrMunicipality', 'blockOrWard', 'gpOrMouza', 'villageOrLocality', 'originalSpelling', 'postOffice', 'policeStation', 'pinCode', 'verificationStatus', 'sourceName'];
    const escapeCsv = (val: any) => `"${String(val ?? '').replace(/"/g, '""')}"`;
    const csvLines = [headers.join(','), ...rows.map(r => headers.map(h => escapeCsv((r as any)[h])).join(','))];
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="murshidabad-villages-pincodes.csv"');
    return res.send(csvLines.join('\r\n'));
  }

  res.json({ success: true, total: rows.length, rows });
});

// ---------------------------------------------------------------------------
// ONE GLOBAL SEQUENTIAL SERIAL NUMBER SYSTEM APIs
// ---------------------------------------------------------------------------
app.get('/api/serial/current', (req, res) => {
  const previewPrefix = req.query.prefix ? String(req.query.prefix) : 'CUST';
  const status = centralDb.getGlobalSerialStatus(previewPrefix);
  res.json({ success: true, ...status });
});

app.post('/api/serial/next', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(401).json({ success: false, message: auth.error });
  const prefix = String(req.body?.prefix || 'REC').trim().toUpperCase();
  const allocated = centralDb.allocateGlobalSerial(prefix);
  res.json({ success: true, ...allocated });
});

app.post('/api/serial/sync', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(401).json({ success: false, message: auth.error });
  const { serial, id, year2 } = req.body || {};
  const status = centralDb.syncGlobalSerialFloor(id || serial || 0, year2 ? String(year2) : undefined);
  res.json({ success: true, ...status });
});

// ---------------------------------------------------------------------------
// ADMIN LOCATION MASTER CRUD: BLOCKS, GPs, POST OFFICES, POLICE STATIONS, PIN CODES
// ---------------------------------------------------------------------------
app.get('/api/locations/blocks', (req, res) => {
  const subdivision = req.query.subdivision ? String(req.query.subdivision) : undefined;
  const blocks = murshidabadMaster.listBlocks(subdivision);
  res.json({ success: true, total: blocks.length, blocks });
});

app.post('/api/locations/blocks', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.addBlock(req.body || {});
  if (!result.success) return res.status(400).json(result);
  centralDb.logAudit('LOCATION_BLOCK_ADDED', result.message, auth.actor.uid);
  res.json(result);
});

app.put('/api/locations/blocks/:id', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.editBlock(String(req.params.id), req.body || {});
  if (!result.success) return res.status(404).json(result);
  centralDb.logAudit('LOCATION_BLOCK_UPDATED', result.message, auth.actor.uid);
  res.json(result);
});

app.get('/api/locations/gram-panchayats', (req, res) => {
  const blockName = req.query.blockName ? String(req.query.blockName) : undefined;
  const gramPanchayats = murshidabadMaster.listGramPanchayats(blockName);
  res.json({ success: true, total: gramPanchayats.length, gramPanchayats });
});

app.post('/api/locations/gram-panchayats', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.addGramPanchayat(req.body || {});
  if (!result.success) return res.status(400).json(result);
  centralDb.logAudit('LOCATION_GP_ADDED', result.message, auth.actor.uid);
  res.json(result);
});

app.put('/api/locations/gram-panchayats/:id', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.editGramPanchayat(String(req.params.id), req.body || {});
  if (!result.success) return res.status(404).json(result);
  centralDb.logAudit('LOCATION_GP_UPDATED', result.message, auth.actor.uid);
  res.json(result);
});

app.get('/api/locations/post-offices-master', (req, res) => {
  const postOffices = murshidabadMaster.listPostOfficesMaster();
  res.json({ success: true, total: postOffices.length, postOffices });
});

app.post('/api/locations/post-offices-master', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.addPostOffice(req.body || {});
  if (!result.success) return res.status(400).json(result);
  centralDb.logAudit('LOCATION_PO_ADDED', result.message, auth.actor.uid);
  res.json(result);
});

app.put('/api/locations/post-offices-master/:id', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.editPostOffice(String(req.params.id), req.body || {});
  if (!result.success) return res.status(404).json(result);
  centralDb.logAudit('LOCATION_PO_UPDATED', result.message, auth.actor.uid);
  res.json(result);
});

app.get('/api/locations/police-stations-master', (req, res) => {
  const policeStations = murshidabadMaster.listPoliceStationsMaster();
  res.json({ success: true, total: policeStations.length, policeStations });
});

app.post('/api/locations/police-stations-master', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.addPoliceStation(req.body || {});
  if (!result.success) return res.status(400).json(result);
  centralDb.logAudit('LOCATION_PS_ADDED', result.message, auth.actor.uid);
  res.json(result);
});

app.put('/api/locations/police-stations-master/:id', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.editPoliceStation(String(req.params.id), req.body || {});
  if (!result.success) return res.status(404).json(result);
  centralDb.logAudit('LOCATION_PS_UPDATED', result.message, auth.actor.uid);
  res.json(result);
});

app.get('/api/locations/pincodes-master', (req, res) => {
  const pinCodes = murshidabadMaster.listPinCodesMaster();
  res.json({ success: true, total: pinCodes.length, pinCodes });
});

app.post('/api/locations/pincodes-master', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.addPinCode(req.body || {});
  if (!result.success) return res.status(400).json(result);
  centralDb.logAudit('LOCATION_PIN_ADDED', result.message, auth.actor.uid);
  res.json(result);
});

app.put('/api/locations/pincodes-master/:id', (req, res) => {
  const auth = verifyManagerOrAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.editPinCode(String(req.params.id), req.body || {});
  if (!result.success) return res.status(404).json(result);
  centralDb.logAudit('LOCATION_PIN_UPDATED', result.message, auth.actor.uid);
  res.json(result);
});

// ---------------------------------------------------------------------------
// ANNAPURNA YOJANA – DYNAMIC WARD & VILLAGE MASTER API (ADMIN PROTECTED MUTATIONS)
// ---------------------------------------------------------------------------
app.get('/api/locations/ward-master', (req, res) => {
  const includeInactive = req.query.includeInactive !== 'false';
  const includeDeleted = req.query.includeDeleted === 'true';
  const wardId = req.query.wardId ? String(req.query.wardId) : undefined;
  const q = req.query.q ? String(req.query.q) : undefined;
  const data = murshidabadMaster.getWardVillageMaster({ includeInactive, includeDeleted, wardId, q });
  res.json({ success: true, ...data });
});

app.post('/api/locations/ward-master/wards', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.addMasterWard(req.body || {}, auth.actor.uid);
  if (!result.success) return res.status(result.duplicate ? 409 : 400).json(result);
  centralDb.logAudit('WARD_MASTER_ADD', result.message, auth.actor.uid);
  res.json({ ...result, master: murshidabadMaster.getWardVillageMaster({ includeInactive: true }) });
});

app.put('/api/locations/ward-master/wards/:wardId', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.editMasterWard(String(req.params.wardId), req.body || {}, auth.actor.uid);
  if (!result.success) return res.status(result.duplicate ? 409 : 404).json(result);
  centralDb.logAudit('WARD_MASTER_UPDATE', result.message, auth.actor.uid);
  res.json({ ...result, master: murshidabadMaster.getWardVillageMaster({ includeInactive: true }) });
});

app.delete('/api/locations/ward-master/wards/:wardId', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const mode = (req.body?.mode || req.query?.mode) === 'soft' ? 'soft' : 'permanent';
  const reassignToWardId = req.body?.reassignToWardId || req.query?.reassignToWardId;
  const forceCascadeDeactivate = Boolean(req.body?.forceCascadeDeactivate === true || req.query?.forceCascadeDeactivate === 'true');
  const result = murshidabadMaster.deleteMasterWard(
    String(req.params.wardId),
    {
      mode,
      reassignToWardId: reassignToWardId ? String(reassignToWardId) : undefined,
      forceCascadeDeactivate
    },
    auth.actor.uid
  );
  if (!result.success) return res.status(result.blocked ? 409 : 400).json(result);
  centralDb.logAudit('WARD_MASTER_DELETE', result.message, auth.actor.uid);
  res.json({ ...result, master: murshidabadMaster.getWardVillageMaster({ includeInactive: true }) });
});

app.post('/api/locations/ward-master/villages', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.addMasterWardVillage(req.body || {}, auth.actor.uid);
  if (!result.success) return res.status(result.duplicate ? 409 : 400).json(result);
  centralDb.logAudit('WARD_VILLAGE_ADD', result.message, auth.actor.uid);
  res.json({ ...result, master: murshidabadMaster.getWardVillageMaster({ includeInactive: true }) });
});

app.put('/api/locations/ward-master/villages/:id', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.editMasterWardVillage(String(req.params.id), req.body || {}, auth.actor.uid);
  if (!result.success) return res.status(result.duplicate ? 409 : 400).json(result);
  centralDb.logAudit('WARD_VILLAGE_UPDATE', result.message, auth.actor.uid);
  res.json({ ...result, master: murshidabadMaster.getWardVillageMaster({ includeInactive: true }) });
});

app.delete('/api/locations/ward-master/villages/:id', (req, res) => {
  const auth = verifyAdminActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 403).json({ success: false, message: auth.error });
  const result = murshidabadMaster.deleteMasterWardVillage(String(req.params.id), auth.actor.uid);
  if (!result.success) return res.status(404).json(result);
  centralDb.logAudit('WARD_VILLAGE_DELETE', result.message, auth.actor.uid);
  res.json({ ...result, master: murshidabadMaster.getWardVillageMaster({ includeInactive: true }) });
});

// ---------------------------------------------------------------------------
// ANNAPURNA YOJANA APPLICATIONS MULTI-USER PERSISTENCE API
// ---------------------------------------------------------------------------
app.get('/api/annapurna/applications', (_req, res) => {
  const applications = centralDb.listAnnapurnaApplications();
  res.json({ success: true, total: applications.length, applications });
});

app.post('/api/annapurna/applications', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const result = centralDb.upsertAnnapurnaApplication(req.body || {}, auth.actor.uid);
  if (!result.success) return res.status(400).json(result);
  res.json(result);
});

app.post('/api/annapurna/sync', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const incoming = Array.isArray(req.body?.applications) ? req.body.applications : [];
  const result = centralDb.syncAnnapurnaApplications(incoming, auth.actor.uid);
  res.json(result);
});

app.delete('/api/annapurna/applications/:id', (req, res) => {
  const auth = resolveActor(req);
  if (!auth.ok || !auth.actor) return res.status(auth.code || 401).json({ success: false, message: auth.error });
  const result = centralDb.deleteAnnapurnaApplication(String(req.params.id), auth.actor.uid);
  res.json(result);
});

// ---------------------------------------------------------------------------
// VITE OR STATIC FRONTEND MOUNT
// ---------------------------------------------------------------------------
async function startServer() {
  initializeUsers();
  locationService.init();
  murshidabadMaster.init();
  centralDb.init();

  // Automatic Daily Data Backup Scheduler (every 6 hours + initial snapshot if none today)
  try {
    const todayPrefix = `BKP-${getKolkataDateParts().isoDate}`;
    const existingSnapshots = centralDb.listBackupSnapshots();
    if (!existingSnapshots.some(s => s.id.startsWith(todayPrefix))) {
      centralDb.createAutoBackupSnapshot(SUPER_ADMIN_UID, 'AUTO');
    }
    setInterval(() => {
      try {
        centralDb.createAutoBackupSnapshot(SUPER_ADMIN_UID, 'AUTO');
      } catch {
        // non-blocking
      }
    }, 6 * 60 * 60 * 1000);
  } catch {
    // non-blocking
  }

  app.use('/api', (_req: Request, res: Response) => {
    res.status(404).json({ success: false, message: 'API endpoint not found.' });
  });

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`[MUN COMPUTER — CENTRAL AUTHORITY] Full-Stack Server listening on port ${PORT}`);
  });
}

startServer();
