/**
 * notifications.js - In-App Notification Center & Deadline Alerts
 * MUN COMPUTER Business Manager
 */

import { getItem, setItem, KEYS, getTodayDate } from './storage.js';
import { getAllFollowups, get90DayDashboardData, getSmartReminders } from './followups.js';
import { getCustomerDuesReport } from './payments.js';

export function getSystemNotifications() {
  const notifications = [];
  const today = getTodayDate();

  // 1. Overdue and Today's Follow-ups (Legacy + 90-Day Case Management)
  const followups = getAllFollowups();
  const caseDashboard = get90DayDashboardData();
  const overdueFollowups = followups.filter(f => f.status === 'Overdue');
  const todayFollowups = followups.filter(f => f.status === 'Today');
  const overdueCases = caseDashboard.buckets.overdue || [];
  const todayCases = caseDashboard.buckets.today || [];
  const review90Cases = caseDashboard.buckets.review90 || [];
  const smartReminders = getSmartReminders({ filter: 'pending' });
  const overdueReminders = smartReminders.filter(r => r.isOverdue);
  const dueTodayReminders = smartReminders.filter(r => r.reminderDate === today && !r.isOverdue);
  const upcomingReminders = smartReminders.filter(r => r.isUpcoming && r.reminderDate > today);

  const totalOverdue = overdueFollowups.length + overdueCases.length + overdueReminders.length;
  const totalToday = todayFollowups.length + todayCases.length + dueTodayReminders.length;

  if (totalOverdue > 0) {
    const names = [
      ...overdueCases.map(c => c.customerName),
      ...overdueFollowups.map(f => f.customerName),
      ...overdueReminders.map(r => `${r.customerName} (${r.reminderType})`)
    ].filter(Boolean);
    notifications.push({
      id: 'notif-flw-overdue',
      type: 'danger',
      title: `${totalOverdue} Overdue Follow-up / Reminder Alert(s)`,
      message: `Immediate action needed: ${names.slice(0, 2).join(', ')}${names.length > 2 ? ' and others' : ''}.`,
      actionRoute: overdueReminders.length > 0 && overdueCases.length === 0 ? 'followups-reminders' : 'followups-overdue',
      time: 'Urgent'
    });
  }

  if (totalToday > 0) {
    const names = [
      ...todayCases.map(c => c.customerName),
      ...todayFollowups.map(f => f.customerName),
      ...dueTodayReminders.map(r => `${r.customerName} @ ${r.reminderTime}`)
    ].filter(Boolean);
    notifications.push({
      id: 'notif-flw-today',
      type: 'warning',
      title: `${totalToday} Scheduled Today (Follow-ups & Reminders)`,
      message: `Due today: ${names.slice(0, 2).join(', ')}${names.length > 2 ? ' and others' : ''}.`,
      actionRoute: dueTodayReminders.length > 0 && todayCases.length === 0 ? 'followups-reminders' : 'followups-today',
      time: 'Today'
    });
  }

  if (overdueReminders.length > 0 || dueTodayReminders.length > 0 || upcomingReminders.length > 0) {
    const activeCount = overdueReminders.length + dueTodayReminders.length + upcomingReminders.length;
    const sample = [...overdueReminders, ...dueTodayReminders, ...upcomingReminders][0];
    notifications.push({
      id: 'notif-reminders-due',
      type: overdueReminders.length > 0 ? 'danger' : 'info',
      title: `${activeCount} Seminar / Gas Delivery / Promo Reminder(s)`,
      message: sample ? `Next: ${sample.reminderType} — ${sample.customerName} (${sample.reminderDate} ${sample.reminderTime})` : 'Scheduled reminders active.',
      actionRoute: 'followups-reminders',
      time: overdueReminders.length > 0 ? 'Due Now' : 'Scheduled'
    });
  }

  if (review90Cases.length > 0) {
    notifications.push({
      id: 'notif-90d-review',
      type: 'info',
      title: `${review90Cases.length} Application(s) in 90-Day Review`,
      message: `Final cycle check ready for ${review90Cases.slice(0, 2).map(c => c.applicationId).join(', ')}.`,
      actionRoute: 'followups-review90',
      time: 'Day 75–90'
    });
  }

  // 2. High Customer Dues
  const dues = getCustomerDuesReport();
  const highDues = dues.filter(d => d.totalDue >= 100);
  if (highDues.length > 0) {
    const totalDueSum = dues.reduce((sum, d) => sum + d.totalDue, 0);
    notifications.push({
      id: 'notif-dues',
      type: 'warning',
      title: `Pending Customer Dues: ₹${totalDueSum.toLocaleString('en-IN')}`,
      message: `${dues.length} customer(s) have outstanding balances pending collection.`,
      actionRoute: 'payments',
      time: 'Financial'
    });
  }

  // 3. Expiring Documents
  const documents = getItem(KEYS.DOCUMENTS, []);
  const expiringDocs = documents.filter(doc => {
    if (!doc.expiryDate) return false;
    const expiry = new Date(doc.expiryDate);
    const now = new Date();
    const diffDays = Math.ceil((expiry - now) / (1000 * 60 * 60 * 24));
    return diffDays >= 0 && diffDays <= 60;
  });

  if (expiringDocs.length > 0) {
    notifications.push({
      id: 'notif-docs-expiring',
      type: 'info',
      title: `${expiringDocs.length} Document(s) Expiring Soon`,
      message: `Renewal needed: ${expiringDocs.map(d => d.name).join(', ')}.`,
      actionRoute: 'documents',
      time: 'Compliance'
    });
  }

  // 4. Pending Staff Tasks
  const tasks = getItem(KEYS.TASKS, []).filter(t => t.status === 'Pending' && t.deadline <= today);
  if (tasks.length > 0) {
    notifications.push({
      id: 'notif-tasks-pending',
      type: 'info',
      title: `${tasks.length} Pending Daily Staff Task(s)`,
      message: `Tasks due today need submission or review.`,
      actionRoute: 'tasks',
      time: 'Operations'
    });
  }

  return notifications;
}

/**
 * Checks pending reminders against current local date & time (HH:mm).
 * Marks triggered reminders with `notifiedAt` so they don't repeat endlessly,
 * and returns newly due reminders for live toast / notification banners.
 */
export function checkDueDateTimeReminders() {
  const rawList = getItem(KEYS.REMINDERS, []);
  if (!Array.isArray(rawList) || rawList.length === 0) return [];

  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const hh = String(now.getHours()).padStart(2, '0');
  const mm = String(now.getMinutes()).padStart(2, '0');
  const nowKey = `${y}-${m}-${d} ${hh}:${mm}`;
  const nowIso = now.toISOString();

  const triggered = [];
  let changed = false;

  const updated = rawList.map(r => {
    if (!r || r.enabled === false) return r;
    if (r.status === 'Completed' || r.status === 'COMPLETED') return r;
    if (r.notifiedAt) return r;
    const rDate = String(r.reminderDate || '').slice(0, 10);
    if (!rDate) return r;
    const rTime = String(r.reminderTime || '09:00').slice(0, 5);
    const dueKey = `${rDate} ${rTime}`;
    if (dueKey <= nowKey) {
      changed = true;
      const item = { ...r, notifiedAt: nowIso };
      triggered.push(item);
      return item;
    }
    return r;
  });

  if (changed) {
    setItem(KEYS.REMINDERS, updated);
  }
  return triggered;
}
