/**
 * reports.js - Centralized Financial Analytics, P&L, PDF, Excel & CSV Export
 * MUN COMPUTER BUSINESS MANAGER - Enterprise ERP
 * Location: Mamudpur, Juginda, Domkal, Murshidabad
 */

import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';

import { getItem, KEYS, formatINR, numberToWords, formatDate, formatDateTime, getTodayDate } from './storage.js';
import { drawBwPdfHeader, getBwAutoTableStyles, finalizeBwPdfPagination } from './documentEngine.js';

function toLocalIsoDate(d) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getFilteredDateRange(preset = 'month', customStart = null, customEnd = null) {
  const now = new Date();
  const todayStr = getTodayDate();

  if (preset === 'custom' && customStart && customEnd) {
    return { start: customStart, end: customEnd };
  }

  if (preset === 'today') {
    return { start: todayStr, end: todayStr };
  }

  if (preset === 'yesterday') {
    const y = new Date(now);
    y.setDate(y.getDate() - 1);
    const yStr = toLocalIsoDate(y);
    return { start: yStr, end: yStr };
  }

  if (preset === 'week') {
    const day = now.getDay();
    const diff = now.getDate() - day + (day === 0 ? -6 : 1); // Monday
    const startOfWeek = new Date(now.getFullYear(), now.getMonth(), diff);
    return { start: toLocalIsoDate(startOfWeek), end: todayStr };
  }

  if (preset === 'month') {
    const s = new Date(now.getFullYear(), now.getMonth(), 1);
    return { start: toLocalIsoDate(s), end: todayStr };
  }

  if (preset === 'last_month') {
    const s = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const e = new Date(now.getFullYear(), now.getMonth(), 0);
    return { start: toLocalIsoDate(s), end: toLocalIsoDate(e) };
  }

  if (preset === 'quarter') {
    const qMonth = Math.floor(now.getMonth() / 3) * 3;
    const s = new Date(now.getFullYear(), qMonth, 1);
    return { start: toLocalIsoDate(s), end: todayStr };
  }

  if (preset === 'year') {
    const s = new Date(now.getFullYear(), 0, 1);
    return { start: toLocalIsoDate(s), end: todayStr };
  }

  // fallback all
  return { start: '2020-01-01', end: '2099-12-31' };
}

function classifyModeBucket(rawMethod) {
  const m = String(rawMethod || 'Cash').trim().toLowerCase();
  if (!m || m === 'cash') return 'CASH';
  if (m === 'upi' || m.includes('qr') || m.includes('phonepe') || m.includes('gpay') || m.includes('paytm')) return 'UPI';
  if (m === 'due' || m === 'credit') return 'DUE';
  return 'BANK';
}

export function generateFinancialSummary(unitId = 'all', dateFilter = 'month', customStart = null, customEnd = null) {
  const { start, end } = getFilteredDateRange(dateFilter, customStart, customEnd);
  const unitMatch = () => true;

  const allServices = getItem(KEYS.SERVICES, []);
  const allPayments = getItem(KEYS.PAYMENTS, []);
  const allExpenses = getItem(KEYS.EXPENSES, []);
  const allCustomers = getItem(KEYS.CUSTOMERS, []);
  const allInvoices = getItem(KEYS.INVOICES, []);
  const allBanking = getItem(KEYS.BANKING, []);
  const allInvestments = getItem(KEYS.INVESTMENTS, []);
  const allDaybook = getItem(KEYS.DAYBOOK, []);
  const allCounterTxns = getItem(KEYS.COUNTER_CASH_TXNS, []);

  const services = allServices.filter(s => s.appDate >= start && s.appDate <= end && unitMatch(s));
  const payments = allPayments.filter(p => p.paymentDate >= start && p.paymentDate <= end && unitMatch(p));
  const expenses = allExpenses.filter(e => e.date >= start && e.date <= end && unitMatch(e));
  const customers = allCustomers.filter(c => c.regDate >= start && c.regDate <= end && unitMatch(c));
  const invoices = allInvoices.filter(i => i.date >= start && i.date <= end && unitMatch(i));
  const banking = allBanking.filter(b => b.date >= start && b.date <= end && unitMatch(b));
  const investments = allInvestments.filter(inv => (inv.investmentDate || inv.date || '') >= start && (inv.investmentDate || inv.date || '') <= end);

  // 1. Gross billed amount (service requests + standalone invoices not linked to services)
  const serviceBilled = services.reduce((sum, s) => sum + (Number(s.totalAmount) || 0), 0);
  const standaloneInvoiceBilled = invoices
    .filter(inv => !inv.serviceId)
    .reduce((sum, inv) => sum + (Number(inv.totalAmount) || 0), 0);
  const grossBilled = serviceBilled + standaloneInvoiceBilled;

  // 2. Real collected cash/UPI/Bank revenue (never counting banking principal or capital)
  const collectedRevenue = payments.reduce((sum, p) => sum + (Number(p.paymentAmount) || 0), 0);

  // 3. Outstanding customer dues
  const serviceDues = services.reduce((sum, s) => sum + Math.max(0, Number(s.dueAmount) || 0), 0);
  const standaloneInvoiceDues = invoices
    .filter(inv => !inv.serviceId)
    .reduce((sum, inv) => sum + Math.max(0, Number(inv.balanceDue) || 0), 0);
  const totalDues = serviceDues + standaloneInvoiceDues;

  // 4. Total actual business expenses
  const totalExpenses = expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

  // 5. PNB CSP / AePS Banking Commission (Rule 6 & 7: Principal excluded from income, ONLY earned commission counted)
  let bankingVolume = 0;
  let bankingWithdrawals = 0;
  let bankingDeposits = 0;
  let bankingTransfers = 0;
  let bankingCommission = 0;
  let bankingSuccessCount = 0;
  let bankingFailedCount = 0;
  let bankingPendingCount = 0;

  banking.forEach(b => {
    const amt = Number(b.amount) || 0;
    const comm = Number(b.commission) || 0;
    if (b.status === 'Success') {
      bankingSuccessCount++;
      bankingVolume += amt;
      bankingCommission += comm;
      if ((b.type || '').includes('Withdrawal')) bankingWithdrawals += amt;
      else if ((b.type || '').includes('Deposit')) bankingDeposits += amt;
      else if ((b.type || '').includes('Transfer')) bankingTransfers += amt;
    } else if (b.status === 'Failed') {
      bankingFailedCount++;
    } else {
      bankingPendingCount++;
    }
  });

  // 6. Operating Income & Net Profit (Rule 8 & 9: Operating Income = Service/Sales Collections + Earned Banking Commission)
  const totalOperatingIncome = collectedRevenue + bankingCommission;
  const netCashFlow = totalOperatingIncome - totalExpenses;
  const estimatedNetProfit = (grossBilled + bankingCommission) - totalExpenses;

  // 7. Separate Cash, UPI & Bank Balances (Rule 5)
  const sortedDaybook = [...allDaybook].sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
  const latestSnapshot = sortedDaybook[0] || null;
  let cashInHand = 0;
  let upiBalance = 0;
  let bankBalance = 0;

  // Compute cumulative or period-accurate separate Cash / UPI / Bank balances
  let cashPayIn = 0;
  let upiPayIn = 0;
  let bankPayIn = 0;
  allPayments.forEach(p => {
    const amt = Number(p.paymentAmount) || 0;
    const bucket = classifyModeBucket(p.paymentMethod);
    if (bucket === 'CASH') cashPayIn += amt;
    else if (bucket === 'UPI') upiPayIn += amt;
    else if (bucket === 'BANK') bankPayIn += amt;
  });

  let cashExpOut = 0;
  let upiExpOut = 0;
  let bankExpOut = 0;
  allExpenses.forEach(e => {
    const amt = Number(e.amount) || 0;
    const bucket = classifyModeBucket(e.paymentMethod);
    if (bucket === 'CASH') cashExpOut += amt;
    else if (bucket === 'UPI') upiExpOut += amt;
    else if (bucket === 'BANK') bankExpOut += amt;
  });

  let counterCashNet = 0;
  let counterUpiNet = 0;
  let counterBankNet = 0;
  allCounterTxns.forEach(t => {
    const amt = Number(t.amount) || 0;
    const bucket = classifyModeBucket(t.paymentMode);
    if (bucket === 'DUE') return;
    const isIn = t.type === 'CASH_RECEIVED' || t.type === 'CASH_WITHDRAWAL';
    const signed = isIn ? amt : -amt;
    if (bucket === 'CASH') counterCashNet += signed;
    else if (bucket === 'UPI') counterUpiNet += signed;
    else if (bucket === 'BANK') counterBankNet += signed;
  });

  if (latestSnapshot && (latestSnapshot.countedPhysicalCash !== undefined || latestSnapshot.closingCash !== undefined || latestSnapshot.expectedClosing !== undefined)) {
    cashInHand = Number(latestSnapshot.closingCash ?? latestSnapshot.countedPhysicalCash ?? latestSnapshot.expectedClosing) || 0;
  } else {
    cashInHand = cashPayIn - cashExpOut + counterCashNet;
  }
  upiBalance = upiPayIn - upiExpOut + counterUpiNet;
  bankBalance = bankPayIn - bankExpOut + counterBankNet;

  // 8. Capital & Investments (Rule 8: Never counted as operating income)
  let ownerCapitalAdded = 0;
  let ownerWithdrawals = 0;
  let totalInvestments = 0;
  allInvestments.forEach(inv => {
    const amt = Number(inv.amount) || 0;
    const cat = String(inv.category || '').toLowerCase();
    const src = String(inv.fundingType || inv.source || '').toLowerCase();
    if (cat.includes('withdrawal') || src.includes('withdrawal')) {
      ownerWithdrawals += amt;
    } else if (src.includes('capital') || cat.includes('capital')) {
      ownerCapitalAdded += amt;
      totalInvestments += amt;
    } else {
      totalInvestments += amt;
    }
  });
  const totalCapital = Math.max(0, ownerCapitalAdded - ownerWithdrawals);

  const periodInvestmentsTotal = investments.reduce((s, inv) => s + (Number(inv.amount) || 0), 0);

  return {
    dateRange: { start, end, preset: dateFilter },
    unitId,
    grossBilled,
    collectedRevenue,
    totalDues,
    totalExpenses,
    bankingCommission,
    bankingVolume,
    bankingWithdrawals,
    bankingDeposits,
    bankingTransfers,
    bankingSuccessCount,
    bankingFailedCount,
    bankingPendingCount,
    totalOperatingIncome,
    netCashFlow,
    estimatedNetProfit,
    cashInHand,
    upiBalance,
    bankBalance,
    totalCapital,
    totalInvestments,
    ownerWithdrawals,
    periodInvestmentsTotal,
    customersCount: customers.length,
    servicesCount: services.length,
    invoicesCount: invoices.length,
    paymentsCount: payments.length,
    expensesCount: expenses.length,
    bankingCount: banking.length
  };
}

/**
 * Universal autoTable wrapper to support both direct function and prototype calls
 */
function applyAutoTable(doc, options) {
  if (typeof autoTable === 'function') {
    autoTable(doc, options);
  } else if (typeof doc.autoTable === 'function') {
    doc.autoTable(options);
  }
}

export function pdfSafeText(val) {
  return String(val ?? '')
    .replace(/₹/g, 'Rs.')
    .replace(/–|—/g, '-')
    .replace(/[^\x20-\x7E]/g, ' ')
    .trim();
}

export function pdfINR(amount, showDecimals = false) {
  return formatINR(amount, showDecimals).replace(/₹/g, 'Rs.');
}

/**
 * Export arbitrary dataset to CSV (safe if headers omitted or dataset empty)
 */
export function downloadCSV(filename, rows, headers) {
  const cleanName = String(filename || 'MUN_COMPUTER_Export').replace(/\.csv$/i, '');
  const list = Array.isArray(rows) ? rows : [];
  let resolvedHeaders = Array.isArray(headers) && headers.length ? headers : [];

  if (!resolvedHeaders.length && list.length > 0 && typeof list[0] === 'object' && list[0] !== null) {
    resolvedHeaders = Object.keys(list[0]).map(k => ({
      key: k,
      label: k.replace(/_/g, ' ')
    }));
  }

  if (!list.length) {
    if (resolvedHeaders.length) {
      const headerLabels = resolvedHeaders.map(h => `"${String(h.label ?? h.key).replace(/"/g, '""')}"`).join(',');
      const blob = new Blob(['\uFEFF' + headerLabels + '\r\n'], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `${cleanName}_${getTodayDate()}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      return true;
    }
    return false;
  }

  const separator = ',';
  const keys = resolvedHeaders.map(h => h.key);
  const headerLabels = resolvedHeaders.map(h => `"${String(h.label ?? h.key).replace(/"/g, '""')}"`).join(separator);

  const csvContent = [
    headerLabels,
    ...list.map(row => {
      return keys.map(k => {
        let val = row[k];
        if (val === null || val === undefined) val = '';
        if (typeof val === 'number') return val;
        return `"${String(val).replace(/"/g, '""')}"`;
      }).join(separator);
    })
  ].join('\r\n');

  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${cleanName}_${getTodayDate()}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return true;
}

/**
 * Export arbitrary dataset to Microsoft Excel (.xlsx)
 */
export function downloadExcelSheet(filename, sheetName = 'Data', jsonRows = [], emptyNote = 'No records available') {
  const cleanName = String(filename || 'MUN_COMPUTER_Export').replace(/\.xlsx$/i, '');
  const safeSheet = String(sheetName || 'Data').slice(0, 31).replace(/[\\/?*[\]:]/g, '_');
  const rows = Array.isArray(jsonRows) && jsonRows.length > 0 ? jsonRows : [{ Note: emptyNote }];
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, safeSheet);
  XLSX.writeFile(wb, `${cleanName}_${getTodayDate()}.xlsx`);
  return true;
}

/**
 * Export tabular report to formatted PDF (A4 Landscape or Portrait)
 */
export function exportTablePDF({
  filename = 'MUN_COMPUTER_Report',
  title = 'MUN COMPUTER REPORT',
  subtitle = '',
  headers = [],
  rows = [],
  orientation = 'landscape',
  format = 'a4'
}) {
  const cleanName = String(filename || 'MUN_COMPUTER_Report').replace(/\.pdf$/i, '');
  const doc = new jsPDF({ orientation, unit: 'mm', format: format === 'a5' ? 'a5' : 'a4' });
  const startY = drawBwPdfHeader(doc, {
    docTitle: title,
    metaLine: subtitle
  });

  const safeHead = headers.map(h => pdfSafeText(h));
  const safeBody = Array.isArray(rows) && rows.length > 0
    ? rows.map(r => r.map(c => pdfSafeText(c)))
    : [[pdfSafeText('No records available.'), ...safeHead.slice(1).map(() => '')]];

  applyAutoTable(doc, {
    startY,
    head: [safeHead],
    body: safeBody,
    margin: { left: 10, right: 10, bottom: 14 },
    ...getBwAutoTableStyles(),
    styles: {
      ...getBwAutoTableStyles().styles,
      fontSize: 7.5
    }
  });

  finalizeBwPdfPagination(doc, `MUN COMPUTER · ${pdfSafeText(title)}`);
  doc.save(`${cleanName}_${getTodayDate()}.pdf`);
  return true;
}

/* =========================================================================
   1. REPORT EXPORT (PDF, EXCEL, CSV)
   ========================================================================= */

/**
 * Export Financial & P&L Statement as a professional PDF document
 */
export function exportReportPDF(summary, periodLabel = 'This Month', layoutOpts = {}) {
  const orientation = layoutOpts?.orientation === 'landscape' ? 'landscape' : 'portrait';
  const format = layoutOpts?.format === 'a5' ? 'a5' : 'a4';
  const doc = new jsPDF({ orientation, unit: 'mm', format });
  const bw = getBwAutoTableStyles();
  const margin = 10;

  const startY = drawBwPdfHeader(doc, {
    docTitle: 'FINANCIAL & INCOME P&L STATEMENT',
    metaLine: `Period: ${formatDate(summary.dateRange.start)} to ${formatDate(summary.dateRange.end)} (${periodLabel})`
  });

  const pnlRows = [
    ['Total Billed Amount', pdfINR(summary.grossBilled, true), pdfSafeText(numberToWords(summary.grossBilled)), 'Total value of billed services & invoices'],
    ['Total Collected Amount', pdfINR(summary.collectedRevenue, true), pdfSafeText(numberToWords(summary.collectedRevenue)), 'Verified cash, UPI & bank collections'],
    ['Total Outstanding Due', pdfINR(summary.totalDues, true), pdfSafeText(numberToWords(summary.totalDues)), 'Pending receivable dues'],
    ['Banking Commission (CSP/AePS)', pdfINR(summary.bankingCommission || 0, true), pdfSafeText(numberToWords(summary.bankingCommission || 0)), 'Earned commission only (principal excluded)'],
    ['Total Operating Income', pdfINR(summary.totalOperatingIncome ?? summary.collectedRevenue, true), pdfSafeText(numberToWords(summary.totalOperatingIncome ?? summary.collectedRevenue)), 'Collected revenue + earned banking commission'],
    ['Total Expenses', pdfINR(summary.totalExpenses, true), pdfSafeText(numberToWords(summary.totalExpenses)), 'Shop rent, electricity, internet, salary & operational costs'],
    ['Net Profit / Loss', pdfINR(summary.netCashFlow, true), pdfSafeText(numberToWords(summary.netCashFlow)), summary.netCashFlow >= 0 ? 'Operating Surplus' : 'Operating Deficit'],
    ['Cash in Hand', pdfINR(summary.cashInHand || 0, true), pdfSafeText(numberToWords(summary.cashInHand || 0)), 'Physical drawer cash balance'],
    ['UPI Balance', pdfINR(summary.upiBalance || 0, true), pdfSafeText(numberToWords(summary.upiBalance || 0)), 'Net UPI / QR balance'],
    ['Bank Balance', pdfINR(summary.bankBalance || 0, true), pdfSafeText(numberToWords(summary.bankBalance || 0)), 'Net bank account balance'],
    ['Total Capital', pdfINR(summary.totalCapital || 0, true), pdfSafeText(numberToWords(summary.totalCapital || 0)), 'Owner capital minus withdrawals (non-income)'],
    ['Total Investments', pdfINR(summary.totalInvestments || 0, true), pdfSafeText(numberToWords(summary.totalInvestments || 0)), 'Assets & expansion investments']
  ];

  applyAutoTable(doc, {
    startY,
    head: [['Master Financial Summary (Particulars)', 'Amount (INR)', 'Amount in Words', 'Verification & Audit Notes']],
    body: pnlRows,
    ...bw,
    columnStyles: {
      0: { fontStyle: 'bold' },
      1: { fontStyle: 'bold', halign: 'right' }
    },
    margin: { left: margin, right: margin, bottom: 14 }
  });

  let currentY = (doc.lastAutoTable?.finalY || 80) + 7;
  const pageH = doc.internal.pageSize.getHeight();

  const payments = getItem(KEYS.PAYMENTS, []).filter(p => p.paymentDate >= summary.dateRange.start && p.paymentDate <= summary.dateRange.end);
  if (currentY > pageH - 45) {
    doc.addPage();
    currentY = 14;
  }
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(0, 0, 0);
  doc.text(`Collections & Payment Ledger (${payments.length} Records)`, margin, currentY);
  currentY += 3.5;

  const paymentRows = payments.length > 0
    ? payments.slice(0, 25).map(p => [
        pdfSafeText(p.id),
        formatDate(p.paymentDate),
        pdfSafeText(p.customerName || '-'),
        pdfSafeText(p.paymentMethod || 'Cash'),
        pdfINR(p.paymentAmount),
        pdfSafeText(p.paymentStatus || 'Paid')
      ])
    : [['-', '-', 'No payment transactions recorded for this period', '-', pdfINR(0), '-']];

  applyAutoTable(doc, {
    startY: currentY,
    head: [['Txn ID', 'Date', 'Customer Name', 'Method', 'Amount (INR)', 'Status']],
    body: paymentRows,
    ...bw,
    columnStyles: {
      4: { halign: 'right', fontStyle: 'bold' }
    },
    margin: { left: margin, right: margin, bottom: 14 }
  });

  currentY = (doc.lastAutoTable?.finalY || currentY + 30) + 7;

  const expenses = getItem(KEYS.EXPENSES, []).filter(e => e.date >= summary.dateRange.start && e.date <= summary.dateRange.end);
  if (currentY > pageH - 45) {
    doc.addPage();
    currentY = 14;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(0, 0, 0);
  doc.text(`Business Expenses Breakdown (${expenses.length} Entries)`, margin, currentY);
  currentY += 3.5;

  const expenseRows = expenses.length > 0
    ? expenses.slice(0, 25).map(e => [
        pdfSafeText(e.id),
        formatDate(e.date),
        pdfSafeText(e.category || 'General'),
        pdfSafeText(e.title || '-'),
        pdfSafeText(e.vendorName || '-'),
        pdfINR(e.amount)
      ])
    : [['-', '-', 'No business expenses logged for this period', '-', '-', pdfINR(0)]];

  applyAutoTable(doc, {
    startY: currentY,
    head: [['Expense ID', 'Date', 'Category', 'Description', 'Vendor', 'Amount (INR)']],
    body: expenseRows,
    ...bw,
    columnStyles: {
      5: { halign: 'right', fontStyle: 'bold' }
    },
    margin: { left: margin, right: margin, bottom: 14 }
  });

  finalizeBwPdfPagination(doc, `MUN COMPUTER · Official Financial P&L Statement`);
  doc.save(`MUN_COMPUTER_Financial_Report_${getTodayDate()}.pdf`);
  return true;
}

/**
 * Export Financial & P&L Statement as a genuine Microsoft Excel (.xlsx) file
 */
export function exportReportExcel(summary) {
  const wb = XLSX.utils.book_new();

  // 1. Financial Summary Sheet
  const summarySheetData = [
    ['MUN COMPUTER BUSINESS MANAGER - OFFICIAL FINANCIAL REPORT'],
    ['Mamudpur, Juginda, Domkal, Murshidabad, West Bengal - 742406 | Helpline: 8101352105'],
    ['Report Period:', `${formatDate(summary.dateRange.start)} to ${formatDate(summary.dateRange.end)}`],
    ['Generated On:', new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })],
    [],
    ['METRIC / PARTICULARS', 'AMOUNT (INR)', 'DETAILS / STATUS'],
    ['Total Billed Amount', summary.grossBilled, 'Total value of services & invoices rendered'],
    ['Total Collected Amount', summary.collectedRevenue, 'Actual payments received at counter (Cash/UPI/Bank)'],
    ['Total Outstanding Due', summary.totalDues, 'Uncollected balances pending recovery'],
    ['Earned Banking Commission (CSP/AePS)', summary.bankingCommission || 0, 'Commission earned only (customer principal excluded)'],
    ['Total Operating Income', summary.totalOperatingIncome ?? summary.collectedRevenue, 'Collections + Earned Banking Commission'],
    ['Total Expenses', summary.totalExpenses, 'Shop rent, electricity, internet, paper, salaries'],
    ['Net Profit / Loss', summary.netCashFlow, summary.netCashFlow >= 0 ? 'Operating Surplus' : 'Operating Deficit'],
    ['Cash in Hand', summary.cashInHand || 0, 'Physical drawer cash balance'],
    ['UPI Balance', summary.upiBalance || 0, 'Net UPI / QR balance'],
    ['Bank Balance', summary.bankBalance || 0, 'Net bank account balance'],
    ['Total Capital', summary.totalCapital || 0, 'Owner capital minus withdrawals (excluded from income)'],
    ['Total Investments', summary.totalInvestments || 0, 'Business capital & asset investments'],
    [],
    ['ACTIVITY METRICS', 'COUNT', 'STATUS'],
    ['Registered Customers in Period', summary.customersCount, 'Directory records'],
    ['Service Requests Processed', summary.servicesCount, 'Counter services'],
    ['Payment Transactions Recorded', summary.paymentsCount, 'Ledger receipts'],
    ['PNB CSP / AePS Transactions', summary.bankingCount || 0, 'Principal volume excluded from income'],
    ['Expense Vouchers Logged', summary.expensesCount, 'Operating vouchers']
  ];

  const wsSummary = XLSX.utils.aoa_to_sheet(summarySheetData);
  XLSX.utils.book_append_sheet(wb, wsSummary, 'Final_Master_Summary');

  // 2. Payments Ledger Sheet
  const payments = getItem(KEYS.PAYMENTS, []).filter(p => p.paymentDate >= summary.dateRange.start && p.paymentDate <= summary.dateRange.end);
  const payRows = payments.map(p => ({
    'Payment ID': p.id,
    'Payment Date': p.paymentDate,
    'Customer Name': p.customerName || '',
    'Payment Method': p.paymentMethod || 'Cash',
    'Amount (INR)': Number(p.paymentAmount) || 0,
    'Remaining Due': Number(p.remainingDue) || 0,
    'Transaction / UPI Ref': p.transactionId || '',
    'Remarks': p.remarks || ''
  }));
  const wsPayments = XLSX.utils.json_to_sheet(payRows.length ? payRows : [{ 'Note': 'No payments recorded for this period' }]);
  XLSX.utils.book_append_sheet(wb, wsPayments, 'Collections_Ledger');

  // 3. Expenses Sheet
  const expenses = getItem(KEYS.EXPENSES, []).filter(e => e.date >= summary.dateRange.start && e.date <= summary.dateRange.end);
  const expRows = expenses.map(e => ({
    'Expense ID': e.id,
    'Date': e.date,
    'Category': e.category || 'General',
    'Title / Description': e.title || '',
    'Amount (INR)': Number(e.amount) || 0,
    'Vendor / Payee': e.vendorName || '',
    'Payment Method': e.paymentMethod || '',
    'Paid By': e.paidBy || '',
    'Bill / Voucher No.': e.billNumber || '',
    'Remarks': e.remarks || ''
  }));
  const wsExpenses = XLSX.utils.json_to_sheet(expRows.length ? expRows : [{ 'Note': 'No expenses recorded for this period' }]);
  XLSX.utils.book_append_sheet(wb, wsExpenses, 'Expenses_Register');

  // 4. Services Sheet
  const services = getItem(KEYS.SERVICES, []).filter(s => s.appDate >= summary.dateRange.start && s.appDate <= summary.dateRange.end);
  const srvRows = services.map(s => ({
    'Service ID': s.id,
    'Booking Date': s.appDate,
    'Customer Name': s.customerName || '',
    'Service Name': s.serviceName || '',
    'Category': s.category || '',
    'Total Fee (INR)': Number(s.totalAmount) || 0,
    'Paid Amount': Number(s.paidAmount) || 0,
    'Due Amount': Number(s.dueAmount) || 0,
    'Status': s.status || '',
    'Delivery Date': s.deliveryDate || ''
  }));
  const wsServices = XLSX.utils.json_to_sheet(srvRows.length ? srvRows : [{ 'Note': 'No services recorded for this period' }]);
  XLSX.utils.book_append_sheet(wb, wsServices, 'Services_Track');

  XLSX.writeFile(wb, `MUN_COMPUTER_Financial_Report_${getTodayDate()}.xlsx`);
  return true;
}

/**
 * Export Financial & P&L Statement as a clean CSV file
 */
export function exportReportCSV(summary) {
  const rows = [
    { Section: 'Final Master Summary', Metric: 'Total Billed Amount', 'Amount (INR)': summary.grossBilled, Notes: 'Total value of billed services & invoices' },
    { Section: 'Final Master Summary', Metric: 'Total Collected Amount', 'Amount (INR)': summary.collectedRevenue, Notes: 'Actual verified payments received' },
    { Section: 'Final Master Summary', Metric: 'Total Outstanding Due', 'Amount (INR)': summary.totalDues, Notes: 'Unpaid client balances' },
    { Section: 'Final Master Summary', Metric: 'Banking Commission (CSP/AePS)', 'Amount (INR)': summary.bankingCommission || 0, Notes: 'Earned commission only' },
    { Section: 'Final Master Summary', Metric: 'Total Operating Income', 'Amount (INR)': summary.totalOperatingIncome ?? summary.collectedRevenue, Notes: 'Collections + Banking Commission' },
    { Section: 'Final Master Summary', Metric: 'Total Expenses', 'Amount (INR)': summary.totalExpenses, Notes: 'Operational expenses' },
    { Section: 'Final Master Summary', Metric: 'Net Profit / Loss', 'Amount (INR)': summary.netCashFlow, Notes: 'Operating Income - Expenses' },
    { Section: 'Final Master Summary', Metric: 'Cash in Hand', 'Amount (INR)': summary.cashInHand || 0, Notes: 'Physical counter drawer balance' },
    { Section: 'Final Master Summary', Metric: 'UPI Balance', 'Amount (INR)': summary.upiBalance || 0, Notes: 'Separate UPI / QR balance' },
    { Section: 'Final Master Summary', Metric: 'Bank Balance', 'Amount (INR)': summary.bankBalance || 0, Notes: 'Separate Bank account balance' },
    { Section: 'Final Master Summary', Metric: 'Total Capital', 'Amount (INR)': summary.totalCapital || 0, Notes: 'Owner capital minus withdrawals' },
    { Section: 'Final Master Summary', Metric: 'Total Investments', 'Amount (INR)': summary.totalInvestments || 0, Notes: 'Business assets & investments' },
    { Section: 'Operational Counts', Metric: 'Registered Customers', 'Amount (INR)': summary.customersCount, Notes: 'In selected period' },
    { Section: 'Operational Counts', Metric: 'Services Registered', 'Amount (INR)': summary.servicesCount, Notes: 'In selected period' },
    { Section: 'Operational Counts', Metric: 'Payments Recorded', 'Amount (INR)': summary.paymentsCount, Notes: 'In selected period' },
    { Section: 'Operational Counts', Metric: 'Expenses Recorded', 'Amount (INR)': summary.expensesCount, Notes: 'In selected period' }
  ];

  return downloadCSV('MUN_COMPUTER_Financial_Summary', rows, [
    { key: 'Section', label: 'Report Section' },
    { key: 'Metric', label: 'Financial Metric' },
    { key: 'Amount (INR)', label: 'Amount / Count' },
    { key: 'Notes', label: 'Description & Notes' }
  ]);
}

/* =========================================================================
   2. ALL DATA MASTER EXPORTS (EXCEL, PDF, CSV)
   ========================================================================= */

/**
 * Export ALL application tables in a Master Excel Workbook (.xlsx)
 */
export function exportAllDataExcel() {
  const wb = XLSX.utils.book_new();

  // 1. Business Profile Sheet
  const profile = getItem(KEYS.BUSINESS_PROFILE, {});
  const profileRows = [
    ['MUN COMPUTER - Master Business Registry'],
    ['Business Name', profile.name || 'MUN COMPUTER'],
    ['Tagline', profile.tagline || ''],
    ['Owner / In-Charge', profile.ownerName || 'Mamun Reja'],
    ['Helpline Phone', profile.phone || '8101352105'],
    ['Email Address', profile.email || 'muncomputer2019@gmail.com'],
    ['Address', profile.address || 'Mamudpur, Juginda, Domkal, Murshidabad, West Bengal – 742406'],
    ['Trade License', profile.tradeLicense || ''],
    ['GSTIN', profile.gstin || ''],
    ['Bank Account', profile.bankAccount || ''],
    ['Backup Date', new Date().toISOString()]
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(profileRows), 'Business_Profile');

  // 2. Customers
  const customers = getItem(KEYS.CUSTOMERS, []);
  const custRows = customers.map(c => ({
    'Customer ID': c.id,
    'Name': c.name,
    'Father / Guardian': c.fatherName || '',
    'Mobile': c.phone,
    'Alt Phone': c.altPhone || '',
    'Village': c.village || '',
    'Post Office': c.postOffice || '',
    'Police Station': c.policeStation || '',
    'District': c.district || 'Murshidabad',
    'PIN Code': c.pinCode || '',
    'Category': c.category || 'General',
    'Registration Date': c.regDate || '',
    'Remarks': c.remarks || ''
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(custRows.length ? custRows : [{ 'Note': 'No customers registered yet' }]), 'Customers');

  // 3. Services
  const services = getItem(KEYS.SERVICES, []);
  const srvRows = services.map(s => ({
    'Service ID': s.id,
    'Booking Date': s.appDate,
    'Customer Name': s.customerName,
    'Mobile': s.phone || '',
    'Service Name': s.serviceName,
    'Category': s.category,
    'Subcategory': s.subcategory || '',
    'Ref / App No.': s.refNumber || '',
    'Service Charge': Number(s.serviceCharge) || 0,
    'Govt Fee': Number(s.govFee) || 0,
    'Total Amount': Number(s.totalAmount) || 0,
    'Paid Amount': Number(s.paidAmount) || 0,
    'Due Amount': Number(s.dueAmount) || 0,
    'Status': s.status,
    'Delivery Date': s.deliveryDate || '',
    'Remarks': s.remarks || ''
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(srvRows.length ? srvRows : [{ 'Note': 'No services registered yet' }]), 'Services');

  // 4. Payments
  const payments = getItem(KEYS.PAYMENTS, []);
  const payRows = payments.map(p => ({
    'Payment ID': p.id,
    'Date': p.paymentDate,
    'Customer Name': p.customerName,
    'Service ID': p.serviceId || '',
    'Invoice Number': p.invoiceNumber || '',
    'Amount (INR)': Number(p.paymentAmount) || 0,
    'Payment Method': p.paymentMethod || 'Cash',
    'Txn / UPI ID': p.transactionId || '',
    'Remarks': p.remarks || ''
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(payRows.length ? payRows : [{ 'Note': 'No payments recorded yet' }]), 'Payments');

  // 5. Invoices
  const invoices = getItem(KEYS.INVOICES, []);
  const invRows = invoices.map(i => ({
    'Invoice ID': i.id,
    'Date': i.date,
    'Customer Name': i.customerName,
    'Phone': i.phone || '',
    'Total Amount': Number(i.totalAmount) || 0,
    'Paid Amount': Number(i.paidAmount) || 0,
    'Balance Due': Number(i.balanceDue) || 0,
    'Status': i.status || ''
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(invRows.length ? invRows : [{ 'Note': 'No invoices issued yet' }]), 'Invoices');

  // 6. Expenses
  const expenses = getItem(KEYS.EXPENSES, []);
  const expRows = expenses.map(e => ({
    'Expense ID': e.id,
    'Date': e.date,
    'Category': e.category,
    'Title': e.title,
    'Amount (INR)': Number(e.amount) || 0,
    'Vendor': e.vendorName || '',
    'Payment Method': e.paymentMethod || '',
    'Paid By': e.paidBy || '',
    'Bill No.': e.billNumber || '',
    'Remarks': e.remarks || ''
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(expRows.length ? expRows : [{ 'Note': 'No expenses recorded yet' }]), 'Expenses');

  // 7. PNB CSP Banking
  const banking = getItem(KEYS.BANKING, []);
  const bankRows = banking.map(b => ({
    'Txn ID': b.id,
    'Date': b.date,
    'Time': b.time || '',
    'Transaction Type': b.type,
    'Bank': b.bank,
    'Customer': b.customerName,
    'Phone': b.customerPhone || '',
    'Amount (INR)': Number(b.amount) || 0,
    'Commission Earned': Number(b.commission) || 0,
    'RRN': b.rrn || '',
    'Status': b.status
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(bankRows.length ? bankRows : [{ 'Note': 'No banking transactions yet' }]), 'Banking_CSP');

  // 8. Inventory
  const inventory = getItem(KEYS.INVENTORY, []);
  const invItems = inventory.map(item => ({
    'Product ID': item.id,
    'SKU': item.sku || '',
    'Item Name': item.name,
    'Category': item.category,
    'Stock Quantity': Number(item.stockQuantity) || 0,
    'Min Stock Level': Number(item.minStockLevel) || 5,
    'Cost Price (INR)': Number(item.costPrice) || 0,
    'Selling Price (INR)': Number(item.sellingPrice) || 0,
    'Supplier': item.supplier || '',
    'Location': item.shelfLocation || ''
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(invItems.length ? invItems : [{ 'Note': 'No inventory items yet' }]), 'Inventory');

  // 9. Daybook Cash Records
  const daybook = getItem(KEYS.DAYBOOK, []);
  const dayRows = daybook.map(d => ({
    'Daybook ID': d.id,
    'Date': d.date,
    'Opening Cash': Number(d.openingCash) || 0,
    'Service Cash In': Number(d.serviceCashIn) || 0,
    'CSP Cash In': Number(d.cspCashIn) || 0,
    'CSP Cash Out': Number(d.cspCashOut) || 0,
    'Cash Expenses': Number(d.cashExpenses) || 0,
    'Expected Closing': Number(d.expectedClosing) || 0,
    'Physical Counted': Number(d.countedPhysicalCash) || 0,
    'Difference': Number(d.difference) || 0,
    'Status': d.status,
    'Verified By': d.verifiedBy || ''
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(dayRows.length ? dayRows : [{ 'Note': 'No daybook entries yet' }]), 'Daybook');

  XLSX.writeFile(wb, `MUN_COMPUTER_All_Data_Master_Workbook_${getTodayDate()}.xlsx`);
  return true;
}

/**
 * Export Master Operations & Complete Business Audit Report in PDF
 */
export function exportAllDataPDF() {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const bw = getBwAutoTableStyles();
  const margin = 10;

  const startY = drawBwPdfHeader(doc, {
    docTitle: 'MASTER BUSINESS DATABASE REPORT',
    metaLine: 'Complete Operations, Customers, Services, Payments, Expenses & Banking Register'
  });

  const customers = getItem(KEYS.CUSTOMERS, []);
  const services = getItem(KEYS.SERVICES, []);
  const payments = getItem(KEYS.PAYMENTS, []);
  const expenses = getItem(KEYS.EXPENSES, []);
  const banking = getItem(KEYS.BANKING, []);

  const totalPaymentsAmt = payments.reduce((s, p) => s + (Number(p.paymentAmount) || 0), 0);
  const totalExpensesAmt = expenses.reduce((s, e) => s + (Number(e.amount) || 0), 0);
  const summaryRows = [
    ['Total Registered Customers', customers.length.toString(), 'Citizen & merchant directory'],
    ['Total Service Requests Logged', services.length.toString(), 'Active & delivered services'],
    ['Total Payments Collected', payments.length.toString(), `Gross Inflow: ${pdfINR(totalPaymentsAmt)} (${pdfSafeText(numberToWords(totalPaymentsAmt))})`],
    ['Total Expenses Logged', expenses.length.toString(), `Total Outflow: ${pdfINR(totalExpensesAmt)} (${pdfSafeText(numberToWords(totalExpensesAmt))})`],
    ['PNB CSP Banking Transactions', banking.length.toString(), 'AePS cash withdrawals & deposits']
  ];

  applyAutoTable(doc, {
    startY,
    head: [['Business Registry Table', 'Total Records', 'Financial Overview']],
    body: summaryRows,
    ...bw,
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 62 },
      1: { halign: 'center', fontStyle: 'bold', cellWidth: 30 }
    },
    margin: { left: margin, right: margin, bottom: 14 }
  });

  let currentY = (doc.lastAutoTable?.finalY || 80) + 8;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(0, 0, 0);
  doc.text(`1. Customer Directory (${customers.length} Records)`, margin, currentY);
  currentY += 3.5;

  const custRows = customers.length > 0
    ? customers.slice(0, 30).map(c => [
        pdfSafeText(c.id),
        pdfSafeText(c.name),
        pdfSafeText(c.phone),
        pdfSafeText(c.village || '-'),
        pdfSafeText(c.category || 'General'),
        formatDate(c.regDate)
      ])
    : [['-', 'No customers registered yet.', '-', '-', '-', '-']];

  applyAutoTable(doc, {
    startY: currentY,
    head: [['Customer ID', 'Full Name', 'Mobile', 'Village', 'Category', 'Reg. Date']],
    body: custRows,
    ...bw,
    margin: { left: margin, right: margin, bottom: 14 }
  });

  currentY = (doc.lastAutoTable?.finalY || currentY + 30) + 8;
  const pageH = doc.internal.pageSize.getHeight();
  if (currentY > pageH - 45) {
    doc.addPage();
    currentY = 14;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(0, 0, 0);
  doc.text(`2. Services Registry (${services.length} Records)`, margin, currentY);
  currentY += 3.5;

  const srvRows = services.length > 0
    ? services.slice(0, 30).map(s => [
        pdfSafeText(s.id),
        pdfSafeText(s.customerName),
        pdfSafeText(s.serviceName),
        pdfINR(s.totalAmount),
        pdfINR(s.paidAmount),
        pdfINR(s.dueAmount),
        pdfSafeText(s.status)
      ])
    : [['-', 'No services booked yet.', '-', pdfINR(0), pdfINR(0), pdfINR(0), '-']];

  applyAutoTable(doc, {
    startY: currentY,
    head: [['Service ID', 'Customer', 'Service Name', 'Total', 'Paid', 'Due', 'Status']],
    body: srvRows,
    ...bw,
    columnStyles: {
      3: { halign: 'right' },
      4: { halign: 'right' },
      5: { halign: 'right', fontStyle: 'bold' }
    },
    margin: { left: margin, right: margin, bottom: 14 }
  });

  finalizeBwPdfPagination(doc, 'MUN COMPUTER — Master Database Export Report');
  doc.save(`MUN_COMPUTER_All_Data_Master_Report_${getTodayDate()}.pdf`);
  return true;
}

/**
 * Export Master Consolidated CSV of All Operational Records
 */
export function exportAllDataCSV() {
  const customers = getItem(KEYS.CUSTOMERS, []);
  const services = getItem(KEYS.SERVICES, []);
  const payments = getItem(KEYS.PAYMENTS, []);
  const expenses = getItem(KEYS.EXPENSES, []);
  const banking = getItem(KEYS.BANKING, []);

  const masterRows = [];

  customers.forEach(c => {
    masterRows.push({
      Module: 'Customer',
      'Record ID': c.id,
      Date: c.regDate || '',
      Title: c.name,
      'Contact / Phone': c.phone,
      'Category / Type': c.category || 'General',
      'Amount (INR)': '',
      Status: 'Active',
      Notes: `${c.village || ''}, ${c.district || ''}`
    });
  });

  services.forEach(s => {
    masterRows.push({
      Module: 'Service',
      'Record ID': s.id,
      Date: s.appDate || '',
      Title: s.serviceName,
      'Contact / Phone': s.phone || '',
      'Category / Type': s.category || '',
      'Amount (INR)': s.totalAmount || 0,
      Status: s.status || '',
      Notes: `Paid: ₹${s.paidAmount || 0}, Due: ₹${s.dueAmount || 0} (Customer: ${s.customerName})`
    });
  });

  payments.forEach(p => {
    masterRows.push({
      Module: 'Payment',
      'Record ID': p.id,
      Date: p.paymentDate || '',
      Title: `Payment from ${p.customerName}`,
      'Contact / Phone': '',
      'Category / Type': p.paymentMethod || 'Cash',
      'Amount (INR)': p.paymentAmount || 0,
      Status: 'Received',
      Notes: p.remarks || ''
    });
  });

  expenses.forEach(e => {
    masterRows.push({
      Module: 'Expense',
      'Record ID': e.id,
      Date: e.date || '',
      Title: e.title,
      'Contact / Phone': e.vendorName || '',
      'Category / Type': e.category || 'Expense',
      'Amount (INR)': e.amount || 0,
      Status: 'Paid',
      Notes: e.remarks || ''
    });
  });

  banking.forEach(b => {
    masterRows.push({
      Module: 'Banking_CSP',
      'Record ID': b.id,
      Date: b.date || '',
      Title: b.type,
      'Contact / Phone': b.customerPhone || '',
      'Category / Type': b.bank,
      'Amount (INR)': b.amount || 0,
      Status: b.status || '',
      Notes: `RRN: ${b.rrn || ''}, Commission: ₹${b.commission || 0} (${b.customerName})`
    });
  });

  if (masterRows.length === 0) {
    masterRows.push({
      Module: 'System',
      'Record ID': 'REC-000',
      Date: getTodayDate(),
      Title: 'Database is Fresh and Clean (No records)',
      'Contact / Phone': '8101352105',
      'Category / Type': 'Clean Slate',
      'Amount (INR)': 0,
      Status: 'Ready',
      Notes: 'Add new customers and services to populate records.'
    });
  }

  return downloadCSV('MUN_COMPUTER_All_Data_Master', masterRows, [
    { key: 'Module', label: 'Module / Table' },
    { key: 'Record ID', label: 'Record ID' },
    { key: 'Date', label: 'Date' },
    { key: 'Title', label: 'Title / Name' },
    { key: 'Contact / Phone', label: 'Mobile / Phone' },
    { key: 'Category / Type', label: 'Category / Bank' },
    { key: 'Amount (INR)', label: 'Amount (INR)' },
    { key: 'Status', label: 'Status' },
    { key: 'Notes', label: 'Details & Remarks' }
  ]);
}
