/**
 * auth.js - User Authentication & Role-Based Access Control (RBAC)
 * Official Shop: MUN COMPUTER
 */

import { getItem, setItem, KEYS, logAuditAction } from './storage.js';

export const ROLES = {
  ADMIN: 'ADMIN',
  MANAGER: 'MANAGER',
  MAKER: 'MAKER',
  CHECKER: 'CHECKER',
  STAFF: 'STAFF'
};

/**
 * Route Permission Mapping
 * Defines which ERP routes each role is authorized to access
 */
const OPERATIONS_ROUTES = [
  'counter-daybook',
  'banking',
  'daily-opening-cash',
  'daily-closing-cash',
  'staff-attendance',
  'time-register',
  'gps-attendance',
  'staff-location-map',
  'attendance-reports',
  'cash-reports',
  'govt-annapurna'
];

export const ROUTE_PERMISSIONS = {
  [ROLES.ADMIN]: [
    'dashboard',
    'universal-search',
    'applications',
    'locations-master',
    'customers',
    'services',
    'rate-chart',
    'inventory',
    'daybook',
    'payroll',
    ...OPERATIONS_ROUTES,
    'followups',
    'payments',
    'invoices',
    'expenses',
    'income',
    'business',
    'targets',
    'projects',
    'investments',
    'marketing',
    'competitors',
    'tasks',
    'chat',
    'documents',
    'reports',
    'user-approvals',
    'admin-settings',
    'settings'
  ],
  [ROLES.MANAGER]: [
    'dashboard',
    'universal-search',
    'applications',
    'locations-master',
    'customers',
    'services',
    'rate-chart',
    'inventory',
    'daybook',
    'payroll',
    ...OPERATIONS_ROUTES,
    'followups',
    'payments',
    'invoices',
    'expenses',
    'income',
    'business',
    'targets',
    'projects',
    'tasks',
    'chat',
    'documents',
    'reports'
  ],
  [ROLES.MAKER]: [
    'dashboard',
    'universal-search',
    'applications',
    'locations-master',
    'customers',
    'services',
    'rate-chart',
    'inventory',
    'daybook',
    'payroll',
    ...OPERATIONS_ROUTES,
    'followups',
    'payments',
    'tasks',
    'chat',
    'documents'
  ],
  [ROLES.CHECKER]: [
    'dashboard',
    'universal-search',
    'applications',
    'locations-master',
    'customers',
    'services',
    'rate-chart',
    'inventory',
    'daybook',
    'payroll',
    ...OPERATIONS_ROUTES,
    'followups',
    'payments',
    'invoices',
    'reports',
    'tasks',
    'chat',
    'documents'
  ],
  [ROLES.STAFF]: [
    'dashboard',
    'universal-search',
    'applications',
    'locations-master',
    'customers',
    'services',
    'rate-chart',
    'inventory',
    'daybook',
    'payroll',
    ...OPERATIONS_ROUTES,
    'followups',
    'payments',
    'tasks',
    'chat',
    'documents'
  ]
};

/**
 * Granular Permission Matrix for Feature Actions
 */
export const PERMISSIONS = {
  [ROLES.ADMIN]: {
    canApproveUsers: true,
    canManageUsers: true,
    canViewFinancials: true,
    canManageSettings: true,
    canDeleteRecords: true,
    canManageTargets: true,
    canManageProjects: true,
    canManageInvestments: true,
    canSwitchBusinessUnits: true,
    canExportData: true,
    canManageCustomers: true,
    canManageServices: true,
    canManageFollowups: true,
    canManagePayments: true,
    canManageInvoices: true,
    canManageExpenses: true,
    canManageTasks: true,
    canManageBanking: true,
    canManageInventory: true,
    canManageDaybook: true,
    canManagePayroll: true
  },
  [ROLES.MANAGER]: {
    canApproveUsers: false,
    canManageUsers: false,
    canViewFinancials: true,
    canManageSettings: false,
    canDeleteRecords: false,
    canManageTargets: true,
    canManageProjects: true,
    canManageInvestments: false,
    canSwitchBusinessUnits: true,
    canExportData: true,
    canManageCustomers: true,
    canManageServices: true,
    canManageFollowups: true,
    canManagePayments: true,
    canManageInvoices: true,
    canManageExpenses: true,
    canManageTasks: true,
    canManageBanking: true,
    canManageInventory: true,
    canManageDaybook: true,
    canManagePayroll: true
  },
  [ROLES.MAKER]: {
    canApproveUsers: false,
    canManageUsers: false,
    canViewFinancials: false,
    canManageSettings: false,
    canDeleteRecords: false,
    canManageTargets: false,
    canManageProjects: false,
    canManageInvestments: false,
    canSwitchBusinessUnits: false,
    canExportData: false,
    canManageCustomers: true,
    canManageServices: true,
    canManageFollowups: true,
    canManagePayments: true,
    canManageInvoices: false,
    canManageExpenses: false,
    canManageTasks: true,
    canManageBanking: true,
    canManageInventory: true,
    canManageDaybook: true,
    canManagePayroll: false
  },
  [ROLES.CHECKER]: {
    canApproveUsers: false,
    canManageUsers: false,
    canViewFinancials: true,
    canManageSettings: false,
    canDeleteRecords: false,
    canManageTargets: false,
    canManageProjects: false,
    canManageInvestments: false,
    canSwitchBusinessUnits: false,
    canExportData: true,
    canManageCustomers: true,
    canManageServices: true,
    canManageFollowups: true,
    canManagePayments: true,
    canManageInvoices: true,
    canManageExpenses: false,
    canManageTasks: true,
    canManageBanking: true,
    canManageInventory: true,
    canManageDaybook: true,
    canManagePayroll: false
  },
  [ROLES.STAFF]: {
    canApproveUsers: false,
    canManageUsers: false,
    canViewFinancials: false,
    canManageSettings: false,
    canDeleteRecords: false,
    canManageTargets: false,
    canManageProjects: false,
    canManageInvestments: false,
    canSwitchBusinessUnits: false,
    canExportData: false,
    canManageCustomers: true,
    canManageServices: true,
    canManageFollowups: true,
    canManagePayments: true,
    canManageInvoices: false,
    canManageExpenses: false,
    canManageTasks: true,
    canManageBanking: true,
    canManageInventory: true,
    canManageDaybook: true,
    canManagePayroll: false
  }
};

export const UID_ORG_PREFIX = 'MUNCOMPUTER';
export const ROLE_UID_CODES = {
  ADMIN: 'AD',
  MANAGER: 'MN',
  STAFF: 'ST',
  MAKER: 'ST',
  CHECKER: 'ST'
};
export const MANAGER_UID = 'MUNCOMPUTER-2019';
export const MANAGER_UID_PREFIX = 'MUNCM';
export const STAFF_UID_PREFIX = 'MUNCS';

/**
 * Human-facing role display label (maps internal ADMIN role to ADMINISTRATION)
 */
export function formatRoleLabel(role = 'STAFF') {
  const r = String(role || 'STAFF').trim().toUpperCase();
  if (r === 'ADMIN' || r === 'ADMINISTRATION') return 'ADMINISTRATION';
  return r;
}

/**
 * Role Overview & Capabilities Description
 */
export const ROLE_CAPABILITIES = {
  [ROLES.ADMIN]: {
    title: 'Administration Authority',
    badge: 'Full Access',
    description: 'Complete system control. Manage services, customers, reports, settings, audit logs, and staff operations (user approvals reserved for Administration).',
    accessibleModules: ['All ERP Modules', 'Service & Location Catalog', 'Financial Control', 'Audit Logs & Settings']
  },
  [ROLES.MANAGER]: {
    title: 'Operations Manager',
    badge: 'Operations & Finance',
    description: 'Manage assigned staff, customers, services, application verification, billing, counter payments, and authorized reports.',
    accessibleModules: ['Customers & Applications', 'Service Tracking', 'Billing & Payments', 'Team Tasks & Reports']
  },
  [ROLES.STAFF]: {
    title: 'Front Desk Operator / Staff',
    badge: 'Front Desk & Service Desk',
    description: 'Register customers, enter new applications, upload KYC documents, record counter payments, and print receipts.',
    accessibleModules: ['Customer Registration', 'Application Entry', 'Document Upload', 'Counter Payments & Receipts']
  }
};

/**
 * Get currently authenticated user from localStorage.
 */
export function getCurrentUser() {
  const user = getItem(KEYS.CURRENT_USER);
  if (!user || user.isLoggedOut) {
    return null;
  }
  return user;
}

/**
 * Set active authenticated user in localStorage
 */
export function setCurrentUser(user) {
  if (!user) {
    localStorage.removeItem(KEYS.CURRENT_USER);
    return;
  }
  const cleanUser = { ...user, isLoggedOut: false, lastLoginAt: user.lastLoginAt || new Date().toISOString() };
  setItem(KEYS.CURRENT_USER, cleanUser);
}

export function isSuperAdmin(user = null) {
  const activeUser = user || getCurrentUser();
  if (!activeUser) return false;
  return (
    activeUser.uid === 'MUNCOMPUTER-2019' ||
    activeUser.id === 'MUNCOMPUTER-2019' ||
    activeUser.uid === 'MUNCM-2026' ||
    activeUser.id === 'MUNCM-2026' ||
    activeUser.isSuperAdmin === true
  );
}

export function handleSessionInvalidationResponse(status, data) {
  if (status === 401 && data && typeof data.message === 'string' && /session|expired|invalidated/i.test(data.message)) {
    logout();
    window.dispatchEvent(new CustomEvent('mun-auth-logout'));
    return true;
  }
  return false;
}

export function normalizeMenuId(route) {
  const r = String(route || '').trim();
  if (r === 'daybook') return 'counter-daybook';
  if (r === 'payroll') return 'staff-attendance';
  if (r === 'customer-registration') return 'customers';
  if (
    r === 'followups-today' ||
    r === 'followups-upcoming' ||
    r === 'followups-overdue' ||
    r === 'followups-pending' ||
    r === 'followups-completed' ||
    r === 'followups-review90' ||
    r === 'grievances'
  ) {
    return 'followups';
  }
  return r;
}

const CLIENT_ALL_MENU_IDS = [
  'dashboard', 'universal-search', 'customers', 'applications', 'services', 'rate-chart',
  'whatsapp-connect', 'inventory', 'followups', 'counter-daybook', 'banking', 'daily-opening-cash',
  'daily-closing-cash', 'staff-attendance', 'time-register', 'gps-attendance',
  'staff-location-map', 'attendance-photo-gallery', 'attendance-reports', 'cash-reports',
  'govt-annapurna',
  'payments', 'invoices', 'expenses', 'income', 'business', 'targets', 'projects',
  'investments', 'marketing', 'competitors', 'tasks', 'chat', 'documents',
  'user-approvals', 'locations-master', 'reports', 'admin-settings', 'settings'
];

function makeSet(overrides = {}) {
  return { view: false, add: false, edit: false, delete: false, approve: false, export: false, print: false, ...overrides };
}

function allTrueSet() {
  return { view: true, add: true, edit: true, delete: true, approve: true, export: true, print: true };
}

function getDefaultRoleEffectiveClient(roleInput = 'STAFF') {
  const role = String(roleInput || 'STAFF').trim().toUpperCase();
  const menus = {};
  if (role === 'ADMIN') {
    CLIENT_ALL_MENU_IDS.forEach(id => { menus[id] = allTrueSet(); });
    return {
      role: 'ADMIN',
      isSuperAdmin: false,
      menus,
      extra: {
        cashOperationLimit: 0,
        customerAccessScope: 'ALL',
        customerAccessLimit: 0,
        canApproveTransactions: true,
        canViewAllAttendancePhotos: true,
        canManageBackupSettings: true,
        canManageUserPermissions: true,
        accountActive: true
      }
    };
  }
  if (role === 'MANAGER') {
    CLIENT_ALL_MENU_IDS.forEach(id => { menus[id] = makeSet(); });
    [
      'dashboard', 'universal-search', 'customers', 'applications', 'services', 'rate-chart',
      'whatsapp-connect', 'inventory', 'followups', 'counter-daybook', 'banking', 'daily-opening-cash',
      'daily-closing-cash', 'staff-attendance', 'time-register', 'gps-attendance',
      'staff-location-map', 'attendance-reports', 'cash-reports', 'govt-annapurna', 'payments', 'invoices',
      'targets', 'tasks', 'chat', 'documents', 'locations-master', 'reports'
    ].forEach(id => {
      menus[id] = makeSet({ view: true, add: true, edit: true, delete: false, approve: true, export: true, print: true });
    });
    menus['expenses'] = makeSet({ view: true, add: true, edit: true, delete: false, approve: false, export: true, print: true });
    menus['income'] = makeSet({ view: true, export: true, print: true });
    menus['attendance-photo-gallery'] = makeSet({ view: true, export: true, print: true });
    menus['projects'] = makeSet({ view: true, add: true, edit: true, print: true });
    return {
      role: 'MANAGER',
      isSuperAdmin: false,
      menus,
      extra: {
        cashOperationLimit: 50000,
        customerAccessScope: 'ALL',
        customerAccessLimit: 0,
        canApproveTransactions: true,
        canViewAllAttendancePhotos: false,
        canManageBackupSettings: false,
        canManageUserPermissions: false,
        accountActive: true
      }
    };
  }
  CLIENT_ALL_MENU_IDS.forEach(id => { menus[id] = makeSet(); });
  menus['dashboard'] = makeSet({ view: true });
  menus['universal-search'] = makeSet({ view: true });
  menus['customers'] = makeSet({ view: true, add: true, edit: true, print: true });
  menus['applications'] = makeSet({ view: true, add: true, edit: true, print: true });
  menus['services'] = makeSet({ view: true, add: true, print: true });
  menus['rate-chart'] = makeSet({ view: true, print: true });
  menus['whatsapp-connect'] = makeSet({ view: true, add: true });
  menus['banking'] = makeSet({ view: true, add: true, print: true });
  menus['invoices'] = makeSet({ view: true, add: true, print: true });
  menus['expenses'] = makeSet({ view: true, add: true });
  menus['staff-attendance'] = makeSet({ view: true, add: true });
  menus['time-register'] = makeSet({ view: true, add: true });
  menus['gps-attendance'] = makeSet({ view: true, add: true });
  menus['staff-location-map'] = makeSet({ view: true });
  menus['attendance-photo-gallery'] = makeSet({ view: true, print: true });
  menus['attendance-reports'] = makeSet({ view: true, print: true });
  menus['govt-annapurna'] = makeSet({ view: true, add: true, edit: true, print: true });
  menus['tasks'] = makeSet({ view: true, edit: true });
  menus['chat'] = makeSet({ view: true, add: true, edit: true, delete: true });
  menus['documents'] = makeSet({ view: true, add: true, print: true });
  if (role === 'CHECKER') {
    menus['reports'] = makeSet({ view: true, print: true });
  }
  return {
    role: role || 'STAFF',
    isSuperAdmin: false,
    menus,
    extra: {
      cashOperationLimit: 5000,
      customerAccessScope: 'ASSIGNED',
      customerAccessLimit: 250,
      canApproveTransactions: false,
      canViewAllAttendancePhotos: false,
      canManageBackupSettings: false,
      canManageUserPermissions: false,
      accountActive: true
    }
  };
}

export function getEffectivePermissions(user = null) {
  const activeUser = user || getCurrentUser();
  if (!activeUser || !activeUser.role) {
    const empty = getDefaultRoleEffectiveClient('STAFF');
    Object.keys(empty.menus).forEach(k => { empty.menus[k] = makeSet(); });
    empty.extra.accountActive = false;
    return empty;
  }

  const rootSuper = isSuperAdmin(activeUser);
  if (rootSuper) {
    const adminEff = getDefaultRoleEffectiveClient('ADMIN');
    adminEff.isSuperAdmin = true;
    return adminEff;
  }

  if (activeUser.effectivePermissions && activeUser.effectivePermissions.menus && activeUser.effectivePermissions.extra) {
    return activeUser.effectivePermissions;
  }

  const role = String(activeUser.role || 'STAFF').trim().toUpperCase();
  const base = getDefaultRoleEffectiveClient(role);
  const ov = activeUser.permissionOverrides || {};
  Object.keys(base.menus).forEach(menuId => {
    if (ov[menuId] && typeof ov[menuId] === 'object') {
      base.menus[menuId] = { ...base.menus[menuId], ...ov[menuId] };
    }
  });
  if (activeUser.extraPermissions && typeof activeUser.extraPermissions === 'object') {
    base.extra = { ...base.extra, ...activeUser.extraPermissions };
  }
  if (activeUser.status && activeUser.status !== 'ACTIVE') {
    base.extra.accountActive = false;
  }
  if (role !== 'ADMIN') {
    base.menus['attendance-photo-gallery'].delete = false;
    base.menus['admin-settings'] = makeSet();
    if (role !== 'MANAGER') {
      base.extra.canViewAllAttendancePhotos = false;
    }
  }
  return base;
}

export function canMenu(menuId, action = 'view', user = null) {
  const activeUser = user || getCurrentUser();
  if (!activeUser || !activeUser.role) return false;
  if (isSuperAdmin(activeUser)) return true;
  const eff = getEffectivePermissions(activeUser);
  if (eff.extra && eff.extra.accountActive === false) return false;
  const normalized = normalizeMenuId(menuId);
  const set = eff.menus?.[normalized];
  if (!set) return false;
  return Boolean(set[action]);
}

export function canExtra(flagName, user = null) {
  const activeUser = user || getCurrentUser();
  if (!activeUser || !activeUser.role) return false;
  if (isSuperAdmin(activeUser)) {
    if (flagName === 'cashOperationLimit' || flagName === 'customerAccessLimit') return 0;
    if (flagName === 'customerAccessScope') return 'ALL';
    return true;
  }
  const eff = getEffectivePermissions(activeUser);
  return eff.extra ? eff.extra[flagName] : undefined;
}

export function getCashOperationLimit(user = null) {
  const activeUser = user || getCurrentUser();
  if (!activeUser || isSuperAdmin(activeUser)) return 0;
  const val = Number(canExtra('cashOperationLimit', activeUser));
  return Number.isFinite(val) && val > 0 ? val : 0;
}

export async function refreshSessionPermissions() {
  const token = localStorage.getItem('MUN_COMPUTER_SESSION_TOKEN') || '';
  const active = getCurrentUser();
  if (!token || !active) return null;
  try {
    const resp = await fetch('/api/auth/session', {
      headers: {
        'Content-Type': 'application/json',
        'x-session-token': token,
        'x-actor-uid': active.uid || active.id || ''
      }
    });
    const data = await resp.json();
    if (resp.ok && data.authenticated && data.user) {
      setCurrentUser({ ...active, ...data.user });
      return data.user;
    }
    if (resp.status === 401 || data.authenticated === false) {
      handleSessionInvalidationResponse(401, { message: data.message || 'Session expired' });
    }
  } catch {
    // offline or transient failure
  }
  return null;
}

/**
 * Check if the active user or given user possesses a specific permission flag
 */
export function can(permissionName, user = null) {
  const activeUser = user || getCurrentUser();
  if (!activeUser || !activeUser.role) return false;
  if (isSuperAdmin(activeUser)) return true;

  if (permissionName === 'canApproveUsers') {
    return Boolean(canMenu('user-approvals', 'approve', activeUser) || canExtra('canManageUserPermissions', activeUser));
  }
  if (permissionName === 'canManageUsers') {
    return Boolean(canMenu('user-approvals', 'view', activeUser) || canExtra('canManageUserPermissions', activeUser));
  }
  if (permissionName === 'canManageSettings') {
    return Boolean(canMenu('settings', 'view', activeUser) || canExtra('canManageBackupSettings', activeUser));
  }
  if (permissionName === 'canViewFinancials') {
    return Boolean(canMenu('payments', 'view', activeUser) || canMenu('income', 'view', activeUser) || canMenu('cash-reports', 'view', activeUser));
  }
  if (permissionName === 'canDeleteRecords') {
    return activeUser.role === 'ADMIN' || Boolean(canMenu('customers', 'delete', activeUser) || canMenu('services', 'delete', activeUser));
  }
  if (permissionName === 'canExportData') {
    return Boolean(canMenu('reports', 'export', activeUser) || canMenu('customers', 'export', activeUser) || canMenu('cash-reports', 'export', activeUser));
  }
  if (permissionName === 'canManageCustomers') return canMenu('customers', 'add', activeUser) || canMenu('customers', 'edit', activeUser);
  if (permissionName === 'canManageServices') return canMenu('services', 'add', activeUser) || canMenu('services', 'edit', activeUser);
  if (permissionName === 'canManageFollowups') return canMenu('followups', 'add', activeUser) || canMenu('followups', 'edit', activeUser);
  if (permissionName === 'canManagePayments') return canMenu('payments', 'add', activeUser) || canMenu('payments', 'edit', activeUser);
  if (permissionName === 'canManageInvoices') return canMenu('invoices', 'add', activeUser) || canMenu('invoices', 'edit', activeUser);
  if (permissionName === 'canManageExpenses') return canMenu('expenses', 'add', activeUser) || canMenu('expenses', 'approve', activeUser);
  if (permissionName === 'canManageTasks') return canMenu('tasks', 'add', activeUser) || canMenu('tasks', 'edit', activeUser);
  if (permissionName === 'canManageInventory') return canMenu('inventory', 'add', activeUser) || canMenu('inventory', 'edit', activeUser);
  if (permissionName === 'canManageDaybook') return canMenu('counter-daybook', 'add', activeUser) || canMenu('counter-daybook', 'edit', activeUser);
  if (permissionName === 'canManagePayroll') return canMenu('staff-attendance', 'edit', activeUser) || activeUser.role === 'ADMIN' || activeUser.role === 'MANAGER';
  if (permissionName === 'canManageTargets') return canMenu('targets', 'add', activeUser) || canMenu('targets', 'edit', activeUser);
  if (permissionName === 'canManageProjects') return canMenu('projects', 'add', activeUser) || canMenu('projects', 'edit', activeUser);
  if (permissionName === 'canManageInvestments') return canMenu('investments', 'add', activeUser) || canMenu('investments', 'edit', activeUser);
  if (permissionName === 'canSwitchBusinessUnits') return canMenu('business', 'view', activeUser);

  const rolePerms = PERMISSIONS[activeUser.role] || {};
  return !!rolePerms[permissionName];
}

/**
 * Check if a role or user is authorized to access a given route
 */
export function canAccessRoute(route, userOrRole = null) {
  if (!route || route === 'login' || route === 'access-denied' || route === 'change-password') return true;

  if (typeof userOrRole === 'string') {
    if (route === 'admin-settings') return String(userOrRole).toUpperCase() === 'ADMIN';
    const def = getDefaultRoleEffectiveClient(userOrRole);
    const norm = normalizeMenuId(route);
    if (route === 'customer-registration') return Boolean(def.menus?.['customers']?.add || def.menus?.['customers']?.view);
    return Boolean(def.menus?.[norm]?.view);
  }

  const targetUser = userOrRole && userOrRole.role ? userOrRole : getCurrentUser();
  if (!targetUser || !targetUser.role) return false;
  if (isSuperAdmin(targetUser)) return true;
  if (route === 'admin-settings') return String(targetUser.role).toUpperCase() === 'ADMIN';

  const norm = normalizeMenuId(route);
  if (norm === 'settings' && canExtra('canManageBackupSettings', targetUser)) return true;
  if (norm === 'user-approvals' && canExtra('canManageUserPermissions', targetUser)) return true;
  if (route === 'customer-registration') return canMenu('customers', 'add', targetUser) || canMenu('customers', 'view', targetUser);
  return canMenu(norm, 'view', targetUser);
}

/**
 * Authenticate credentials strictly against central server API
 */
export async function authenticateAsync(uid, password, panelRole = 'STAFF', captchaToken = '', captchaInput = '') {
  const cleanUid = (uid || '').trim().toUpperCase();
  const inputPass = (password || '').trim();

  if (!cleanUid || !inputPass) {
    return { success: false, message: 'Please provide both User ID and Password.' };
  }

  try {
    const resp = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid: cleanUid, password: inputPass, panelRole, captchaToken, captchaInput })
    });
    const data = await resp.json();

    if (resp.ok && data.success) {
      if (data.sessionToken) {
        localStorage.setItem('MUN_COMPUTER_SESSION_TOKEN', data.sessionToken);
      }
      setCurrentUser(data.user);
      const users = getItem(KEYS.USERS, []);
      const idx = users.findIndex(u => (u.uid || u.id) === data.user.uid);
      if (idx !== -1) {
        users[idx] = { ...users[idx], ...data.user };
      } else {
        users.push(data.user);
      }
      setItem(KEYS.USERS, users);

      return {
        success: true,
        user: data.user,
        mustChangePassword: data.mustChangePassword,
        message: data.message
      };
    }
    return {
      success: false,
      message: data.message || 'Authentication failed. Please check your credentials.'
    };
  } catch {
    return {
      success: false,
      message: 'Central authentication server is unreachable. Please verify server connection.'
    };
  }
}

/**
 * Change password strictly on central server API
 */
export async function changePasswordAsync(uid, currentPassword, newPassword, confirmPassword) {
  try {
    const resp = await fetch('/api/auth/change-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid, currentPassword, newPassword, confirmPassword })
    });
    const data = await resp.json();

    if (resp.ok && data.success) {
      if (data.sessionToken) {
        localStorage.setItem('MUN_COMPUTER_SESSION_TOKEN', data.sessionToken);
      }
      const active = getCurrentUser();
      if (active && (active.uid === uid || active.id === uid)) {
        const merged = data.user ? { ...active, ...data.user, mustChangePassword: false } : { ...active, mustChangePassword: false };
        setCurrentUser(merged);
      }
      return {
        success: true,
        message: data.message,
        user: data.user,
        dailyLimit: data.dailyLimit,
        dailyChangesUsed: data.dailyChangesUsed,
        remainingChangesToday: data.remainingChangesToday
      };
    }
    return {
      success: false,
      message: data.message || 'Password update failed.',
      dailyLimit: data.dailyLimit,
      dailyChangesUsed: data.dailyChangesUsed,
      remainingChangesToday: data.remainingChangesToday
    };
  } catch {
    return { success: false, message: 'Server unreachable while updating password.' };
  }
}

/**
 * Log out active session and clean credentials
 */
export function logout() {
  const user = getCurrentUser();
  if (user) {
    logAuditAction('AUTH_LOGOUT', `User ${user.name} (${user.uid || user.id}) logged out from MUN COMPUTER`, user);
  }
  localStorage.removeItem('MUN_COMPUTER_SESSION_TOKEN');
  setItem(KEYS.CURRENT_USER, { isLoggedOut: true });
  localStorage.removeItem(KEYS.CURRENT_USER);
}
