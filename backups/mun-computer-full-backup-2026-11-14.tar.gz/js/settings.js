/**
 * settings.js - Business Settings, User & Super Admin Approval Management & Backup/Restore
 * MUN COMPUTER BUSINESS MANAGER
 */

import { getItem, setItem, KEYS, exportDatabaseBackup, restoreDatabaseBackup, logAuditAction, getAuthHeaders } from './storage.js';
import { getCurrentUser, isSuperAdmin, handleSessionInvalidationResponse, canExtra, setCurrentUser } from './auth.js';

function getActorHeaders() {
  return getAuthHeaders();
}

export function getAllUsers() {
  return getItem(KEYS.USERS, []);
}

export function getUserDashboardStats() {
  return window._munUserStats || null;
}

export function getRecentLoginActivity() {
  return window._munRecentLogins || [];
}

export async function fetchIdFormatPreview(role = 'STAFF') {
  try {
    const res = await fetch(`/api/auth/id-preview?role=${encodeURIComponent(role)}`);
    if (res.ok) return await res.json();
  } catch {
    // ignore
  }
  return null;
}

export async function fetchUsersFromBackend(query = '') {
  try {
    const url = query ? `/api/users?q=${encodeURIComponent(query)}` : '/api/users';
    const res = await fetch(url, { headers: getActorHeaders() });
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.users)) {
        if (!query) setItem(KEYS.USERS, data.users);
        if (data.stats) window._munUserStats = data.stats;
        if (Array.isArray(data.recentLogins)) window._munRecentLogins = data.recentLogins;
        return data.users;
      }
    }
  } catch (err) {
    console.warn('Backend /api/users fetch failed, using local storage:', err);
  }
  return getAllUsers();
}

export async function fetchAuditLogsFromBackend() {
  try {
    const res = await fetch('/api/audit-logs', { headers: getActorHeaders() });
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.logs)) {
        return data.logs;
      }
    }
  } catch (err) {
    console.warn('Backend /api/audit-logs fetch failed:', err);
  }
  return getItem(KEYS.AUDIT_LOGS, []);
}

export async function saveUser(userData) {
  const allowedRoles = ['ADMIN', 'MANAGER', 'MAKER', 'CHECKER', 'STAFF'];
  const rawRole = String(userData.role || 'STAFF').trim().toUpperCase();
  const targetRole = allowedRoles.includes(rawRole) ? rawRole : 'STAFF';

  try {
    const resp = await fetch('/api/users/create', {
      method: 'POST',
      headers: getActorHeaders(),
      body: JSON.stringify({
        name: userData.name,
        fatherName: userData.fatherName || '',
        motherName: userData.motherName || '',
        dob: userData.dob || '',
        role: targetRole,
        designation: userData.designation,
        phone: userData.phone,
        aadhaarNumber: userData.aadhaarNumber || '',
        email: userData.email || '',
        district: userData.district || 'Murshidabad',
        areaType: userData.areaType || 'RURAL',
        blockOrMunicipality: userData.blockOrMunicipality || '',
        gpOrWard: userData.gpOrWard || '',
        villageOrWard: userData.villageOrWard || '',
        postOffice: userData.postOffice || '',
        policeStation: userData.policeStation || '',
        pinCode: userData.pinCode || '',
        address: userData.address || ''
      })
    });
    const data = await resp.json();
    handleSessionInvalidationResponse(resp.status, data);
    if (resp.ok && data.success && data.user) {
      await fetchUsersFromBackend();
      logAuditAction('USER_REQUEST_CREATED', `Submitted ${targetRole} request ${data.user.requestId} for ${data.user.name} (Pending Administration Approval)`);
      return { success: true, user: data.user, message: data.message };
    }
    return { success: false, message: data.message || 'Failed to submit user request.' };
  } catch {
    return { success: false, message: 'Server unreachable. User creation requires central backend verification.' };
  }
}

export async function editUser(userData) {
  if (!isSuperAdmin()) {
    return { success: false, message: 'ACCESS DENIED: Only Administration (MUNCOMPUTER-2019) can edit user profiles.' };
  }
  try {
    const resp = await fetch('/api/users/edit', {
      method: 'POST',
      headers: getActorHeaders(),
      body: JSON.stringify(userData)
    });
    const data = await resp.json();
    handleSessionInvalidationResponse(resp.status, data);
    if (resp.ok && data.success) {
      await fetchUsersFromBackend();
      return { success: true, user: data.user, message: data.message };
    }
    return { success: false, message: data.message || 'Failed to update user.' };
  } catch {
    return { success: false, message: 'Server error while updating user.' };
  }
}

export async function approveUser(requestIdOrUid, notes = '') {
  if (!isSuperAdmin()) {
    return { success: false, message: 'ACCESS DENIED: Only Administration (MUNCOMPUTER-2019) can approve user accounts.' };
  }

  try {
    const resp = await fetch('/api/users/approve', {
      method: 'POST',
      headers: getActorHeaders(),
      body: JSON.stringify({ requestId: requestIdOrUid, uid: requestIdOrUid, notes })
    });
    const data = await resp.json();
    handleSessionInvalidationResponse(resp.status, data);
    if (resp.ok && data.success) {
      await fetchUsersFromBackend();
      logAuditAction('USER_APPROVE', `Administration approved ${requestIdOrUid}. Assigned UID: ${data.uid}`);
      return { success: true, message: data.message, uid: data.uid, temporaryPassword: data.temporaryPassword, user: data.user };
    }
    return { success: false, message: data.message || 'Approval failed.' };
  } catch {
    return { success: false, message: 'Server error during Administration approval.' };
  }
}

export async function rejectUser(requestIdOrUid, reason = '') {
  if (!isSuperAdmin()) {
    return { success: false, message: 'ACCESS DENIED: Only Administration (MUNCOMPUTER-2019) can reject user accounts.' };
  }

  try {
    const resp = await fetch('/api/users/reject', {
      method: 'POST',
      headers: getActorHeaders(),
      body: JSON.stringify({ requestId: requestIdOrUid, uid: requestIdOrUid, reason })
    });
    const data = await resp.json();
    handleSessionInvalidationResponse(resp.status, data);
    if (resp.ok && data.success) {
      await fetchUsersFromBackend();
      logAuditAction('USER_REJECT', `Administration rejected registration ${requestIdOrUid}`);
      return { success: true, message: data.message };
    }
    return { success: false, message: data.message || 'Rejection failed.' };
  } catch {
    return { success: false, message: 'Server error during rejection.' };
  }
}

export async function requestUserCorrection(requestIdOrUid, notes = '') {
  if (!isSuperAdmin()) {
    return { success: false, message: 'ACCESS DENIED: Only Administration (MUNCOMPUTER-2019) can request corrections.' };
  }

  try {
    const resp = await fetch('/api/users/request-correction', {
      method: 'POST',
      headers: getActorHeaders(),
      body: JSON.stringify({ requestId: requestIdOrUid, uid: requestIdOrUid, notes })
    });
    const data = await resp.json();
    handleSessionInvalidationResponse(resp.status, data);
    if (resp.ok && data.success) {
      await fetchUsersFromBackend();
      logAuditAction('USER_CORRECTION', `Administration requested correction for ${requestIdOrUid}: ${notes}`);
      return { success: true, message: data.message };
    }
    return { success: false, message: data.message || 'Correction request failed.' };
  } catch {
    return { success: false, message: 'Server error requesting correction.' };
  }
}

export async function toggleUserStatus(requestIdOrUid) {
  if (!isSuperAdmin()) {
    return { success: false, message: 'ACCESS DENIED: Only Administration (MUNCOMPUTER-2019) can suspend or reactivate accounts.' };
  }

  if (requestIdOrUid === 'MUNCOMPUTER-2019' || requestIdOrUid === 'MUNCM-2026') {
    return { success: false, message: 'Cannot deactivate initial Administration account.' };
  }

  try {
    const resp = await fetch('/api/users/toggle-status', {
      method: 'POST',
      headers: getActorHeaders(),
      body: JSON.stringify({ requestId: requestIdOrUid, uid: requestIdOrUid })
    });
    const data = await resp.json();
    handleSessionInvalidationResponse(resp.status, data);
    if (resp.ok && data.success) {
      await fetchUsersFromBackend();
      logAuditAction('USER_STATUS_CHANGE', `Administration toggled status for ${requestIdOrUid} to ${data.status}`);
      return { success: true, message: data.message, status: data.status };
    }
    return { success: false, message: data.message || 'Status update failed.' };
  } catch {
    return { success: false, message: 'Server error updating status.' };
  }
}

export async function resetUserPassword(uid) {
  if (!isSuperAdmin()) {
    return { success: false, message: 'ACCESS DENIED: Only Administration can reset passwords.' };
  }

  try {
    const resp = await fetch('/api/users/reset-password', {
      method: 'POST',
      headers: getActorHeaders(),
      body: JSON.stringify({ uid })
    });
    const data = await resp.json();
    handleSessionInvalidationResponse(resp.status, data);
    if (resp.ok && data.success) {
      await fetchUsersFromBackend();
      logAuditAction('ADMIN_PASSWORD_RESET', `Administration generated a new one-time temporary password for ${uid}.`);
      return { success: true, temporaryPassword: data.temporaryPassword, uid: data.uid, message: data.message };
    }
    return { success: false, message: data.message || 'Password reset failed.' };
  } catch {
    return { success: false, message: 'Server error resetting password.' };
  }
}

export function deleteUser(id) {
  if (!isSuperAdmin() && !canExtra('canManageUserPermissions')) {
    return { success: false, message: 'Only Administration can remove accounts.' };
  }
  const users = getAllUsers();
  if (users.length <= 1) {
    return { success: false, message: 'Cannot delete the only administrative user account.' };
  }
  if (id === 'MUNCOMPUTER-2019' || id === 'MUNCM-2026') {
    return { success: false, message: 'Cannot delete initial Administration account.' };
  }
  const updated = users.filter(u => (u.uid || u.id || u.requestId) !== id);
  setItem(KEYS.USERS, updated);
  logAuditAction('USER_DELETE', `Deleted user account: ${id}`);
  return { success: true };
}

export async function fetchPermissionsSchema() {
  try {
    const resp = await fetch('/api/permissions/schema', { headers: getActorHeaders() });
    const data = await resp.json();
    if (resp.ok && data.success) return data;
  } catch (err) {
    console.warn('fetchPermissionsSchema error:', err);
  }
  return null;
}

export async function saveUserPermissions(payload) {
  try {
    const resp = await fetch('/api/users/permissions', {
      method: 'POST',
      headers: getActorHeaders(),
      body: JSON.stringify(payload)
    });
    const data = await resp.json();
    handleSessionInvalidationResponse(resp.status, data);
    if (resp.ok && data.success) {
      await fetchUsersFromBackend();
      const active = getCurrentUser();
      if (active && data.user && (active.uid === data.user.uid || active.id === data.user.uid)) {
        setCurrentUser({ ...active, ...data.user });
      }
      return { success: true, user: data.user, effectivePermissions: data.effectivePermissions, message: data.message };
    }
    return { success: false, message: data.message || 'Failed to update user permissions.' };
  } catch {
    return { success: false, message: 'Server unreachable while saving user permissions.' };
  }
}

export async function deleteUserAccount(uidOrRequestId, reason) {
  try {
    const resp = await fetch('/api/users/delete', {
      method: 'POST',
      headers: getActorHeaders(),
      body: JSON.stringify({ uid: uidOrRequestId, requestId: uidOrRequestId, reason })
    });
    const data = await resp.json();
    handleSessionInvalidationResponse(resp.status, data);
    if (resp.ok && data.success) {
      await fetchUsersFromBackend();
      return { success: true, message: data.message };
    }
    return { success: false, message: data.message || 'Failed to delete user.' };
  } catch {
    return { success: false, message: 'Server unreachable while deleting user.' };
  }
}

export async function fetchDeleteHistory(targetType = '') {
  try {
    const url = targetType
      ? `/api/security/delete-history?targetType=${encodeURIComponent(targetType)}`
      : '/api/security/delete-history';
    const resp = await fetch(url, { headers: getActorHeaders() });
    const data = await resp.json();
    if (resp.ok && data.success) return data.history || [];
  } catch (err) {
    console.warn('fetchDeleteHistory failed:', err);
  }
  return [];
}

export async function logDeleteHistory(entry) {
  try {
    const resp = await fetch('/api/security/delete-history', {
      method: 'POST',
      headers: getActorHeaders(),
      body: JSON.stringify(entry)
    });
    const data = await resp.json();
    if (resp.ok && data.success) return { success: true, record: data.record };
    return { success: false, message: data.message || 'Delete reason log failed.' };
  } catch {
    return { success: false, message: 'Server unreachable while logging delete reason.' };
  }
}

export async function fetchAutoBackupSnapshots() {
  try {
    const resp = await fetch('/api/backup/snapshots', { headers: getActorHeaders() });
    const data = await resp.json();
    if (resp.ok && data.success) return data.snapshots || [];
  } catch (err) {
    console.warn('fetchAutoBackupSnapshots failed:', err);
  }
  return [];
}

export async function triggerAutoBackupSnapshot() {
  try {
    const resp = await fetch('/api/backup/auto-snapshot', {
      method: 'POST',
      headers: getActorHeaders(),
      body: JSON.stringify({ trigger: 'MANUAL' })
    });
    const data = await resp.json();
    if (resp.ok && data.success) return { success: true, snapshot: data.snapshot, snapshots: data.snapshots || [] };
    return { success: false, message: data.message || 'Snapshot failed.' };
  } catch {
    return { success: false, message: 'Server unreachable while creating backup snapshot.' };
  }
}

export function downloadBackupFile() {
  const backupJson = exportDatabaseBackup();
  const blob = new Blob([backupJson], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `MUN_COMPUTER_Business_Manager_Backup_${new Date().toISOString().split('T')[0]}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  return true;
}

export function restoreFromFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = restoreDatabaseBackup(e.target.result);
      if (result.success) {
        resolve(result);
      } else {
        reject(new Error(result.error || 'Failed to restore backup'));
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
}
