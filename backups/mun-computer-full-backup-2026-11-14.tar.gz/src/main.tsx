import {createRoot} from 'react-dom/client';
import './index.css';
import '../css/style.css';
import '../css/dashboard.css';
import '../css/components.css';
import '../css/responsive.css';
import App from './App.tsx';
import { FirebaseProvider } from './contexts/FirebaseContext';

if (import.meta.env.DEV && 'serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then((registrations) => {
    registrations.forEach((registration) => {
      if (registration.active?.scriptURL?.includes('dev-sw')) {
        registration.unregister();
      }
    });
  });
}

createRoot(document.getElementById('root')!).render(
  <FirebaseProvider>
    <App />
  </FirebaseProvider>
);
