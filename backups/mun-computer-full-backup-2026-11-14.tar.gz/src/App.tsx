import React, { useState, useEffect, useLayoutEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence, MotionConfig } from 'motion/react';
import {
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  KeyRound,
  RefreshCw,
  X,
  ShieldCheck,
  Crown,
  Briefcase,
  UserCheck,
  Lock,
  Check,
  Shield,
  User
} from 'lucide-react';
import { PWAInstallButton, OfflineIndicator, PWAInstallModalHost } from './components/PWAInstallButton';
import { SessionTimeoutNotice } from './components/SessionTimeoutNotice';
import '../js/app.js';

declare global {
  interface Window {
    MJK?: {
      render?: (preserveRoute?: boolean, explicitMount?: HTMLElement | null) => void;
      navigateTo?: (route: string) => void;
      closeModal?: () => void;
      [key: string]: any;
    };
    _munUserStats?: Record<string, number>;
    _munRecentLogins?: any[];
  }
}

type RequestedRole = 'STAFF' | 'MAKER' | 'CHECKER' | 'MANAGER' | 'ADMIN';
type LoginPanel = 'ADMIN' | 'MANAGER' | 'STAFF';

interface AuthUser {
  requestId?: string;
  uid: string;
  name: string;
  role: RequestedRole;
  isSuperAdmin?: boolean;
  designation: string;
  phone?: string;
  phoneMasked?: string;
  aadhaarMasked?: string;
  email?: string;
  address?: string;
  mustChangePassword?: boolean;
  approvalStatus?: string;
  status: string;
  isLoggedOut?: boolean;
  dailyPasswordChangesUsed?: number;
  dailyPasswordChangesRemaining?: number;
  dailyPasswordChangeLimit?: number;
}

const ERP_USER_KEY = 'MUN_COMPUTER_ERP_v1_current_user';
const ERP_SESSION_KEY = 'MUN_COMPUTER_SESSION_TOKEN';
const ERP_USERS_KEY = 'MUN_COMPUTER_ERP_v1_users';
const ERP_AUDIT_KEY = 'MUN_COMPUTER_ERP_v1_audit_logs';
const REMEMBER_UID_KEY = 'mun_remembered_uid';
const DEFAULT_ADMIN_UID = 'MUNCOMPUTER-2019';
const INACTIVITY_TIMEOUT_MS = 15 * 60 * 1000; // 15 minutes
const INACTIVITY_WARNING_MS = 2 * 60 * 1000; // Show countdown notice in final 2 minutes

function getPasswordChecks(pwd: string) {
  return {
    length: pwd.length >= 8,
    upper: /[A-Z]/.test(pwd),
    lower: /[a-z]/.test(pwd),
    digit: /[0-9]/.test(pwd),
    special: /[^A-Za-z0-9]/.test(pwd)
  };
}

function isStrongPasswordClient(pwd: string): boolean {
  const c = getPasswordChecks(pwd);
  return c.length && c.upper && c.lower && c.digit && c.special;
}

function getInitialUid(): string {
  try {
    const remembered = localStorage.getItem(REMEMBER_UID_KEY);
    if (!remembered || remembered === 'MUNCM-2026') {
      if (remembered === 'MUNCM-2026') {
        localStorage.setItem(REMEMBER_UID_KEY, DEFAULT_ADMIN_UID);
      }
      return DEFAULT_ADMIN_UID;
    }
    return remembered;
  } catch {
    return DEFAULT_ADMIN_UID;
  }
}

function readStoredUser(): AuthUser | null {
  try {
    const raw =
      localStorage.getItem(ERP_USER_KEY) ||
      localStorage.getItem('mun_computer_v3_user') ||
      localStorage.getItem('mun_current_user');
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || parsed.isLoggedOut || !parsed.uid) return null;
    if (parsed.status && parsed.status !== 'ACTIVE') return null;
    return parsed;
  } catch {
    return null;
  }
}

function getAuthRequestHeaders(user: AuthUser | null): Record<string, string> {
  const token = localStorage.getItem(ERP_SESSION_KEY) || '';
  const headers: Record<string, string> = {};
  if (token) headers['x-session-token'] = token;
  if (user?.uid) headers['x-actor-uid'] = user.uid;
  return headers;
}

function MunComputerLogo() {
  return (
    <div className="flex flex-col items-center justify-center select-none pt-0.5">
      <img
        src="/assets/aistudio/MUN_Computer_Tech_Logo_35ee99e8.png"
        alt="MUN COMPUTER"
        className="h-[68px] sm:h-[78px] w-auto max-w-full object-contain drop-shadow-[0_2px_6px_rgba(0,68,170,0.10)]"
      />
    </div>
  );
}

function LoginWaveBackdrop() {
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full select-none"
      viewBox="0 0 1440 900"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="waveRibbonA" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#60b6ff" stopOpacity="0.45" />
          <stop offset="50%" stopColor="#ffffff" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#2b8eff" stopOpacity="0.32" />
        </linearGradient>
        <linearGradient id="waveRibbonB" x1="100%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#3b9eff" stopOpacity="0.38" />
          <stop offset="60%" stopColor="#bfe1ff" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0.65" />
        </linearGradient>
      </defs>
      <path
        d="M-80 650 C220 500, 420 790, 780 620 C1080 480, 1260 220, 1520 120 L1520 960 L-80 960 Z"
        fill="url(#waveRibbonA)"
      />
      <path
        d="M-120 220 C180 60, 440 310, 820 140 C1060 30, 1280 90, 1520 10 L1520 -80 L-120 -80 Z"
        fill="url(#waveRibbonB)"
      />
      <path
        d="M-60 760 C310 640, 560 880, 960 720 C1210 620, 1360 440, 1520 380 L1520 960 L-60 960 Z"
        fill="#ffffff"
        fillOpacity="0.28"
      />
    </svg>
  );
}

function PasswordInstructionsCard({ pwd }: { pwd: string }) {
  const checks = getPasswordChecks(pwd);
  const items = [
    { ok: checks.length, label: 'Minimum 8 Characters' },
    { ok: checks.upper, label: '1 Capital Letter (A–Z)' },
    { ok: checks.lower, label: '1 Small Letter (a–z)' },
    { ok: checks.digit, label: '1 Number (0–9)' },
    { ok: checks.special, label: '1 Special Symbol (@#$%&*!)' }
  ];

  return (
    <div className="p-3.5 rounded-xl bg-white/85 border border-blue-200 space-y-2.5 shadow-xs">
      <div className="flex items-start gap-2">
        <Shield className="w-4 h-4 text-[#0052cc] shrink-0 mt-0.5" />
        <div>
          <div className="text-[11px] font-bold tracking-wide text-[#0b2447] uppercase">
            Password Instructions (Required for All Users)
          </div>
          <p className="text-[11px] text-slate-600 leading-relaxed mt-0.5">
            Must be at least 8 characters and include a Capital letter, Small letter, Number, and Special Symbol. Logged-in password changes are allowed up to 5 times per day.
          </p>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-1.5 pt-1.5 border-t border-blue-100 text-[11px]">
        {items.map((item, idx) => (
          <div
            key={item.label}
            className={`flex items-center gap-1.5 ${idx === items.length - 1 ? 'col-span-2' : ''} ${
              item.ok ? 'text-emerald-700 font-semibold' : 'text-slate-600'
            }`}
          >
            {item.ok ? <Check className="w-3.5 h-3.5 shrink-0 text-emerald-600" /> : <span className="w-3.5 text-center">○</span>}
            <span>{item.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function App() {
  const todayDateStr = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });

  // Authentication State (3 Main Login Panels)
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(() => readStoredUser());
  const [activePanel, setActivePanel] = useState<LoginPanel>('ADMIN');
  const [uid, setUid] = useState<string>(() => getInitialUid());
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [rememberMe, setRememberMe] = useState<boolean>(true);
  const [loginCaptchaSvg, setLoginCaptchaSvg] = useState<string>('');
  const [loginCaptchaToken, setLoginCaptchaToken] = useState<string>('');
  const [loginCaptchaInput, setLoginCaptchaInput] = useState<string>('');
  const [captchaLoading, setCaptchaLoading] = useState<boolean>(false);
  const [captchaError, setCaptchaError] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loginAlert, setLoginAlert] = useState<{ type: 'error' | 'success' | 'info'; text: string } | null>(null);

  // Mandatory Password Change
  const [isMandatoryModalOpen, setIsMandatoryModalOpen] = useState<boolean>(() => Boolean(readStoredUser()?.mustChangePassword));
  const [changeCurrentPwd, setChangeCurrentPwd] = useState<string>('');
  const [changeNewPwd, setChangeNewPwd] = useState<string>('');
  const [changeConfirmPwd, setChangeConfirmPwd] = useState<string>('');
  const [showChangeCurrentPwd, setShowChangeCurrentPwd] = useState<boolean>(false);
  const [showChangeNewPwd, setShowChangeNewPwd] = useState<boolean>(false);
  const [showChangeConfirmPwd, setShowChangeConfirmPwd] = useState<boolean>(false);
  const [changeAlert, setChangeAlert] = useState<string | null>(null);
  const [isChangingPwd, setIsChangingPwd] = useState<boolean>(false);

  // Separate Forgot Password Interface (STRICT NO-OTP 6-STEP FLOW)
  const [isForgotModalOpen, setIsForgotModalOpen] = useState<boolean>(false);
  const [forgotStep, setForgotStep] = useState<1 | 2 | 3 | 4 | 5 | 6>(1);
  const [forgotUid, setForgotUid] = useState<string>('');
  const [forgotCaptchaSvg, setForgotCaptchaSvg] = useState<string>('');
  const [forgotCaptchaToken, setForgotCaptchaToken] = useState<string>('');
  const [forgotCaptchaInput, setForgotCaptchaInput] = useState<string>('');
  const [forgotCaptchaLoading, setForgotCaptchaLoading] = useState<boolean>(false);
  const [forgotCaptchaError, setForgotCaptchaError] = useState<boolean>(false);
  const [forgotStepToken, setForgotStepToken] = useState<string>('');
  const [forgotPhone, setForgotPhone] = useState<string>('');
  const [forgotAadhaar, setForgotAadhaar] = useState<string>('');
  const [forgotResetToken, setForgotResetToken] = useState<string>('');
  const [forgotNewPwd, setForgotNewPwd] = useState<string>('');
  const [forgotConfirmPwd, setForgotConfirmPwd] = useState<string>('');
  const [showForgotNewPwd, setShowForgotNewPwd] = useState<boolean>(false);
  const [showForgotConfirmPwd, setShowForgotConfirmPwd] = useState<boolean>(false);
  const [forgotSuccessBanner, setForgotSuccessBanner] = useState<{ title: string; message: string }>({
    title: 'PASSWORD RESET SUCCESSFUL!',
    message: 'Your password has been changed successfully. Please log in with your new password.'
  });
  const [forgotAlert, setForgotAlert] = useState<{ type: 'error' | 'info' | 'success'; text: string } | null>(null);
  const [forgotLoading, setForgotLoading] = useState<boolean>(false);

  // Subtle 15-minute inactivity warning countdown
  const [isSessionWarningVisible, setIsSessionWarningVisible] = useState<boolean>(false);
  const [sessionRemainingMs, setSessionRemainingMs] = useState<number>(INACTIVITY_WARNING_MS);
  const [isExtendingSession, setIsExtendingSession] = useState<boolean>(false);

  const erpRootRef = useRef<HTMLDivElement | null>(null);
  const currentUserRef = useRef<AuthUser | null>(currentUser);
  currentUserRef.current = currentUser;
  const uidRef = useRef<string>(uid);
  uidRef.current = uid;
  const activePanelRef = useRef<LoginPanel>(activePanel);
  activePanelRef.current = activePanel;
  const rememberMeRef = useRef<boolean>(rememberMe);
  rememberMeRef.current = rememberMe;
  const justLoggedInRef = useRef<boolean>(false);
  const idleLogoutReasonRef = useRef<string | null>(null);
  const extendSessionActivityRef = useRef<(() => void) | null>(null);

  const clearAuthStorage = useCallback(() => {
    localStorage.removeItem(ERP_SESSION_KEY);
    localStorage.removeItem(ERP_USER_KEY);
    localStorage.removeItem('mun_computer_v3_user');
    localStorage.removeItem('mun_current_user');
  }, []);

  const loadLoginCaptcha = useCallback(async () => {
    setCaptchaLoading(true);
    setCaptchaError(false);
    setLoginCaptchaInput('');
    try {
      const res = await fetch('/api/auth/captcha', { cache: 'no-store' });
      const data = await res.json();
      if (res.ok && data.success && data.svg && data.captchaToken) {
        setLoginCaptchaSvg(data.svg);
        setLoginCaptchaToken(data.captchaToken);
        setCaptchaError(false);
      } else {
        setLoginCaptchaSvg('');
        setLoginCaptchaToken('');
        setCaptchaError(true);
      }
    } catch {
      setLoginCaptchaSvg('');
      setLoginCaptchaToken('');
      setCaptchaError(true);
    } finally {
      setCaptchaLoading(false);
    }
  }, []);

  const loadForgotCaptcha = useCallback(async () => {
    setForgotCaptchaLoading(true);
    setForgotCaptchaError(false);
    setForgotCaptchaInput('');
    try {
      const res = await fetch('/api/auth/captcha', { cache: 'no-store' });
      const data = await res.json();
      if (res.ok && data.success && data.svg && data.captchaToken) {
        setForgotCaptchaSvg(data.svg);
        setForgotCaptchaToken(data.captchaToken);
        setForgotCaptchaError(false);
      } else {
        setForgotCaptchaSvg('');
        setForgotCaptchaToken('');
        setForgotCaptchaError(true);
      }
    } catch {
      setForgotCaptchaSvg('');
      setForgotCaptchaToken('');
      setForgotCaptchaError(true);
    } finally {
      setForgotCaptchaLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!currentUser) {
      loadLoginCaptcha();
    }
  }, [currentUser, loadLoginCaptcha]);

  const resetToLoginScreen = useCallback(
    (alertInfo: { type: 'error' | 'success' | 'info'; text: string } | null = null) => {
      clearAuthStorage();
      document.body.classList.remove('mobile-drawer-open', 'printing-inapp-sheet', 'printing-a4-popup');
      document.querySelector('.main-wrapper')?.scrollTo(0, 0);
      window.scrollTo(0, 0);
      justLoggedInRef.current = false;
      setCurrentUser(null);
      setIsMandatoryModalOpen(false);
      setIsForgotModalOpen(false);
      setIsLoading(false);
      setPassword('');
      setShowPassword(false);
      setLoginCaptchaInput('');
      setLoginCaptchaToken('');
      setLoginCaptchaSvg('');
      setCaptchaError(false);
      if (!rememberMeRef.current) {
        const year = todayDateStr.slice(0, 4);
        const panel = activePanelRef.current;
        setUid(
          panel === 'ADMIN'
            ? DEFAULT_ADMIN_UID
            : panel === 'MANAGER'
              ? `MUNCOMPUTER-MN-${year}-`
              : `MUNCOMPUTER-ST-${year}-`
        );
      } else if (activePanelRef.current === 'ADMIN' && !uidRef.current.trim()) {
        setUid(DEFAULT_ADMIN_UID);
      }
      setLoginAlert(alertInfo);
    },
    [clearAuthStorage, todayDateStr]
  );

  const syncAndRenderErp = useCallback(
    async (user: AuthUser, signal?: { cancelled: boolean }, skipSessionCheck = false) => {
      const cleanUser: AuthUser = { ...user, isLoggedOut: false };
      localStorage.setItem(ERP_USER_KEY, JSON.stringify(cleanUser));
      localStorage.setItem('mun_computer_v3_user', JSON.stringify(cleanUser));
      localStorage.setItem('mun_current_user', JSON.stringify(cleanUser));
      document.body.classList.remove('mobile-drawer-open', 'printing-inapp-sheet', 'printing-a4-popup');

      // Render ERP shell immediately so Dashboard appears right away without blocking on network checks
      const mountEl = erpRootRef.current || document.getElementById('erp-root');
      const activeHash = window.location.hash;
      const preserveExistingRoute =
        !skipSessionCheck &&
        Boolean(activeHash && activeHash !== '#' && activeHash !== '#login' && activeHash !== '#access-denied');
      if (mountEl && window.MJK?.render) {
        window.MJK.render(preserveExistingRoute, mountEl);
        window.scrollTo(0, 0);
        mountEl.querySelector('.main-wrapper')?.scrollTo(0, 0);
      }

      // Verify central session version token in background for restored sessions
      const token = localStorage.getItem(ERP_SESSION_KEY);
      if (token && !skipSessionCheck) {
        try {
          const sessResp = await fetch('/api/auth/session', {
            headers: { 'x-session-token': token }
          });
          if (signal?.cancelled) return;
          if (sessResp.status === 401) {
            resetToLoginScreen({
              type: 'info',
              text: 'Your session expired or was updated. Please sign in again.'
            });
            return;
          }
        } catch {
          // continue with local render if offline
        }
      }

      try {
        const headers = getAuthRequestHeaders(cleanUser);
        const [usersResp, logsResp] = await Promise.all([
          fetch('/api/users', { headers }),
          fetch('/api/audit-logs', { headers })
        ]);
        if (signal?.cancelled) return;

        let updatedCache = false;
        if (usersResp.ok) {
          const usersData = await usersResp.json();
          if (usersData.success && Array.isArray(usersData.users)) {
            const nextUsersJson = JSON.stringify(usersData.users);
            if (localStorage.getItem(ERP_USERS_KEY) !== nextUsersJson) {
              localStorage.setItem(ERP_USERS_KEY, nextUsersJson);
              updatedCache = true;
            }
            if (usersData.stats) window._munUserStats = usersData.stats;
            if (Array.isArray(usersData.recentLogins)) window._munRecentLogins = usersData.recentLogins;
          }
        }
        if (logsResp.ok) {
          const logsData = await logsResp.json();
          if (logsData.success && Array.isArray(logsData.logs)) {
            const nextLogsJson = JSON.stringify(logsData.logs);
            if (localStorage.getItem(ERP_AUDIT_KEY) !== nextLogsJson) {
              localStorage.setItem(ERP_AUDIT_KEY, nextLogsJson);
              updatedCache = true;
            }
          }
        }

        if (!signal?.cancelled && updatedCache) {
          const hasOpenModal = Boolean(
            document.getElementById('global-modal-overlay')?.classList.contains('open') ||
              document.getElementById('a4-print-popup-overlay') ||
              document.getElementById('inapp-print-overlay')
          );
          const activeTag = document.activeElement?.tagName || '';
          const isEditingInput = ['INPUT', 'TEXTAREA', 'SELECT'].includes(activeTag);
          if (hasOpenModal || isEditingInput) {
            return;
          }
          const activeMount = erpRootRef.current || document.getElementById('erp-root');
          if (activeMount && window.MJK?.render) {
            window.MJK.render(true, activeMount);
          }
        }
      } catch {
        // keep local cache if offline
      }
    },
    [resetToLoginScreen]
  );

  useEffect(() => {
    const onErpLogout = () => {
      const reason =
        idleLogoutReasonRef.current ||
        'Signed out successfully. Enter your credentials to sign in again.';
      idleLogoutReasonRef.current = null;
      resetToLoginScreen({
        type: 'info',
        text: reason
      });
    };
    window.addEventListener('mun-auth-logout', onErpLogout);
    return () => window.removeEventListener('mun-auth-logout', onErpLogout);
  }, [resetToLoginScreen]);

  const activeUid = currentUser?.uid || '';
  const mustChangePwd = Boolean(currentUser?.mustChangePassword);

  const triggerInactivityLogout = useCallback(() => {
    if (!currentUserRef.current) return;
    setIsSessionWarningVisible(false);
    const message =
      'Session timed out after 15 minutes of inactivity to protect this workstation. Please sign in again.';
    idleLogoutReasonRef.current = message;
    if (typeof window.MJK?.handleLogout === 'function') {
      window.MJK.handleLogout();
    }
    if (idleLogoutReasonRef.current !== null) {
      idleLogoutReasonRef.current = null;
      resetToLoginScreen({ type: 'info', text: message });
    }
  }, [resetToLoginScreen]);

  const handleExtendSession = useCallback(async () => {
    if (!currentUserRef.current) return;
    setIsExtendingSession(true);
    try {
      const token = localStorage.getItem(ERP_SESSION_KEY);
      if (token) {
        const resp = await fetch('/api/auth/session', {
          headers: { 'x-session-token': token }
        });
        if (resp.status === 401) {
          setIsSessionWarningVisible(false);
          resetToLoginScreen({
            type: 'info',
            text: 'Your session expired or was invalidated. Please sign in again.'
          });
          return;
        }
      }
    } catch {
      // Allow local session extension when offline
    } finally {
      setIsExtendingSession(false);
    }
    extendSessionActivityRef.current?.();
  }, [resetToLoginScreen]);

  const handleManualWarningSignOut = useCallback(() => {
    setIsSessionWarningVisible(false);
    if (typeof window.MJK?.handleLogout === 'function') {
      window.MJK.handleLogout();
      return;
    }
    resetToLoginScreen({
      type: 'info',
      text: 'Signed out successfully. Enter your credentials to sign in again.'
    });
  }, [resetToLoginScreen]);

  // Client-side 15-minute inactivity timer with 2-minute countdown warning
  useEffect(() => {
    if (!activeUid) {
      setIsSessionWarningVisible(false);
      extendSessionActivityRef.current = null;
      return;
    }

    let lastActivityAt = Date.now();
    let timeoutId: number | null = null;
    let countdownIntervalId: number | null = null;
    let lastThrottleResetAt = Date.now();
    let warningShown = false;

    const clearTimers = () => {
      if (timeoutId !== null) {
        window.clearTimeout(timeoutId);
        timeoutId = null;
      }
      if (countdownIntervalId !== null) {
        window.clearInterval(countdownIntervalId);
        countdownIntervalId = null;
      }
    };

    const startCountdownTicker = () => {
      if (countdownIntervalId !== null) return;
      const updateTick = () => {
        const remaining = INACTIVITY_TIMEOUT_MS - (Date.now() - lastActivityAt);
        if (remaining <= 0) {
          clearTimers();
          triggerInactivityLogout();
          return;
        }
        setSessionRemainingMs(remaining);
      };
      updateTick();
      countdownIntervalId = window.setInterval(updateTick, 500);
    };

    const scheduleCheck = () => {
      clearTimers();
      const elapsed = Date.now() - lastActivityAt;
      const remaining = INACTIVITY_TIMEOUT_MS - elapsed;

      if (remaining <= 0) {
        triggerInactivityLogout();
        return;
      }

      if (remaining <= INACTIVITY_WARNING_MS) {
        warningShown = true;
        setIsSessionWarningVisible(true);
        setSessionRemainingMs(remaining);
        startCountdownTicker();
        return;
      }

      if (warningShown) {
        warningShown = false;
        setIsSessionWarningVisible(false);
      }

      const msUntilWarning = remaining - INACTIVITY_WARNING_MS;
      timeoutId = window.setTimeout(() => {
        scheduleCheck();
      }, msUntilWarning);
    };

    const resetActivity = () => {
      lastActivityAt = Date.now();
      lastThrottleResetAt = lastActivityAt;
      warningShown = false;
      setIsSessionWarningVisible(false);
      setSessionRemainingMs(INACTIVITY_WARNING_MS);
      scheduleCheck();
    };

    extendSessionActivityRef.current = resetActivity;

    const handleUserActivity = () => {
      const now = Date.now();
      if (now - lastActivityAt >= INACTIVITY_TIMEOUT_MS) {
        clearTimers();
        triggerInactivityLogout();
        return;
      }
      // Once the warning notice is visible, require explicit "Extend Session" click
      // so passive mouse movement doesn't dismiss the timer before the user sees it.
      if (warningShown) return;

      lastActivityAt = now;
      if (now - lastThrottleResetAt >= 1000) {
        lastThrottleResetAt = now;
        scheduleCheck();
      }
    };

    const handleVisibilityOrFocus = () => {
      if (document.visibilityState === 'hidden') return;
      const remaining = INACTIVITY_TIMEOUT_MS - (Date.now() - lastActivityAt);
      if (remaining <= 0) {
        clearTimers();
        triggerInactivityLogout();
      } else {
        scheduleCheck();
      }
    };

    const activityEvents: Array<keyof WindowEventMap> = [
      'mousemove',
      'mousedown',
      'keydown',
      'touchstart',
      'scroll',
      'pointerdown',
      'wheel'
    ];

    activityEvents.forEach((evt) => {
      window.addEventListener(evt, handleUserActivity, { passive: true, capture: true });
    });
    document.addEventListener('visibilitychange', handleVisibilityOrFocus);
    window.addEventListener('focus', handleVisibilityOrFocus);

    scheduleCheck();

    return () => {
      clearTimers();
      extendSessionActivityRef.current = null;
      activityEvents.forEach((evt) => {
        window.removeEventListener(evt, handleUserActivity, { capture: true });
      });
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
      window.removeEventListener('focus', handleVisibilityOrFocus);
    };
  }, [activeUid, triggerInactivityLogout]);

  useLayoutEffect(() => {
    const activeUser = currentUserRef.current;
    if (!activeUser || mustChangePwd || isMandatoryModalOpen) {
      return;
    }
    const skipCheck = justLoggedInRef.current;
    justLoggedInRef.current = false;
    const signal = { cancelled: false };
    syncAndRenderErp(activeUser, signal, skipCheck);

    return () => {
      signal.cancelled = true;
      if (erpRootRef.current) {
        erpRootRef.current.innerHTML = '';
      }
    };
  }, [activeUid, mustChangePwd, isMandatoryModalOpen, syncAndRenderErp]);

  useEffect(() => {
    if (!isForgotModalOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsForgotModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isForgotModalOpen]);

  const handlePanelSelect = (panel: LoginPanel) => {
    setActivePanel(panel);
    setLoginAlert(null);
    setPassword('');
    loadLoginCaptcha();
    const currentYear = todayDateStr.slice(0, 4);
    if (panel === 'ADMIN') {
      setUid(DEFAULT_ADMIN_UID);
    } else if (panel === 'MANAGER') {
      setUid(`MUNCOMPUTER-MN-${currentYear}-`);
    } else {
      setUid(`MUNCOMPUTER-ST-${currentYear}-`);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginAlert(null);

    const cleanUid = uid.trim().toUpperCase();
    if (!cleanUid) {
      setLoginAlert({ type: 'error', text: 'Please enter your assigned User ID (UID).' });
      return;
    }
    if (!password) {
      setLoginAlert({ type: 'error', text: 'Please enter your account password.' });
      return;
    }
    if (!loginCaptchaToken) {
      setLoginAlert({ type: 'error', text: 'Security CAPTCHA is still loading. Please refresh CAPTCHA and try again.' });
      loadLoginCaptcha();
      return;
    }
    if (!loginCaptchaInput.trim()) {
      setLoginAlert({ type: 'error', text: 'Please enter the security CAPTCHA characters.' });
      return;
    }

    if (rememberMe) {
      localStorage.setItem(REMEMBER_UID_KEY, cleanUid);
    } else {
      localStorage.removeItem(REMEMBER_UID_KEY);
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: cleanUid,
          password,
          panelRole: activePanel,
          captchaToken: loginCaptchaToken,
          captchaInput: loginCaptchaInput.trim()
        })
      });
      const data = await response.json();

      if (response.ok && data.success && data.user) {
        const user: AuthUser = { ...data.user, isLoggedOut: false };
        if (data.sessionToken) {
          localStorage.setItem(ERP_SESSION_KEY, data.sessionToken);
        }
        localStorage.setItem(ERP_USER_KEY, JSON.stringify(user));
        localStorage.setItem('mun_computer_v3_user', JSON.stringify(user));
        localStorage.setItem('mun_current_user', JSON.stringify(user));

        const requireChange = Boolean(data.mustChangePassword || user.mustChangePassword);
        if (requireChange) {
          setChangeCurrentPwd(password);
          setIsMandatoryModalOpen(true);
        } else {
          setIsMandatoryModalOpen(false);
        }
        justLoggedInRef.current = true;
        setPassword('');
        setShowPassword(false);
        setLoginCaptchaInput('');
        setLoginCaptchaToken('');
        setCurrentUser(user);
      } else {
        setLoginAlert({
          type: 'error',
          text: data.message || 'Authentication failed. Check your UID, password, or CAPTCHA.'
        });
        loadLoginCaptcha();
      }
    } catch {
      setLoginAlert({
        type: 'error',
        text: 'Unable to reach central authentication server. Please verify connection.'
      });
      loadLoginCaptcha();
    } finally {
      setIsLoading(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setChangeAlert(null);

    if (!isStrongPasswordClient(changeNewPwd)) {
      setChangeAlert(
        'Password must be at least 8 characters and include 1 Capital letter (A-Z), 1 Small letter (a-z), 1 Number (0-9), and 1 Special Symbol (@#$%&*!).'
      );
      return;
    }
    if (changeNewPwd === changeCurrentPwd) {
      setChangeAlert('New password cannot be the same as your current password.');
      return;
    }
    if (changeNewPwd !== changeConfirmPwd) {
      setChangeAlert('New password and confirmation do not match.');
      return;
    }

    setIsChangingPwd(true);
    try {
      const response = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthRequestHeaders(currentUser)
        },
        body: JSON.stringify({
          uid: currentUser?.uid || uid,
          currentPassword: changeCurrentPwd,
          newPassword: changeNewPwd,
          confirmPassword: changeConfirmPwd
        })
      });
      const data = await response.json();
      if (response.ok && data.success) {
        if (data.sessionToken) localStorage.setItem(ERP_SESSION_KEY, data.sessionToken);
        const updated: AuthUser = {
          ...(data.user || currentUser!),
          mustChangePassword: false,
          isLoggedOut: false
        };
        localStorage.setItem(ERP_USER_KEY, JSON.stringify(updated));
        localStorage.setItem('mun_computer_v3_user', JSON.stringify(updated));
        localStorage.setItem('mun_current_user', JSON.stringify(updated));
        justLoggedInRef.current = true;
        setCurrentUser(updated);
        setIsMandatoryModalOpen(false);
        setChangeCurrentPwd('');
        setChangeNewPwd('');
        setChangeConfirmPwd('');
      } else {
        setChangeAlert(data.message || 'Password update failed.');
      }
    } catch {
      setChangeAlert('Network error while updating password.');
    } finally {
      setIsChangingPwd(false);
    }
  };

  const handleLogout = () => {
    resetToLoginScreen({
      type: 'info',
      text: 'Signed out successfully. Enter your credentials to sign in again.'
    });
  };

  // --- Separate Forgot Password Interface (STRICT NO-OTP 6-STEP FLOW) ---
  const openForgotModal = () => {
    setIsForgotModalOpen(true);
    setForgotStep(1);
    setForgotAlert(null);
    setForgotUid('');
    setForgotStepToken('');
    setForgotPhone('');
    setForgotAadhaar('');
    setForgotResetToken('');
    setForgotNewPwd('');
    setForgotConfirmPwd('');
    setShowForgotNewPwd(false);
    setShowForgotConfirmPwd(false);
    loadForgotCaptcha();
  };

  const handleForgotStep1Next = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotAlert(null);
    if (!forgotUid.trim()) {
      setForgotAlert({ type: 'error', text: 'Please enter your permanent User ID (UID).' });
      return;
    }
    setForgotUid(forgotUid.trim().toUpperCase());
    setForgotStep(2);
    if (!forgotCaptchaSvg) loadForgotCaptcha();
  };

  const handleForgotStep2VerifyCaptcha = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotAlert(null);
    if (!forgotCaptchaInput.trim() || !forgotCaptchaToken) {
      setForgotAlert({ type: 'error', text: 'Please enter the security CAPTCHA characters.' });
      return;
    }
    setForgotLoading(true);
    try {
      const resp = await fetch('/api/auth/forgot/verify-step1', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: forgotUid.trim().toUpperCase(),
          captchaToken: forgotCaptchaToken,
          captchaInput: forgotCaptchaInput.trim()
        })
      });
      const data = await resp.json();
      if (resp.ok && data.success && data.stepToken) {
        setForgotStepToken(data.stepToken);
        setForgotStep(3);
      } else {
        setForgotAlert({ type: 'error', text: data.message || 'User ID or CAPTCHA verification failed.' });
        loadForgotCaptcha();
      }
    } catch {
      setForgotAlert({ type: 'error', text: 'Unable to reach verification server.' });
    } finally {
      setForgotLoading(false);
    }
  };

  const handleForgotStep3Next = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotAlert(null);
    const cleanPhone = forgotPhone.replace(/[^0-9]/g, '');
    if (cleanPhone.length !== 10) {
      setForgotAlert({ type: 'error', text: 'Please enter your valid 10-digit registered mobile number.' });
      return;
    }
    setForgotPhone(cleanPhone);
    setForgotStep(4);
  };

  const handleForgotStep4VerifyIdentity = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotAlert(null);
    const cleanAadhaar = forgotAadhaar.replace(/[^0-9]/g, '');
    if (cleanAadhaar.length !== 12) {
      setForgotAlert({ type: 'error', text: 'Please enter your full 12-digit registered Aadhaar number.' });
      return;
    }
    setForgotLoading(true);
    try {
      const resp = await fetch('/api/auth/forgot/verify-identity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stepToken: forgotStepToken,
          phone: forgotPhone,
          aadhaarNumber: cleanAadhaar
        })
      });
      const data = await resp.json();
      if (resp.ok && data.success && data.resetToken) {
        setForgotResetToken(data.resetToken);
        setForgotStep(5);
      } else {
        setForgotAlert({
          type: 'error',
          text: data.message || 'Identity verification failed. UID, mobile number, or Aadhaar did not match.'
        });
      }
    } catch {
      setForgotAlert({ type: 'error', text: 'Network error during identity verification.' });
    } finally {
      setForgotLoading(false);
    }
  };

  const handleForgotStep5ResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotAlert(null);
    if (!forgotResetToken) {
      setForgotAlert({ type: 'error', text: 'Verified reset token missing. Restart verification.' });
      return;
    }
    if (!isStrongPasswordClient(forgotNewPwd)) {
      setForgotAlert({
        type: 'error',
        text: 'Password must be at least 8 characters and include 1 Capital letter (A-Z), 1 Small letter (a-z), 1 Number (0-9), and 1 Special Symbol (@#$%&*!).'
      });
      return;
    }
    if (forgotNewPwd !== forgotConfirmPwd) {
      setForgotAlert({ type: 'error', text: 'New password and confirmation do not match.' });
      return;
    }

    setForgotLoading(true);
    try {
      const resp = await fetch('/api/auth/forgot/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          resetToken: forgotResetToken,
          newPassword: forgotNewPwd,
          confirmPassword: forgotConfirmPwd
        })
      });
      const data = await resp.json();
      if (resp.ok && data.success) {
        clearAuthStorage();
        setForgotSuccessBanner({
          title: data.title || 'PASSWORD RESET SUCCESSFUL!',
          message: data.message || 'Your password has been changed successfully. Please log in with your new password.'
        });
        setForgotStep(6);
      } else {
        setForgotAlert({ type: 'error', text: data.message || 'Password reset failed.' });
      }
    } catch {
      setForgotAlert({ type: 'error', text: 'Network error during password update.' });
    } finally {
      setForgotLoading(false);
    }
  };

  if (!currentUser) {
    const panelCtaLabel =
      activePanel === 'ADMIN'
        ? 'Sign In to Administration'
        : activePanel === 'MANAGER'
          ? 'Sign In to Manager'
          : 'Sign In to Staff';

    const uidFieldLabel =
      activePanel === 'ADMIN'
        ? 'User ID'
        : activePanel === 'MANAGER'
          ? 'Manager User ID'
          : 'Staff User ID';

    const uidPlaceholder =
      activePanel === 'ADMIN'
        ? DEFAULT_ADMIN_UID
        : activePanel === 'MANAGER'
          ? `MUNCOMPUTER-MN-${todayDateStr.slice(0, 4)}-`
          : `MUNCOMPUTER-ST-${todayDateStr.slice(0, 4)}-`;

    const roleOptions: Array<{
      id: LoginPanel;
      label: string;
      Icon: typeof Crown;
    }> = [
      { id: 'ADMIN', label: 'Administration', Icon: Crown },
      { id: 'MANAGER', label: 'Manager', Icon: Briefcase },
      { id: 'STAFF', label: 'Staff', Icon: UserCheck }
    ];

    return (
      <MotionConfig reducedMotion="user">
        <div className="min-h-screen mun-login-bg text-[#0b2447] flex flex-col items-center justify-center p-4 sm:p-6 selection:bg-blue-600 selection:text-white relative overflow-hidden">
          <LoginWaveBackdrop />

          {/* Responsive top-right PWA Install Action — non-overlapping on mobile, pinned top-right on sm+ */}
          <div className="relative z-20 w-full max-w-[540px] flex justify-end mb-3 sm:mb-0 sm:w-auto sm:max-w-none sm:fixed sm:top-5 sm:right-5">
            <PWAInstallButton variant="login" />
          </div>

          <motion.div
            initial={{ opacity: 0, y: 14, scale: 0.985 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.34, ease: [0.22, 1, 0.36, 1] }}
            className="relative z-10 w-full max-w-[540px] box-border overflow-hidden flex flex-col mun-login-card-glass backdrop-blur-xl bg-white/85 rounded-[28px] p-6 sm:p-8 shadow-[0_20px_50px_rgba(8,112,184,0.15)]"
          >
            {/* Brand Header matching MUN COMPUTER Portal Identity */}
            <div className="pt-1 pb-1.5">
              <MunComputerLogo />
            </div>

            <div className="h-[1.5px] w-full bg-gradient-to-r from-blue-300/15 via-blue-400/75 to-blue-300/15 my-4" />

            {/* Portal Status & Active Role Indicator */}
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3.5 min-h-[20px]">
              <div className="inline-flex items-center gap-2 text-[11px] sm:text-xs font-extrabold uppercase tracking-[0.04em] text-[#15803d]">
                <span className="w-3.5 h-3.5 rounded-full bg-[#16a34a] inline-block shrink-0 shadow-[0_0_0_2px_rgba(22,163,74,0.18)]" />
                <span>Authorized Portal Access</span>
              </div>
              <AnimatePresence mode="wait" initial={false}>
                <motion.span
                  key={activePanel}
                  initial={{ opacity: 0, y: 3 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -3 }}
                  transition={{ duration: 0.16, ease: 'easeOut' }}
                  className="text-xs font-bold text-[#0044aa] tracking-wide"
                >
                  {activePanel === 'ADMIN' ? 'Administration' : activePanel === 'MANAGER' ? 'Manager' : 'Staff'}
                </motion.span>
              </AnimatePresence>
            </div>

            {/* Segmented Role Switcher with Equal Width Distribution */}
            <div
              role="tablist"
              aria-label="Portal Role Selector"
              className="flex items-center gap-1.5 p-1.5 bg-[#e5f0fe]/90 rounded-full border border-[#bad6fb] shadow-inner mb-5 w-full box-border overflow-hidden"
            >
              {roleOptions.map(({ id, label, Icon }) => {
                const isActive = activePanel === id;
                return (
                  <button
                    key={id}
                    type="button"
                    role="tab"
                    aria-selected={isActive}
                    onClick={() => handlePanelSelect(id)}
                    className={`relative flex-1 min-w-0 min-h-[40px] px-2.5 sm:px-3.5 rounded-full text-xs font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563eb]/50 ${
                      isActive ? 'text-white' : 'text-[#1e3a5f] hover:text-[#0044aa]'
                    }`}
                  >
                    {isActive && (
                      <motion.span
                        layoutId="mun-login-role-pill"
                        transition={{ type: 'spring', stiffness: 460, damping: 34 }}
                        className="absolute inset-0 rounded-full bg-gradient-to-b from-[#1e8cff] to-[#0050cc] shadow-[0_2px_8px_rgba(0,74,189,0.35),inset_0_1px_0_rgba(255,255,255,0.45)]"
                        aria-hidden="true"
                      />
                    )}
                    <Icon className="relative z-10 w-3.5 h-3.5 shrink-0 hidden sm:inline" />
                    <span className="relative z-10 truncate">{label}</span>
                  </button>
                );
              })}
            </div>

            <AnimatePresence initial={false}>
              {loginAlert && (
                <motion.div
                  key={`${loginAlert.type}-${loginAlert.text}`}
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -4 }}
                  transition={{ duration: 0.18, ease: 'easeOut' }}
                  className={`mb-4 p-3.5 rounded-2xl border text-xs font-medium flex items-center gap-2.5 box-border ${
                    loginAlert.type === 'error'
                      ? 'bg-red-50/95 border-red-200 text-red-700'
                      : loginAlert.type === 'success'
                        ? 'bg-emerald-50/95 border-emerald-200 text-emerald-700'
                        : 'bg-blue-50/95 border-blue-200 text-[#0044aa]'
                  }`}
                >
                  {loginAlert.type === 'error' ? (
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                  )}
                  <span className="min-w-0 break-words">{loginAlert.text}</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Login Form */}
            <form onSubmit={handleLogin} className="flex flex-col gap-4 w-full box-border">
              <div className="flex flex-col gap-1.5 w-full">
                <label className="block text-[13px] font-bold text-[#0b2447] pl-1">
                  {uidFieldLabel} <span className="text-[#1d64f2]">*</span>
                </label>
                <input
                  type="text"
                  value={uid}
                  onChange={(e) => setUid(e.target.value.toUpperCase())}
                  placeholder={uidPlaceholder}
                  autoComplete="username"
                  className="w-full box-border min-h-[46px] px-4.5 py-2.5 mun-login-input-pill rounded-full font-mono text-[14px] font-semibold tabular-nums placeholder:text-slate-400 focus:outline-none"
                  required
                />
              </div>

              <div className="flex flex-col gap-1.5 w-full">
                <div className="flex items-center justify-between gap-2 px-1">
                  <label className="text-[13px] font-bold text-[#0b2447]">
                    Password <span className="text-[#1d64f2]">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    className="px-2 py-0.5 rounded-md text-xs text-[#0057d9] hover:text-[#003da6] hover:bg-blue-50/80 transition flex items-center gap-1 cursor-pointer font-bold shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563eb]/45"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    <span>{showPassword ? 'Hide' : 'Show'}</span>
                  </button>
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your account password"
                  autoComplete="current-password"
                  className="w-full box-border min-h-[46px] px-4.5 py-2.5 mun-login-input-pill rounded-full text-sm placeholder:text-slate-400 focus:outline-none"
                  required
                />
              </div>

              {/* Security CAPTCHA */}
              <div className="flex flex-col gap-1.5 w-full">
                <label className="block text-[13px] font-bold text-[#0b2447] pl-1">
                  CAPTCHA Verification <span className="text-[#1d64f2]">*</span>
                </label>
                <div className="flex flex-col sm:flex-row sm:items-center gap-3 w-full box-border">
                  <div className="flex items-center gap-2.5 shrink-0">
                    {loginCaptchaSvg ? (
                      <div
                        className="w-[160px] h-[46px] rounded-xl border-[1.5px] border-[#2563eb] overflow-hidden bg-white shrink-0 flex items-center justify-center shadow-xs mun-captcha-box"
                        dangerouslySetInnerHTML={{ __html: loginCaptchaSvg }}
                      />
                    ) : (
                      <button
                        type="button"
                        onClick={loadLoginCaptcha}
                        className="w-[160px] h-[46px] rounded-xl border-[1.5px] border-[#8ec0f9] bg-white text-xs font-semibold text-[#0044aa] flex items-center justify-center gap-1.5 cursor-pointer hover:border-[#2563eb] transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563eb]/45"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${captchaLoading ? 'animate-spin' : ''}`} />
                        <span>{captchaError ? 'Tap to Retry' : 'Loading...'}</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={loadLoginCaptcha}
                      disabled={captchaLoading}
                      aria-label="Refresh CAPTCHA"
                      className="h-[46px] w-[46px] flex items-center justify-center bg-gradient-to-b from-white to-[#dbeafe] hover:from-[#f8fbff] hover:to-[#bfdbfe] hover:border-[#60a5fa] active:scale-95 border border-[#93c5fd] text-[#0047cc] rounded-full cursor-pointer shrink-0 disabled:opacity-60 disabled:cursor-not-allowed shadow-sm transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563eb]/45"
                      title="Refresh CAPTCHA"
                    >
                      <RefreshCw className={`w-4 h-4 ${captchaLoading ? 'animate-spin' : ''}`} />
                    </button>
                  </div>
                  <input
                    type="text"
                    value={loginCaptchaInput}
                    onChange={(e) => setLoginCaptchaInput(e.target.value.toUpperCase())}
                    placeholder="Enter 6-char CAPTCHA"
                    maxLength={6}
                    autoComplete="off"
                    className="w-full flex-1 min-w-0 box-border min-h-[46px] px-4.5 py-2.5 mun-login-input-pill rounded-full font-mono uppercase tracking-wider text-sm font-semibold placeholder:text-slate-400 placeholder:tracking-normal placeholder:font-sans placeholder:normal-case focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 text-xs pt-0.5 px-1 w-full">
                <label className="flex items-center gap-2 text-[#0b2447] font-semibold cursor-pointer select-none py-0.5">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded accent-[#0057d9] border-blue-400 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563eb]/45 focus-visible:ring-offset-1"
                  />
                  <span>Remember UID</span>
                </label>

                <button
                  type="button"
                  onClick={openForgotModal}
                  className="px-2 py-0.5 rounded-md text-[#0057d9] hover:text-[#003da6] hover:bg-blue-50/80 transition font-bold cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563eb]/45"
                >
                  Forgot Password?
                </button>
              </div>

              <div className="pt-1 w-full">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="group w-full box-border min-h-[54px] px-6 text-white rounded-full font-display font-bold text-[15px] flex items-center justify-center gap-3 cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed text-center mun-login-cta-gloss"
                >
                  {isLoading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin shrink-0" />
                      <span>Verifying Credentials...</span>
                    </>
                  ) : (
                    <>
                      <User className="w-5 h-5 shrink-0 fill-white/90" />
                      <span className="h-5 w-[1.5px] bg-white/65 shrink-0" aria-hidden="true" />
                      <span>{panelCtaLabel}</span>
                      <ArrowRight className="w-4 h-4 shrink-0 transition-transform duration-150 group-hover:translate-x-0.5" />
                    </>
                  )}
                </button>
              </div>
            </form>

            <div className="mt-6 pt-4 border-t border-blue-200/80 flex items-center justify-center gap-2.5 text-center text-xs font-semibold text-[#0b2447] leading-relaxed w-full box-border">
              <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-[#16a34a] text-white shrink-0 shadow-xs">
                <ShieldCheck className="w-3.5 h-3.5" />
              </span>
              <span className="text-balance min-w-0">
                Protected by Administration Authority ({DEFAULT_ADMIN_UID}) • 5-attempt lockout &amp; session verification
              </span>
            </div>
          </motion.div>

          {/* SEPARATE FORGOT PASSWORD MODAL — STRICT NO-OTP 6-STEP VERIFICATION */}
          <AnimatePresence>
            {isForgotModalOpen && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2, ease: 'easeOut' }}
                onClick={(e) => {
                  if (e.target === e.currentTarget) setIsForgotModalOpen(false);
                }}
                className="fixed inset-0 z-50 bg-slate-900/45 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
              >
                <motion.div
                  initial={{ opacity: 0, y: 16, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.975 }}
                  transition={{ duration: 0.24, ease: [0.22, 1, 0.36, 1] }}
                  role="dialog"
                  aria-modal="true"
                  aria-label="Reset Account Password"
                  className="w-full max-w-[500px] box-border overflow-hidden mun-login-card-glass backdrop-blur-xl bg-white/85 rounded-[26px] p-6 sm:p-8 shadow-[0_20px_50px_rgba(8,112,184,0.15)] relative my-auto text-[#0b2447]"
                >
                  <div className="flex items-center justify-between pb-3 border-b border-blue-200/80 mb-4">
                    <h3 className="text-sm font-display font-bold text-[#0b2447] flex items-center gap-2">
                      <KeyRound className="w-4 h-4 text-[#0057d9]" />
                      <span>Reset Account Password (No-OTP Verification)</span>
                    </h3>
                    <button
                      type="button"
                      onClick={() => setIsForgotModalOpen(false)}
                      aria-label="Close password reset dialog"
                      className="p-1.5 rounded-full text-slate-500 hover:text-[#0b2447] hover:bg-blue-100/70 transition cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563eb]/45"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* 6-Step Progress Bar */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between text-[11px] text-slate-600 mb-1.5 font-mono font-semibold tabular-nums">
                      <span>STEP {forgotStep} OF 6</span>
                      <span className="text-[#0044aa]">
                        {forgotStep === 1 && 'User ID'}
                        {forgotStep === 2 && 'CAPTCHA Check'}
                        {forgotStep === 3 && 'Mobile Number'}
                        {forgotStep === 4 && 'Aadhaar Identity'}
                        {forgotStep === 5 && 'Set New Password'}
                        {forgotStep === 6 && 'Confirmation'}
                      </span>
                    </div>
                    <div className="grid grid-cols-6 gap-1">
                      {[1, 2, 3, 4, 5, 6].map((s) => (
                        <div
                          key={s}
                          className={`h-1.5 rounded-full transition ${
                            s <= forgotStep ? 'bg-gradient-to-r from-[#1a88ff] to-[#0052cc]' : 'bg-blue-100'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  <AnimatePresence initial={false}>
                    {forgotAlert && (
                      <motion.div
                        key={`${forgotAlert.type}-${forgotAlert.text}`}
                        initial={{ opacity: 0, y: -5 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -4 }}
                        transition={{ duration: 0.16 }}
                        className={`mb-3 p-2.5 rounded-xl border text-xs font-medium ${
                          forgotAlert.type === 'error'
                            ? 'bg-red-50 border-red-200 text-red-700'
                            : forgotAlert.type === 'success'
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                              : 'bg-blue-50 border-blue-200 text-[#0044aa]'
                        }`}
                      >
                        {forgotAlert.text}
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <AnimatePresence mode="wait" initial={false}>
                    <motion.div
                      key={forgotStep}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                      transition={{ duration: 0.18, ease: 'easeOut' }}
                    >
                      {/* STEP 1: User ID */}
                      {forgotStep === 1 && (
                        <form onSubmit={handleForgotStep1Next} className="space-y-3">
                          <div className="text-xs text-slate-700">
                            Step 1 of 6: Enter your permanent User ID assigned by MUN COMPUTER.
                          </div>
                          <div>
                            <label className="text-xs font-bold text-[#0b2447]">User ID *</label>
                            <input
                              type="text"
                              value={forgotUid}
                              onChange={(e) => setForgotUid(e.target.value.toUpperCase())}
                              placeholder={`${DEFAULT_ADMIN_UID} or MUNCOMPUTER-ST-...`}
                              className="w-full min-h-[42px] mt-1 px-4 py-2 mun-login-input-pill rounded-full font-mono text-sm focus:outline-none"
                              required
                            />
                          </div>
                          <button
                            type="submit"
                            className="w-full min-h-[44px] py-2.5 text-white rounded-full text-xs font-bold cursor-pointer mun-login-cta-gloss"
                          >
                            Continue to Step 2: CAPTCHA →
                          </button>
                        </form>
                      )}

                      {/* STEP 2: CAPTCHA Verification */}
                      {forgotStep === 2 && (
                        <form onSubmit={handleForgotStep2VerifyCaptcha} className="space-y-3">
                          <div className="text-xs text-slate-700">
                            Step 2 of 6: Complete security CAPTCHA verification for{' '}
                            <strong className="text-[#0044aa] font-mono">{forgotUid}</strong>.
                          </div>
                          <div>
                            <label className="text-xs font-bold text-[#0b2447]">Security CAPTCHA *</label>
                            <div className="flex items-center gap-2 mt-1">
                              {forgotCaptchaSvg ? (
                                <div
                                  className="w-[170px] h-[48px] rounded-xl border-[1.5px] border-[#2563eb] overflow-hidden bg-white shrink-0 flex items-center justify-center shadow-xs mun-captcha-box"
                                  dangerouslySetInnerHTML={{ __html: forgotCaptchaSvg }}
                                />
                              ) : (
                                <button
                                  type="button"
                                  onClick={loadForgotCaptcha}
                                  className="w-[170px] h-[48px] rounded-xl border border-blue-300 bg-white text-xs font-semibold text-[#0044aa] flex items-center justify-center gap-1.5 cursor-pointer hover:border-[#2563eb] transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563eb]/45"
                                >
                                  <RefreshCw className={`w-3.5 h-3.5 ${forgotCaptchaLoading ? 'animate-spin' : ''}`} />
                                  <span>{forgotCaptchaError ? 'Tap to Retry' : 'Loading...'}</span>
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={loadForgotCaptcha}
                                disabled={forgotCaptchaLoading}
                                aria-label="Refresh CAPTCHA"
                                className="h-[44px] w-[44px] flex items-center justify-center bg-gradient-to-b from-white to-[#dbeafe] hover:from-[#f8fbff] hover:to-[#bfdbfe] hover:border-[#60a5fa] active:scale-95 border border-[#93c5fd] text-[#0047cc] rounded-full cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed shadow-sm transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563eb]/45"
                                title="Refresh CAPTCHA"
                              >
                                <RefreshCw className={`w-4 h-4 ${forgotCaptchaLoading ? 'animate-spin' : ''}`} />
                              </button>
                            </div>
                            <input
                              type="text"
                              value={forgotCaptchaInput}
                              onChange={(e) => setForgotCaptchaInput(e.target.value.toUpperCase())}
                              placeholder="Enter 6-character CAPTCHA above"
                              maxLength={6}
                              className="w-full min-h-[42px] mt-2 px-4 py-2 mun-login-input-pill rounded-full font-mono uppercase tracking-widest text-sm focus:outline-none"
                              required
                            />
                          </div>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                setForgotAlert(null);
                                setForgotStep(1);
                              }}
                              className="px-4 py-2.5 bg-white border border-blue-200 text-[#0b2447] rounded-full text-xs font-semibold cursor-pointer hover:bg-blue-50"
                            >
                              ← Back
                            </button>
                            <button
                              type="submit"
                              disabled={forgotLoading}
                              className="flex-1 py-2.5 text-white rounded-full text-xs font-bold disabled:opacity-60 cursor-pointer mun-login-cta-gloss"
                            >
                              {forgotLoading ? 'Verifying CAPTCHA...' : 'Verify CAPTCHA → Step 3'}
                            </button>
                          </div>
                        </form>
                      )}

                      {/* STEP 3: Registered Mobile Number (NO OTP) */}
                      {forgotStep === 3 && (
                        <form onSubmit={handleForgotStep3Next} className="space-y-3">
                          <div className="text-xs text-slate-700">
                            Step 3 of 6: Enter your 10-digit registered mobile number for{' '}
                            <strong className="text-[#0044aa] font-mono">{forgotUid}</strong>.
                          </div>
                          <div className="p-2.5 rounded-xl bg-white/80 border border-blue-200 text-[11px] text-slate-600">
                            No OTP or SMS code is sent. Your mobile number is matched locally alongside your Aadhaar number in the next step.
                          </div>
                          <div>
                            <label className="text-xs font-bold text-[#0b2447]">Registered 10-Digit Mobile Number *</label>
                            <input
                              type="tel"
                              value={forgotPhone}
                              onChange={(e) => setForgotPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                              placeholder="10-digit registered mobile number"
                              maxLength={10}
                              className="w-full min-h-[42px] mt-1 px-4 py-2 mun-login-input-pill rounded-full font-mono text-sm focus:outline-none"
                              required
                            />
                          </div>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                setForgotAlert(null);
                                setForgotStep(2);
                              }}
                              className="px-4 py-2.5 bg-white border border-blue-200 text-[#0b2447] rounded-full text-xs font-semibold cursor-pointer hover:bg-blue-50"
                            >
                              ← Back
                            </button>
                            <button
                              type="submit"
                              className="flex-1 py-2.5 text-white rounded-full text-xs font-bold cursor-pointer mun-login-cta-gloss"
                            >
                              Continue to Step 4: Aadhaar →
                            </button>
                          </div>
                        </form>
                      )}

                      {/* STEP 4: Registered 12-Digit Aadhaar Verification */}
                      {forgotStep === 4 && (
                        <form onSubmit={handleForgotStep4VerifyIdentity} className="space-y-3">
                          <div className="text-xs text-slate-700">
                            Step 4 of 6: Enter your 12-digit registered Aadhaar number to confirm identity.
                          </div>
                          <div className="p-2.5 rounded-xl bg-white/80 border border-blue-200 text-[11px] text-slate-600 leading-relaxed">
                            Security Note: Performs a local encrypted identity match against stored account registration details only. Your stored Aadhaar is never displayed.
                          </div>
                          <div>
                            <label className="text-xs font-bold text-[#0b2447]">Registered 12-Digit Aadhaar Number *</label>
                            <input
                              type="password"
                              inputMode="numeric"
                              value={forgotAadhaar}
                              onChange={(e) => setForgotAadhaar(e.target.value.replace(/\D/g, '').slice(0, 12))}
                              placeholder="Enter 12-digit Aadhaar number"
                              maxLength={12}
                              className="w-full min-h-[42px] mt-1 px-4 py-2 mun-login-input-pill rounded-full font-mono text-sm tracking-wider focus:outline-none"
                              required
                            />
                          </div>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                setForgotAlert(null);
                                setForgotStep(3);
                              }}
                              className="px-4 py-2.5 bg-white border border-blue-200 text-[#0b2447] rounded-full text-xs font-semibold cursor-pointer hover:bg-blue-50"
                            >
                              ← Back
                            </button>
                            <button
                              type="submit"
                              disabled={forgotLoading}
                              className="flex-1 py-2.5 text-white rounded-full text-xs font-bold disabled:opacity-60 cursor-pointer mun-login-cta-gloss"
                            >
                              {forgotLoading ? 'Matching Identity...' : 'Verify Identity → Step 5'}
                            </button>
                          </div>
                        </form>
                      )}

                      {/* STEP 5: Password Reset Form */}
                      {forgotStep === 5 && (
                        <form onSubmit={handleForgotStep5ResetPassword} className="space-y-3">
                          <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-medium flex items-center gap-2">
                            <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-600" />
                            <span>Identity verified for {forgotUid}. Set a new strong password below.</span>
                          </div>

                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <label className="text-xs font-bold text-[#0b2447]">New Password *</label>
                              <button
                                type="button"
                                onClick={() => setShowForgotNewPwd(!showForgotNewPwd)}
                                className="text-xs font-bold text-[#0057d9] hover:text-[#003da6] flex items-center gap-1 cursor-pointer"
                              >
                                {showForgotNewPwd ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                                <span>{showForgotNewPwd ? 'Hide' : 'Show'}</span>
                              </button>
                            </div>
                            <input
                              type={showForgotNewPwd ? 'text' : 'password'}
                              value={forgotNewPwd}
                              onChange={(e) => setForgotNewPwd(e.target.value)}
                              placeholder="Enter new strong password"
                              className="w-full min-h-[42px] px-4 py-2 mun-login-input-pill rounded-full text-sm focus:outline-none"
                              required
                            />
                          </div>

                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <label className="text-xs font-bold text-[#0b2447]">Confirm New Password *</label>
                              <button
                                type="button"
                                onClick={() => setShowForgotConfirmPwd(!showForgotConfirmPwd)}
                                className="text-xs font-bold text-[#0057d9] hover:text-[#003da6] flex items-center gap-1 cursor-pointer"
                              >
                                {showForgotConfirmPwd ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                                <span>{showForgotConfirmPwd ? 'Hide' : 'Show'}</span>
                              </button>
                            </div>
                            <input
                              type={showForgotConfirmPwd ? 'text' : 'password'}
                              value={forgotConfirmPwd}
                              onChange={(e) => setForgotConfirmPwd(e.target.value)}
                              placeholder="Re-enter new password"
                              className="w-full min-h-[42px] px-4 py-2 mun-login-input-pill rounded-full text-sm focus:outline-none"
                              required
                            />
                          </div>

                          <PasswordInstructionsCard pwd={forgotNewPwd} />

                          <button
                            type="submit"
                            disabled={forgotLoading}
                            className="w-full min-h-[44px] py-2.5 text-white rounded-full text-xs font-bold disabled:opacity-60 cursor-pointer mun-login-cta-gloss"
                          >
                            {forgotLoading ? 'Updating Password...' : 'Reset Password'}
                          </button>
                        </form>
                      )}

                      {/* STEP 6: Exact Confirmation Screen */}
                      {forgotStep === 6 && (
                        <div className="space-y-4 text-center py-3">
                          <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 inline-flex items-center justify-center">
                            <CheckCircle2 className="w-6 h-6" />
                          </div>
                          <div>
                            <h4 className="text-base font-extrabold text-emerald-700 tracking-wide">
                              {forgotSuccessBanner.title}
                            </h4>
                            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                              {forgotSuccessBanner.message}
                            </p>
                          </div>
                          <div className="text-[11px] text-slate-600 bg-white/80 border border-blue-200 rounded-xl p-2.5">
                            All prior active login sessions for <strong className="font-mono text-[#0b2447]">{forgotUid}</strong> have been invalidated.
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setUid(forgotUid);
                              setPassword('');
                              setIsForgotModalOpen(false);
                              loadLoginCaptcha();
                            }}
                            className="w-full min-h-[44px] py-2.5 text-white rounded-full text-xs font-bold cursor-pointer mun-login-cta-gloss"
                          >
                            Return to Login Panels
                          </button>
                        </div>
                      )}
                    </motion.div>
                  </AnimatePresence>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
          <OfflineIndicator />
          <PWAInstallModalHost />
        </div>
      </MotionConfig>
    );
  }

  // Mandatory First-Login / Temporary Password Change View
  if (isMandatoryModalOpen) {
    return (
      <MotionConfig reducedMotion="user">
        <div className="min-h-screen mun-login-bg flex items-center justify-center p-4 relative overflow-hidden">
          <LoginWaveBackdrop />
          <motion.div
            initial={{ opacity: 0, y: 16, scale: 0.975 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="relative z-10 w-full max-w-[500px] box-border overflow-hidden mun-login-card-glass backdrop-blur-xl bg-white/85 rounded-[26px] p-6 sm:p-8 shadow-[0_20px_50px_rgba(8,112,184,0.15)] text-[#0b2447]"
          >
            <div className="flex items-center gap-3 pb-4 border-b border-blue-200/80 mb-5">
              <div className="w-10 h-10 rounded-xl bg-amber-100 border border-amber-300 text-amber-700 flex items-center justify-center shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-display text-base font-bold text-[#0b2447]">Mandatory Password Change</h2>
                <p className="text-xs text-slate-600">
                  User: <span className="font-mono text-[#0044aa] font-bold">{currentUser.uid}</span>
                </p>
              </div>
            </div>

            <AnimatePresence initial={false}>
              {changeAlert && (
                <motion.div
                  key={changeAlert}
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -4 }}
                  transition={{ duration: 0.16 }}
                  className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-xs font-medium text-red-700"
                >
                  {changeAlert}
                </motion.div>
              )}
            </AnimatePresence>

            <form onSubmit={handlePasswordChange} className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-[#0b2447]">Current / Temporary Password *</label>
                  <button
                    type="button"
                    onClick={() => setShowChangeCurrentPwd(!showChangeCurrentPwd)}
                    className="text-xs font-bold text-[#0057d9] flex items-center gap-1 cursor-pointer"
                  >
                    {showChangeCurrentPwd ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{showChangeCurrentPwd ? 'Hide' : 'Show'}</span>
                  </button>
                </div>
                <input
                  type={showChangeCurrentPwd ? 'text' : 'password'}
                  value={changeCurrentPwd}
                  onChange={(e) => setChangeCurrentPwd(e.target.value)}
                  placeholder="Enter issued one-time temporary password"
                  className="w-full min-h-[42px] px-4 py-2 mun-login-input-pill rounded-full text-sm focus:outline-none"
                  required
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-[#0b2447]">New Strong Password *</label>
                  <button
                    type="button"
                    onClick={() => setShowChangeNewPwd(!showChangeNewPwd)}
                    className="text-xs font-bold text-[#0057d9] flex items-center gap-1 cursor-pointer"
                  >
                    {showChangeNewPwd ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{showChangeNewPwd ? 'Hide' : 'Show'}</span>
                  </button>
                </div>
                <input
                  type={showChangeNewPwd ? 'text' : 'password'}
                  value={changeNewPwd}
                  onChange={(e) => setChangeNewPwd(e.target.value)}
                  placeholder="Enter custom strong password"
                  className="w-full min-h-[42px] px-4 py-2 mun-login-input-pill rounded-full text-sm focus:outline-none"
                  required
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-[#0b2447]">Confirm New Password *</label>
                  <button
                    type="button"
                    onClick={() => setShowChangeConfirmPwd(!showChangeConfirmPwd)}
                    className="text-xs font-bold text-[#0057d9] flex items-center gap-1 cursor-pointer"
                  >
                    {showChangeConfirmPwd ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{showChangeConfirmPwd ? 'Hide' : 'Show'}</span>
                  </button>
                </div>
                <input
                  type={showChangeConfirmPwd ? 'text' : 'password'}
                  value={changeConfirmPwd}
                  onChange={(e) => setChangeConfirmPwd(e.target.value)}
                  placeholder="Re-enter custom password"
                  className="w-full min-h-[42px] px-4 py-2 mun-login-input-pill rounded-full text-sm focus:outline-none"
                  required
                />
              </div>

              <PasswordInstructionsCard pwd={changeNewPwd} />

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={handleLogout}
                  className="px-4 py-2.5 bg-white border border-blue-200 text-[#0b2447] rounded-full text-xs font-semibold cursor-pointer hover:bg-blue-50"
                >
                  Sign Out
                </button>
                <button
                  type="submit"
                  disabled={isChangingPwd}
                  className="flex-1 py-2.5 text-white rounded-full text-xs font-bold disabled:opacity-60 cursor-pointer mun-login-cta-gloss"
                >
                  {isChangingPwd ? 'Updating Password...' : 'Update Password & Enter Dashboard →'}
                </button>
              </div>
            </form>
          </motion.div>
          <SessionTimeoutNotice
            visible={isSessionWarningVisible}
            remainingMs={sessionRemainingMs}
            warningWindowMs={INACTIVITY_WARNING_MS}
            isExtending={isExtendingSession}
            onExtend={handleExtendSession}
            onSignOut={handleManualWarningSignOut}
          />
          <OfflineIndicator />
          <PWAInstallModalHost />
        </div>
      </MotionConfig>
    );
  }

  return (
    <>
      <div id="erp-root" ref={erpRootRef} className="min-h-screen w-full" />
      <SessionTimeoutNotice
        visible={isSessionWarningVisible}
        remainingMs={sessionRemainingMs}
        warningWindowMs={INACTIVITY_WARNING_MS}
        isExtending={isExtendingSession}
        onExtend={handleExtendSession}
        onSignOut={handleManualWarningSignOut}
      />
      <OfflineIndicator />
      <PWAInstallModalHost />
    </>
  );
}
